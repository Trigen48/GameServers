using System;
using System.Collections.Generic;

namespace GameServer
{
	internal static class QuestAccept
	{

        public delegate byte Listen(ConnectionInfo c, int QuestID);
        //public static Func<ConnectionInfo,int, byte> QuestFunc;

        public static Listen[][][] Handler;

        static QuestAccept()
        {
            Handler = new Listen[16][][];
            Handler[10] = new Listen[0 + 1][];
            Handler[10][0] = new Listen[26 + 1];
            Handler[10][0][1] = new Listen(QuestCode.A100001);
            Handler[10][0][2] = new Listen(QuestCode.A100002);
            Handler[10][0][3] = new Listen(QuestCode.A100003);
            Handler[10][0][5] = new Listen(QuestCode.A100005);
            Handler[10][0][7] = new Listen(QuestCode.A100007);
            Handler[10][0][9] = new Listen(QuestCode.A100009);
            Handler[10][0][10] = new Listen(QuestCode.A100010);
            Handler[10][0][12] = new Listen(QuestCode.A100012);
            Handler[10][0][13] = new Listen(QuestCode.A100013);
            Handler[10][0][14] = new Listen(QuestCode.A100014);
            Handler[10][0][15] = new Listen(QuestCode.A100015);
            Handler[10][0][16] = new Listen(QuestCode.A100016);
            Handler[10][0][17] = new Listen(QuestCode.A100017);
            Handler[10][0][20] = new Listen(QuestCode.A100020);
            Handler[10][0][23] = new Listen(QuestCode.A100023);
            Handler[10][0][24] = new Listen(QuestCode.A100024);
            Handler[10][0][25] = new Listen(QuestCode.A100025);
            Handler[10][0][26] = new Listen(QuestCode.A100026);


            Handler[11] = new Listen[90 + 1][];
            Handler[11][0] = new Listen[99 + 1];
            Handler[11][0][16] = new Listen(QuestCode.A110016);
            Handler[11][0][17] = new Listen(QuestCode.A110017);
            Handler[11][0][20] = new Listen(QuestCode.A110020);
            Handler[11][0][21] = new Listen(QuestCode.A110021);
            Handler[11][0][22] = new Listen(QuestCode.A110022);
            Handler[11][0][24] = new Listen(QuestCode.A110024);
            Handler[11][0][25] = new Listen(QuestCode.A110025);
            Handler[11][0][27] = new Listen(QuestCode.A110027);
            Handler[11][0][28] = new Listen(QuestCode.A110028);
            Handler[11][0][29] = new Listen(QuestCode.A110029);
            Handler[11][0][30] = new Listen(QuestCode.A110030);
            Handler[11][0][32] = new Listen(QuestCode.A110032);
            Handler[11][0][33] = new Listen(QuestCode.A110033);
            Handler[11][0][35] = new Listen(QuestCode.A110035);
            Handler[11][0][36] = new Listen(QuestCode.A110036);
            Handler[11][0][38] = new Listen(QuestCode.A110038);
            Handler[11][0][39] = new Listen(QuestCode.A110039);
            Handler[11][0][40] = new Listen(QuestCode.A110040);
            Handler[11][0][41] = new Listen(QuestCode.A110041);
            Handler[11][0][45] = new Listen(QuestCode.A110045);
            Handler[11][0][48] = new Listen(QuestCode.A110048);
            Handler[11][0][49] = new Listen(QuestCode.A110049);
            Handler[11][0][50] = new Listen(QuestCode.A110050);
            Handler[11][0][51] = new Listen(QuestCode.A110051);
            Handler[11][0][58] = new Listen(QuestCode.A110058);
            Handler[11][0][59] = new Listen(QuestCode.A110059);
            Handler[11][0][60] = new Listen(QuestCode.A110060);
            Handler[11][0][61] = new Listen(QuestCode.A110061);
            Handler[11][0][62] = new Listen(QuestCode.A110062);
            Handler[11][0][63] = new Listen(QuestCode.A110063);
            Handler[11][0][64] = new Listen(QuestCode.A110064);
            Handler[11][0][89] = new Listen(QuestCode.A110089);
            Handler[11][0][90] = new Listen(QuestCode.A110090);
            Handler[11][0][91] = new Listen(QuestCode.A110091);
            Handler[11][0][92] = new Listen(QuestCode.A110092);
            Handler[11][0][93] = new Listen(QuestCode.A110093);
            Handler[11][0][94] = new Listen(QuestCode.A110094);
            Handler[11][0][95] = new Listen(QuestCode.A110095);
            Handler[11][0][96] = new Listen(QuestCode.A110096);
            Handler[11][0][97] = new Listen(QuestCode.A110097);
            Handler[11][0][98] = new Listen(QuestCode.A110098);
            Handler[11][0][99] = new Listen(QuestCode.A110099);
            Handler[11][1] = new Listen[99 + 1];
            Handler[11][1][0] = new Listen(QuestCode.A110100);
            Handler[11][1][1] = new Listen(QuestCode.A110101);
            Handler[11][1][2] = new Listen(QuestCode.A110102);
            Handler[11][1][3] = new Listen(QuestCode.A110103);
            Handler[11][1][4] = new Listen(QuestCode.A110104);
            Handler[11][1][5] = new Listen(QuestCode.A110105);
            Handler[11][1][6] = new Listen(QuestCode.A110106);
            Handler[11][1][7] = new Listen(QuestCode.A110107);
            Handler[11][1][8] = new Listen(QuestCode.A110108);
            Handler[11][1][9] = new Listen(QuestCode.A110109);
            Handler[11][1][10] = new Listen(QuestCode.A110110);
            Handler[11][1][11] = new Listen(QuestCode.A110111);
            Handler[11][1][12] = new Listen(QuestCode.A110112);
            Handler[11][1][13] = new Listen(QuestCode.A110113);
            Handler[11][1][14] = new Listen(QuestCode.A110114);
            Handler[11][1][15] = new Listen(QuestCode.A110115);
            Handler[11][1][16] = new Listen(QuestCode.A110116);
            Handler[11][1][17] = new Listen(QuestCode.A110117);
            Handler[11][1][18] = new Listen(QuestCode.A110118);
            Handler[11][1][19] = new Listen(QuestCode.A110119);
            Handler[11][1][20] = new Listen(QuestCode.A110120);
            Handler[11][1][21] = new Listen(QuestCode.A110121);
            Handler[11][1][22] = new Listen(QuestCode.A110122);
            Handler[11][1][23] = new Listen(QuestCode.A110123);
            Handler[11][1][24] = new Listen(QuestCode.A110124);
            Handler[11][1][25] = new Listen(QuestCode.A110125);
            Handler[11][1][26] = new Listen(QuestCode.A110126);
            Handler[11][1][27] = new Listen(QuestCode.A110127);
            Handler[11][1][28] = new Listen(QuestCode.A110128);
            Handler[11][1][29] = new Listen(QuestCode.A110129);
            Handler[11][1][30] = new Listen(QuestCode.A110130);
            Handler[11][1][31] = new Listen(QuestCode.A110131);
            Handler[11][1][32] = new Listen(QuestCode.A110132);
            Handler[11][1][33] = new Listen(QuestCode.A110133);
            Handler[11][1][34] = new Listen(QuestCode.A110134);
            Handler[11][1][35] = new Listen(QuestCode.A110135);
            Handler[11][1][36] = new Listen(QuestCode.A110136);
            Handler[11][1][37] = new Listen(QuestCode.A110137);
            Handler[11][1][38] = new Listen(QuestCode.A110138);
            Handler[11][1][39] = new Listen(QuestCode.A110139);
            Handler[11][1][40] = new Listen(QuestCode.A110140);
            Handler[11][1][41] = new Listen(QuestCode.A110141);
            Handler[11][1][42] = new Listen(QuestCode.A110142);
            Handler[11][1][43] = new Listen(QuestCode.A110143);
            Handler[11][1][44] = new Listen(QuestCode.A110144);
            Handler[11][1][45] = new Listen(QuestCode.A110145);
            Handler[11][1][46] = new Listen(QuestCode.A110146);
            Handler[11][1][47] = new Listen(QuestCode.A110147);
            Handler[11][1][48] = new Listen(QuestCode.A110148);
            Handler[11][1][49] = new Listen(QuestCode.A110149);
            Handler[11][1][50] = new Listen(QuestCode.A110150);
            Handler[11][1][51] = new Listen(QuestCode.A110151);
            Handler[11][1][52] = new Listen(QuestCode.A110152);
            Handler[11][1][53] = new Listen(QuestCode.A110153);
            Handler[11][1][54] = new Listen(QuestCode.A110154);
            Handler[11][1][55] = new Listen(QuestCode.A110155);
            Handler[11][1][56] = new Listen(QuestCode.A110156);
            Handler[11][1][57] = new Listen(QuestCode.A110157);
            Handler[11][1][58] = new Listen(QuestCode.A110158);
            Handler[11][1][59] = new Listen(QuestCode.A110159);
            Handler[11][1][60] = new Listen(QuestCode.A110160);
            Handler[11][1][61] = new Listen(QuestCode.A110161);
            Handler[11][1][62] = new Listen(QuestCode.A110162);
            Handler[11][1][63] = new Listen(QuestCode.A110163);
            Handler[11][1][64] = new Listen(QuestCode.A110164);
            Handler[11][1][65] = new Listen(QuestCode.A110165);
            Handler[11][1][66] = new Listen(QuestCode.A110166);
            Handler[11][1][67] = new Listen(QuestCode.A110167);
            Handler[11][1][68] = new Listen(QuestCode.A110168);
            Handler[11][1][69] = new Listen(QuestCode.A110169);
            Handler[11][1][70] = new Listen(QuestCode.A110170);
            Handler[11][1][71] = new Listen(QuestCode.A110171);
            Handler[11][1][72] = new Listen(QuestCode.A110172);
            Handler[11][1][73] = new Listen(QuestCode.A110173);
            Handler[11][1][74] = new Listen(QuestCode.A110174);
            Handler[11][1][75] = new Listen(QuestCode.A110175);
            Handler[11][1][76] = new Listen(QuestCode.A110176);
            Handler[11][1][77] = new Listen(QuestCode.A110177);
            Handler[11][1][78] = new Listen(QuestCode.A110178);
            Handler[11][1][79] = new Listen(QuestCode.A110179);
            Handler[11][1][80] = new Listen(QuestCode.A110180);
            Handler[11][1][81] = new Listen(QuestCode.A110181);
            Handler[11][1][82] = new Listen(QuestCode.A110182);
            Handler[11][1][83] = new Listen(QuestCode.A110183);
            Handler[11][1][84] = new Listen(QuestCode.A110184);
            Handler[11][1][85] = new Listen(QuestCode.A110185);
            Handler[11][1][86] = new Listen(QuestCode.A110186);
            Handler[11][1][87] = new Listen(QuestCode.A110187);
            Handler[11][1][88] = new Listen(QuestCode.A110188);
            Handler[11][1][89] = new Listen(QuestCode.A110189);
            Handler[11][1][90] = new Listen(QuestCode.A110190);
            Handler[11][1][91] = new Listen(QuestCode.A110191);
            Handler[11][1][92] = new Listen(QuestCode.A110192);
            Handler[11][1][93] = new Listen(QuestCode.A110193);
            Handler[11][1][94] = new Listen(QuestCode.A110194);
            Handler[11][1][95] = new Listen(QuestCode.A110195);
            Handler[11][1][96] = new Listen(QuestCode.A110196);
            Handler[11][1][97] = new Listen(QuestCode.A110197);
            Handler[11][1][98] = new Listen(QuestCode.A110198);
            Handler[11][1][99] = new Listen(QuestCode.A110199);
            Handler[11][2] = new Listen[84 + 1];
            Handler[11][2][0] = new Listen(QuestCode.A110200);
            Handler[11][2][1] = new Listen(QuestCode.A110201);
            Handler[11][2][2] = new Listen(QuestCode.A110202);
            Handler[11][2][3] = new Listen(QuestCode.A110203);
            Handler[11][2][4] = new Listen(QuestCode.A110204);
            Handler[11][2][5] = new Listen(QuestCode.A110205);
            Handler[11][2][6] = new Listen(QuestCode.A110206);
            Handler[11][2][7] = new Listen(QuestCode.A110207);
            Handler[11][2][8] = new Listen(QuestCode.A110208);
            Handler[11][2][9] = new Listen(QuestCode.A110209);
            Handler[11][2][10] = new Listen(QuestCode.A110210);
            Handler[11][2][11] = new Listen(QuestCode.A110211);
            Handler[11][2][12] = new Listen(QuestCode.A110212);
            Handler[11][2][13] = new Listen(QuestCode.A110213);
            Handler[11][2][14] = new Listen(QuestCode.A110214);
            Handler[11][2][15] = new Listen(QuestCode.A110215);
            Handler[11][2][16] = new Listen(QuestCode.A110216);
            Handler[11][2][17] = new Listen(QuestCode.A110217);
            Handler[11][2][18] = new Listen(QuestCode.A110218);
            Handler[11][2][19] = new Listen(QuestCode.A110219);
            Handler[11][2][20] = new Listen(QuestCode.A110220);
            Handler[11][2][21] = new Listen(QuestCode.A110221);
            Handler[11][2][22] = new Listen(QuestCode.A110222);
            Handler[11][2][23] = new Listen(QuestCode.A110223);
            Handler[11][2][24] = new Listen(QuestCode.A110224);
            Handler[11][2][25] = new Listen(QuestCode.A110225);
            Handler[11][2][26] = new Listen(QuestCode.A110226);
            Handler[11][2][27] = new Listen(QuestCode.A110227);
            Handler[11][2][28] = new Listen(QuestCode.A110228);
            Handler[11][2][29] = new Listen(QuestCode.A110229);
            Handler[11][2][30] = new Listen(QuestCode.A110230);
            Handler[11][2][31] = new Listen(QuestCode.A110231);
            Handler[11][2][32] = new Listen(QuestCode.A110232);
            Handler[11][2][33] = new Listen(QuestCode.A110233);
            Handler[11][2][34] = new Listen(QuestCode.A110234);
            Handler[11][2][35] = new Listen(QuestCode.A110235);
            Handler[11][2][36] = new Listen(QuestCode.A110236);
            Handler[11][2][37] = new Listen(QuestCode.A110237);
            Handler[11][2][38] = new Listen(QuestCode.A110238);
            Handler[11][2][39] = new Listen(QuestCode.A110239);
            Handler[11][2][40] = new Listen(QuestCode.A110240);
            Handler[11][2][41] = new Listen(QuestCode.A110241);
            Handler[11][2][42] = new Listen(QuestCode.A110242);
            Handler[11][2][43] = new Listen(QuestCode.A110243);
            Handler[11][2][44] = new Listen(QuestCode.A110244);
            Handler[11][2][45] = new Listen(QuestCode.A110245);
            Handler[11][2][46] = new Listen(QuestCode.A110246);
            Handler[11][2][47] = new Listen(QuestCode.A110247);
            Handler[11][2][48] = new Listen(QuestCode.A110248);
            Handler[11][2][49] = new Listen(QuestCode.A110249);
            Handler[11][2][50] = new Listen(QuestCode.A110250);
            Handler[11][2][51] = new Listen(QuestCode.A110251);
            Handler[11][2][52] = new Listen(QuestCode.A110252);
            Handler[11][2][53] = new Listen(QuestCode.A110253);
            Handler[11][2][54] = new Listen(QuestCode.A110254);
            Handler[11][2][55] = new Listen(QuestCode.A110255);
            Handler[11][2][56] = new Listen(QuestCode.A110256);
            Handler[11][2][57] = new Listen(QuestCode.A110257);
            Handler[11][2][58] = new Listen(QuestCode.A110258);
            Handler[11][2][59] = new Listen(QuestCode.A110259);
            Handler[11][2][60] = new Listen(QuestCode.A110260);
            Handler[11][2][61] = new Listen(QuestCode.A110261);
            Handler[11][2][62] = new Listen(QuestCode.A110262);
            Handler[11][2][63] = new Listen(QuestCode.A110263);
            Handler[11][2][64] = new Listen(QuestCode.A110264);
            Handler[11][2][65] = new Listen(QuestCode.A110265);
            Handler[11][2][66] = new Listen(QuestCode.A110266);
            Handler[11][2][67] = new Listen(QuestCode.A110267);
            Handler[11][2][68] = new Listen(QuestCode.A110268);
            Handler[11][2][69] = new Listen(QuestCode.A110269);
            Handler[11][2][70] = new Listen(QuestCode.A110270);
            Handler[11][2][71] = new Listen(QuestCode.A110271);
            Handler[11][2][72] = new Listen(QuestCode.A110272);
            Handler[11][2][73] = new Listen(QuestCode.A110273);
            Handler[11][2][74] = new Listen(QuestCode.A110274);
            Handler[11][2][75] = new Listen(QuestCode.A110275);
            Handler[11][2][76] = new Listen(QuestCode.A110276);
            Handler[11][2][77] = new Listen(QuestCode.A110277);
            Handler[11][2][78] = new Listen(QuestCode.A110278);
            Handler[11][2][79] = new Listen(QuestCode.A110279);
            Handler[11][2][80] = new Listen(QuestCode.A110280);
            Handler[11][2][81] = new Listen(QuestCode.A110281);
            Handler[11][2][82] = new Listen(QuestCode.A110282);
            Handler[11][2][83] = new Listen(QuestCode.A110283);
            Handler[11][2][84] = new Listen(QuestCode.A110284);
            Handler[11][10] = new Listen[44 + 1];
            Handler[11][10][1] = new Listen(QuestCode.A111001);
            Handler[11][10][4] = new Listen(QuestCode.A111004);
            Handler[11][10][6] = new Listen(QuestCode.A111006);
            Handler[11][10][8] = new Listen(QuestCode.A111008);
            Handler[11][10][10] = new Listen(QuestCode.A111010);
            Handler[11][10][11] = new Listen(QuestCode.A111011);
            Handler[11][10][12] = new Listen(QuestCode.A111012);
            Handler[11][10][15] = new Listen(QuestCode.A111015);
            Handler[11][10][44] = new Listen(QuestCode.A111044);
            Handler[11][20] = new Listen[15 + 1];
            Handler[11][20][1] = new Listen(QuestCode.A112001);
            Handler[11][20][4] = new Listen(QuestCode.A112004);
            Handler[11][20][6] = new Listen(QuestCode.A112006);
            Handler[11][20][8] = new Listen(QuestCode.A112008);
            Handler[11][20][10] = new Listen(QuestCode.A112010);
            Handler[11][20][11] = new Listen(QuestCode.A112011);
            Handler[11][20][12] = new Listen(QuestCode.A112012);
            Handler[11][20][15] = new Listen(QuestCode.A112015);
            Handler[11][30] = new Listen[15 + 1];
            Handler[11][30][1] = new Listen(QuestCode.A113001);
            Handler[11][30][4] = new Listen(QuestCode.A113004);
            Handler[11][30][6] = new Listen(QuestCode.A113006);
            Handler[11][30][8] = new Listen(QuestCode.A113008);
            Handler[11][30][10] = new Listen(QuestCode.A113010);
            Handler[11][30][11] = new Listen(QuestCode.A113011);
            Handler[11][30][12] = new Listen(QuestCode.A113012);
            Handler[11][30][15] = new Listen(QuestCode.A113015);
            Handler[11][90] = new Listen[25 + 1];
            Handler[11][90][1] = new Listen(QuestCode.A119001);
            Handler[11][90][2] = new Listen(QuestCode.A119002);
            Handler[11][90][3] = new Listen(QuestCode.A119003);
            Handler[11][90][4] = new Listen(QuestCode.A119004);
            Handler[11][90][5] = new Listen(QuestCode.A119005);
            Handler[11][90][6] = new Listen(QuestCode.A119006);
            Handler[11][90][7] = new Listen(QuestCode.A119007);
            Handler[11][90][9] = new Listen(QuestCode.A119009);
            Handler[11][90][10] = new Listen(QuestCode.A119010);
            Handler[11][90][11] = new Listen(QuestCode.A119011);
            Handler[11][90][12] = new Listen(QuestCode.A119012);
            Handler[11][90][13] = new Listen(QuestCode.A119013);
            Handler[11][90][14] = new Listen(QuestCode.A119014);
            Handler[11][90][16] = new Listen(QuestCode.A119016);
            Handler[11][90][17] = new Listen(QuestCode.A119017);
            Handler[11][90][18] = new Listen(QuestCode.A119018);
            Handler[11][90][20] = new Listen(QuestCode.A119020);
            Handler[11][90][21] = new Listen(QuestCode.A119021);
            Handler[11][90][22] = new Listen(QuestCode.A119022);
            Handler[11][90][23] = new Listen(QuestCode.A119023);
            Handler[11][90][24] = new Listen(QuestCode.A119024);
            Handler[11][90][25] = new Listen(QuestCode.A119025);


            Handler[12] = new Listen[90 + 1][];
            Handler[12][0] = new Listen[99 + 1];
            Handler[12][0][4] = new Listen(QuestCode.A120004);
            Handler[12][0][22] = new Listen(QuestCode.A120022);
            Handler[12][0][27] = new Listen(QuestCode.A120027);
            Handler[12][0][28] = new Listen(QuestCode.A120028);
            Handler[12][0][29] = new Listen(QuestCode.A120029);
            Handler[12][0][30] = new Listen(QuestCode.A120030);
            Handler[12][0][31] = new Listen(QuestCode.A120031);
            Handler[12][0][35] = new Listen(QuestCode.A120035);
            Handler[12][0][36] = new Listen(QuestCode.A120036);
            Handler[12][0][37] = new Listen(QuestCode.A120037);
            Handler[12][0][38] = new Listen(QuestCode.A120038);
            Handler[12][0][39] = new Listen(QuestCode.A120039);
            Handler[12][0][40] = new Listen(QuestCode.A120040);
            Handler[12][0][58] = new Listen(QuestCode.A120058);
            Handler[12][0][59] = new Listen(QuestCode.A120059);
            Handler[12][0][60] = new Listen(QuestCode.A120060);
            Handler[12][0][61] = new Listen(QuestCode.A120061);
            Handler[12][0][62] = new Listen(QuestCode.A120062);
            Handler[12][0][63] = new Listen(QuestCode.A120063);
            Handler[12][0][64] = new Listen(QuestCode.A120064);
            Handler[12][0][65] = new Listen(QuestCode.A120065);
            Handler[12][0][66] = new Listen(QuestCode.A120066);
            Handler[12][0][67] = new Listen(QuestCode.A120067);
            Handler[12][0][68] = new Listen(QuestCode.A120068);
            Handler[12][0][69] = new Listen(QuestCode.A120069);
            Handler[12][0][70] = new Listen(QuestCode.A120070);
            Handler[12][0][71] = new Listen(QuestCode.A120071);
            Handler[12][0][72] = new Listen(QuestCode.A120072);
            Handler[12][0][73] = new Listen(QuestCode.A120073);
            Handler[12][0][74] = new Listen(QuestCode.A120074);
            Handler[12][0][75] = new Listen(QuestCode.A120075);
            Handler[12][0][76] = new Listen(QuestCode.A120076);
            Handler[12][0][77] = new Listen(QuestCode.A120077);
            Handler[12][0][78] = new Listen(QuestCode.A120078);
            Handler[12][0][79] = new Listen(QuestCode.A120079);
            Handler[12][0][80] = new Listen(QuestCode.A120080);
            Handler[12][0][81] = new Listen(QuestCode.A120081);
            Handler[12][0][85] = new Listen(QuestCode.A120085);
            Handler[12][0][86] = new Listen(QuestCode.A120086);
            Handler[12][0][87] = new Listen(QuestCode.A120087);
            Handler[12][0][88] = new Listen(QuestCode.A120088);
            Handler[12][0][89] = new Listen(QuestCode.A120089);
            Handler[12][0][90] = new Listen(QuestCode.A120090);
            Handler[12][0][91] = new Listen(QuestCode.A120091);
            Handler[12][0][92] = new Listen(QuestCode.A120092);
            Handler[12][0][93] = new Listen(QuestCode.A120093);
            Handler[12][0][94] = new Listen(QuestCode.A120094);
            Handler[12][0][95] = new Listen(QuestCode.A120095);
            Handler[12][0][96] = new Listen(QuestCode.A120096);
            Handler[12][0][97] = new Listen(QuestCode.A120097);
            Handler[12][0][98] = new Listen(QuestCode.A120098);
            Handler[12][0][99] = new Listen(QuestCode.A120099);
            Handler[12][1] = new Listen[99 + 1];
            Handler[12][1][0] = new Listen(QuestCode.A120100);
            Handler[12][1][1] = new Listen(QuestCode.A120101);
            Handler[12][1][2] = new Listen(QuestCode.A120102);
            Handler[12][1][3] = new Listen(QuestCode.A120103);
            Handler[12][1][4] = new Listen(QuestCode.A120104);
            Handler[12][1][5] = new Listen(QuestCode.A120105);
            Handler[12][1][6] = new Listen(QuestCode.A120106);
            Handler[12][1][7] = new Listen(QuestCode.A120107);
            Handler[12][1][8] = new Listen(QuestCode.A120108);
            Handler[12][1][9] = new Listen(QuestCode.A120109);
            Handler[12][1][10] = new Listen(QuestCode.A120110);
            Handler[12][1][11] = new Listen(QuestCode.A120111);
            Handler[12][1][12] = new Listen(QuestCode.A120112);
            Handler[12][1][13] = new Listen(QuestCode.A120113);
            Handler[12][1][14] = new Listen(QuestCode.A120114);
            Handler[12][1][15] = new Listen(QuestCode.A120115);
            Handler[12][1][16] = new Listen(QuestCode.A120116);
            Handler[12][1][17] = new Listen(QuestCode.A120117);
            Handler[12][1][18] = new Listen(QuestCode.A120118);
            Handler[12][1][19] = new Listen(QuestCode.A120119);
            Handler[12][1][20] = new Listen(QuestCode.A120120);
            Handler[12][1][21] = new Listen(QuestCode.A120121);
            Handler[12][1][22] = new Listen(QuestCode.A120122);
            Handler[12][1][23] = new Listen(QuestCode.A120123);
            Handler[12][1][24] = new Listen(QuestCode.A120124);
            Handler[12][1][25] = new Listen(QuestCode.A120125);
            Handler[12][1][26] = new Listen(QuestCode.A120126);
            Handler[12][1][27] = new Listen(QuestCode.A120127);
            Handler[12][1][28] = new Listen(QuestCode.A120128);
            Handler[12][1][29] = new Listen(QuestCode.A120129);
            Handler[12][1][30] = new Listen(QuestCode.A120130);
            Handler[12][1][31] = new Listen(QuestCode.A120131);
            Handler[12][1][32] = new Listen(QuestCode.A120132);
            Handler[12][1][33] = new Listen(QuestCode.A120133);
            Handler[12][1][34] = new Listen(QuestCode.A120134);
            Handler[12][1][35] = new Listen(QuestCode.A120135);
            Handler[12][1][36] = new Listen(QuestCode.A120136);
            Handler[12][1][37] = new Listen(QuestCode.A120137);
            Handler[12][1][38] = new Listen(QuestCode.A120138);
            Handler[12][1][39] = new Listen(QuestCode.A120139);
            Handler[12][1][40] = new Listen(QuestCode.A120140);
            Handler[12][1][41] = new Listen(QuestCode.A120141);
            Handler[12][1][42] = new Listen(QuestCode.A120142);
            Handler[12][1][43] = new Listen(QuestCode.A120143);
            Handler[12][1][44] = new Listen(QuestCode.A120144);
            Handler[12][1][45] = new Listen(QuestCode.A120145);
            Handler[12][1][46] = new Listen(QuestCode.A120146);
            Handler[12][1][47] = new Listen(QuestCode.A120147);
            Handler[12][1][48] = new Listen(QuestCode.A120148);
            Handler[12][1][49] = new Listen(QuestCode.A120149);
            Handler[12][1][50] = new Listen(QuestCode.A120150);
            Handler[12][1][51] = new Listen(QuestCode.A120151);
            Handler[12][1][52] = new Listen(QuestCode.A120152);
            Handler[12][1][53] = new Listen(QuestCode.A120153);
            Handler[12][1][54] = new Listen(QuestCode.A120154);
            Handler[12][1][55] = new Listen(QuestCode.A120155);
            Handler[12][1][56] = new Listen(QuestCode.A120156);
            Handler[12][1][57] = new Listen(QuestCode.A120157);
            Handler[12][1][58] = new Listen(QuestCode.A120158);
            Handler[12][1][59] = new Listen(QuestCode.A120159);
            Handler[12][1][60] = new Listen(QuestCode.A120160);
            Handler[12][1][61] = new Listen(QuestCode.A120161);
            Handler[12][1][62] = new Listen(QuestCode.A120162);
            Handler[12][1][63] = new Listen(QuestCode.A120163);
            Handler[12][1][64] = new Listen(QuestCode.A120164);
            Handler[12][1][65] = new Listen(QuestCode.A120165);
            Handler[12][1][66] = new Listen(QuestCode.A120166);
            Handler[12][1][67] = new Listen(QuestCode.A120167);
            Handler[12][1][68] = new Listen(QuestCode.A120168);
            Handler[12][1][69] = new Listen(QuestCode.A120169);
            Handler[12][1][70] = new Listen(QuestCode.A120170);
            Handler[12][1][71] = new Listen(QuestCode.A120171);
            Handler[12][1][72] = new Listen(QuestCode.A120172);
            Handler[12][1][73] = new Listen(QuestCode.A120173);
            Handler[12][1][74] = new Listen(QuestCode.A120174);
            Handler[12][1][75] = new Listen(QuestCode.A120175);
            Handler[12][1][76] = new Listen(QuestCode.A120176);
            Handler[12][1][77] = new Listen(QuestCode.A120177);
            Handler[12][1][78] = new Listen(QuestCode.A120178);
            Handler[12][1][79] = new Listen(QuestCode.A120179);
            Handler[12][1][80] = new Listen(QuestCode.A120180);
            Handler[12][1][81] = new Listen(QuestCode.A120181);
            Handler[12][1][82] = new Listen(QuestCode.A120182);
            Handler[12][1][83] = new Listen(QuestCode.A120183);
            Handler[12][1][84] = new Listen(QuestCode.A120184);
            Handler[12][1][85] = new Listen(QuestCode.A120185);
            Handler[12][1][86] = new Listen(QuestCode.A120186);
            Handler[12][1][87] = new Listen(QuestCode.A120187);
            Handler[12][1][88] = new Listen(QuestCode.A120188);
            Handler[12][1][89] = new Listen(QuestCode.A120189);
            Handler[12][1][90] = new Listen(QuestCode.A120190);
            Handler[12][1][91] = new Listen(QuestCode.A120191);
            Handler[12][1][92] = new Listen(QuestCode.A120192);
            Handler[12][1][93] = new Listen(QuestCode.A120193);
            Handler[12][1][94] = new Listen(QuestCode.A120194);
            Handler[12][1][95] = new Listen(QuestCode.A120195);
            Handler[12][1][96] = new Listen(QuestCode.A120196);
            Handler[12][1][97] = new Listen(QuestCode.A120197);
            Handler[12][1][98] = new Listen(QuestCode.A120198);
            Handler[12][1][99] = new Listen(QuestCode.A120199);
            Handler[12][2] = new Listen[43 + 1];
            Handler[12][2][0] = new Listen(QuestCode.A120200);
            Handler[12][2][1] = new Listen(QuestCode.A120201);
            Handler[12][2][2] = new Listen(QuestCode.A120202);
            Handler[12][2][3] = new Listen(QuestCode.A120203);
            Handler[12][2][4] = new Listen(QuestCode.A120204);
            Handler[12][2][5] = new Listen(QuestCode.A120205);
            Handler[12][2][6] = new Listen(QuestCode.A120206);
            Handler[12][2][7] = new Listen(QuestCode.A120207);
            Handler[12][2][8] = new Listen(QuestCode.A120208);
            Handler[12][2][9] = new Listen(QuestCode.A120209);
            Handler[12][2][10] = new Listen(QuestCode.A120210);
            Handler[12][2][11] = new Listen(QuestCode.A120211);
            Handler[12][2][12] = new Listen(QuestCode.A120212);
            Handler[12][2][13] = new Listen(QuestCode.A120213);
            Handler[12][2][14] = new Listen(QuestCode.A120214);
            Handler[12][2][15] = new Listen(QuestCode.A120215);
            Handler[12][2][16] = new Listen(QuestCode.A120216);
            Handler[12][2][17] = new Listen(QuestCode.A120217);
            Handler[12][2][18] = new Listen(QuestCode.A120218);
            Handler[12][2][19] = new Listen(QuestCode.A120219);
            Handler[12][2][20] = new Listen(QuestCode.A120220);
            Handler[12][2][21] = new Listen(QuestCode.A120221);
            Handler[12][2][22] = new Listen(QuestCode.A120222);
            Handler[12][2][23] = new Listen(QuestCode.A120223);
            Handler[12][2][24] = new Listen(QuestCode.A120224);
            Handler[12][2][25] = new Listen(QuestCode.A120225);
            Handler[12][2][26] = new Listen(QuestCode.A120226);
            Handler[12][2][27] = new Listen(QuestCode.A120227);
            Handler[12][2][28] = new Listen(QuestCode.A120228);
            Handler[12][2][29] = new Listen(QuestCode.A120229);
            Handler[12][2][30] = new Listen(QuestCode.A120230);
            Handler[12][2][31] = new Listen(QuestCode.A120231);
            Handler[12][2][32] = new Listen(QuestCode.A120232);
            Handler[12][2][33] = new Listen(QuestCode.A120233);
            Handler[12][2][34] = new Listen(QuestCode.A120234);
            Handler[12][2][35] = new Listen(QuestCode.A120235);
            Handler[12][2][36] = new Listen(QuestCode.A120236);
            Handler[12][2][37] = new Listen(QuestCode.A120237);
            Handler[12][2][38] = new Listen(QuestCode.A120238);
            Handler[12][2][39] = new Listen(QuestCode.A120239);
            Handler[12][2][40] = new Listen(QuestCode.A120240);
            Handler[12][2][41] = new Listen(QuestCode.A120241);
            Handler[12][2][42] = new Listen(QuestCode.A120242);
            Handler[12][2][43] = new Listen(QuestCode.A120243);
            Handler[12][90] = new Listen[19 + 1];
            Handler[12][90][1] = new Listen(QuestCode.A129001);
            Handler[12][90][2] = new Listen(QuestCode.A129002);
            Handler[12][90][4] = new Listen(QuestCode.A129004);
            Handler[12][90][11] = new Listen(QuestCode.A129011);
            Handler[12][90][16] = new Listen(QuestCode.A129016);
            Handler[12][90][17] = new Listen(QuestCode.A129017);
            Handler[12][90][19] = new Listen(QuestCode.A129019);


            Handler[13] = new Listen[2 + 1][];
            Handler[13][0] = new Listen[91 + 1];
            Handler[13][0][1] = new Listen(QuestCode.A130001);
            Handler[13][0][2] = new Listen(QuestCode.A130002);
            Handler[13][0][3] = new Listen(QuestCode.A130003);
            Handler[13][0][5] = new Listen(QuestCode.A130005);
            Handler[13][0][6] = new Listen(QuestCode.A130006);
            Handler[13][0][7] = new Listen(QuestCode.A130007);
            Handler[13][0][9] = new Listen(QuestCode.A130009);
            Handler[13][0][10] = new Listen(QuestCode.A130010);
            Handler[13][0][11] = new Listen(QuestCode.A130011);
            Handler[13][0][22] = new Listen(QuestCode.A130022);
            Handler[13][0][23] = new Listen(QuestCode.A130023);
            Handler[13][0][24] = new Listen(QuestCode.A130024);
            Handler[13][0][54] = new Listen(QuestCode.A130054);
            Handler[13][0][55] = new Listen(QuestCode.A130055);
            Handler[13][0][56] = new Listen(QuestCode.A130056);
            Handler[13][0][57] = new Listen(QuestCode.A130057);
            Handler[13][0][58] = new Listen(QuestCode.A130058);
            Handler[13][0][59] = new Listen(QuestCode.A130059);
            Handler[13][0][60] = new Listen(QuestCode.A130060);
            Handler[13][0][61] = new Listen(QuestCode.A130061);
            Handler[13][0][62] = new Listen(QuestCode.A130062);
            Handler[13][0][63] = new Listen(QuestCode.A130063);
            Handler[13][0][73] = new Listen(QuestCode.A130073);
            Handler[13][0][74] = new Listen(QuestCode.A130074);
            Handler[13][0][75] = new Listen(QuestCode.A130075);
            Handler[13][0][76] = new Listen(QuestCode.A130076);
            Handler[13][0][77] = new Listen(QuestCode.A130077);
            Handler[13][0][78] = new Listen(QuestCode.A130078);
            Handler[13][0][79] = new Listen(QuestCode.A130079);
            Handler[13][0][80] = new Listen(QuestCode.A130080);
            Handler[13][0][81] = new Listen(QuestCode.A130081);
            Handler[13][0][82] = new Listen(QuestCode.A130082);
            Handler[13][0][83] = new Listen(QuestCode.A130083);
            Handler[13][0][84] = new Listen(QuestCode.A130084);
            Handler[13][0][85] = new Listen(QuestCode.A130085);
            Handler[13][0][86] = new Listen(QuestCode.A130086);
            Handler[13][0][87] = new Listen(QuestCode.A130087);
            Handler[13][0][88] = new Listen(QuestCode.A130088);
            Handler[13][0][89] = new Listen(QuestCode.A130089);
            Handler[13][0][90] = new Listen(QuestCode.A130090);
            Handler[13][0][91] = new Listen(QuestCode.A130091);
            Handler[13][1] = new Listen[99 + 1];
            Handler[13][1][1] = new Listen(QuestCode.A130101);
            Handler[13][1][2] = new Listen(QuestCode.A130102);
            Handler[13][1][3] = new Listen(QuestCode.A130103);
            Handler[13][1][4] = new Listen(QuestCode.A130104);
            Handler[13][1][5] = new Listen(QuestCode.A130105);
            Handler[13][1][6] = new Listen(QuestCode.A130106);
            Handler[13][1][7] = new Listen(QuestCode.A130107);
            Handler[13][1][8] = new Listen(QuestCode.A130108);
            Handler[13][1][9] = new Listen(QuestCode.A130109);
            Handler[13][1][10] = new Listen(QuestCode.A130110);
            Handler[13][1][11] = new Listen(QuestCode.A130111);
            Handler[13][1][12] = new Listen(QuestCode.A130112);
            Handler[13][1][14] = new Listen(QuestCode.A130114);
            Handler[13][1][15] = new Listen(QuestCode.A130115);
            Handler[13][1][16] = new Listen(QuestCode.A130116);
            Handler[13][1][17] = new Listen(QuestCode.A130117);
            Handler[13][1][18] = new Listen(QuestCode.A130118);
            Handler[13][1][19] = new Listen(QuestCode.A130119);
            Handler[13][1][20] = new Listen(QuestCode.A130120);
            Handler[13][1][21] = new Listen(QuestCode.A130121);
            Handler[13][1][22] = new Listen(QuestCode.A130122);
            Handler[13][1][23] = new Listen(QuestCode.A130123);
            Handler[13][1][24] = new Listen(QuestCode.A130124);
            Handler[13][1][25] = new Listen(QuestCode.A130125);
            Handler[13][1][26] = new Listen(QuestCode.A130126);
            Handler[13][1][27] = new Listen(QuestCode.A130127);
            Handler[13][1][28] = new Listen(QuestCode.A130128);
            Handler[13][1][29] = new Listen(QuestCode.A130129);
            Handler[13][1][30] = new Listen(QuestCode.A130130);
            Handler[13][1][31] = new Listen(QuestCode.A130131);
            Handler[13][1][32] = new Listen(QuestCode.A130132);
            Handler[13][1][36] = new Listen(QuestCode.A130136);
            Handler[13][1][37] = new Listen(QuestCode.A130137);
            Handler[13][1][38] = new Listen(QuestCode.A130138);
            Handler[13][1][39] = new Listen(QuestCode.A130139);
            Handler[13][1][40] = new Listen(QuestCode.A130140);
            Handler[13][1][41] = new Listen(QuestCode.A130141);
            Handler[13][1][42] = new Listen(QuestCode.A130142);
            Handler[13][1][43] = new Listen(QuestCode.A130143);
            Handler[13][1][44] = new Listen(QuestCode.A130144);
            Handler[13][1][45] = new Listen(QuestCode.A130145);
            Handler[13][1][46] = new Listen(QuestCode.A130146);
            Handler[13][1][47] = new Listen(QuestCode.A130147);
            Handler[13][1][48] = new Listen(QuestCode.A130148);
            Handler[13][1][49] = new Listen(QuestCode.A130149);
            Handler[13][1][50] = new Listen(QuestCode.A130150);
            Handler[13][1][51] = new Listen(QuestCode.A130151);
            Handler[13][1][52] = new Listen(QuestCode.A130152);
            Handler[13][1][53] = new Listen(QuestCode.A130153);
            Handler[13][1][54] = new Listen(QuestCode.A130154);
            Handler[13][1][55] = new Listen(QuestCode.A130155);
            Handler[13][1][56] = new Listen(QuestCode.A130156);
            Handler[13][1][57] = new Listen(QuestCode.A130157);
            Handler[13][1][58] = new Listen(QuestCode.A130158);
            Handler[13][1][59] = new Listen(QuestCode.A130159);
            Handler[13][1][60] = new Listen(QuestCode.A130160);
            Handler[13][1][61] = new Listen(QuestCode.A130161);
            Handler[13][1][62] = new Listen(QuestCode.A130162);
            Handler[13][1][63] = new Listen(QuestCode.A130163);
            Handler[13][1][64] = new Listen(QuestCode.A130164);
            Handler[13][1][65] = new Listen(QuestCode.A130165);
            Handler[13][1][66] = new Listen(QuestCode.A130166);
            Handler[13][1][67] = new Listen(QuestCode.A130167);
            Handler[13][1][68] = new Listen(QuestCode.A130168);
            Handler[13][1][69] = new Listen(QuestCode.A130169);
            Handler[13][1][70] = new Listen(QuestCode.A130170);
            Handler[13][1][71] = new Listen(QuestCode.A130171);
            Handler[13][1][72] = new Listen(QuestCode.A130172);
            Handler[13][1][73] = new Listen(QuestCode.A130173);
            Handler[13][1][74] = new Listen(QuestCode.A130174);
            Handler[13][1][75] = new Listen(QuestCode.A130175);
            Handler[13][1][76] = new Listen(QuestCode.A130176);
            Handler[13][1][77] = new Listen(QuestCode.A130177);
            Handler[13][1][78] = new Listen(QuestCode.A130178);
            Handler[13][1][79] = new Listen(QuestCode.A130179);
            Handler[13][1][80] = new Listen(QuestCode.A130180);
            Handler[13][1][81] = new Listen(QuestCode.A130181);
            Handler[13][1][82] = new Listen(QuestCode.A130182);
            Handler[13][1][83] = new Listen(QuestCode.A130183);
            Handler[13][1][84] = new Listen(QuestCode.A130184);
            Handler[13][1][85] = new Listen(QuestCode.A130185);
            Handler[13][1][86] = new Listen(QuestCode.A130186);
            Handler[13][1][88] = new Listen(QuestCode.A130188);
            Handler[13][1][89] = new Listen(QuestCode.A130189);
            Handler[13][1][90] = new Listen(QuestCode.A130190);
            Handler[13][1][91] = new Listen(QuestCode.A130191);
            Handler[13][1][92] = new Listen(QuestCode.A130192);
            Handler[13][1][93] = new Listen(QuestCode.A130193);
            Handler[13][1][94] = new Listen(QuestCode.A130194);
            Handler[13][1][95] = new Listen(QuestCode.A130195);
            Handler[13][1][96] = new Listen(QuestCode.A130196);
            Handler[13][1][97] = new Listen(QuestCode.A130197);
            Handler[13][1][98] = new Listen(QuestCode.A130198);
            Handler[13][1][99] = new Listen(QuestCode.A130199);
            Handler[13][2] = new Listen[10 + 1];
            Handler[13][2][0] = new Listen(QuestCode.A130200);
            Handler[13][2][1] = new Listen(QuestCode.A130201);
            Handler[13][2][2] = new Listen(QuestCode.A130202);
            Handler[13][2][3] = new Listen(QuestCode.A130203);
            Handler[13][2][4] = new Listen(QuestCode.A130204);
            Handler[13][2][5] = new Listen(QuestCode.A130205);
            Handler[13][2][6] = new Listen(QuestCode.A130206);
            Handler[13][2][7] = new Listen(QuestCode.A130207);
            Handler[13][2][8] = new Listen(QuestCode.A130208);
            Handler[13][2][9] = new Listen(QuestCode.A130209);
            Handler[13][2][10] = new Listen(QuestCode.A130210);


            Handler[14] = new Listen[10 + 1][];
            Handler[14][1] = new Listen[9 + 1];
            Handler[14][1][2] = new Listen(QuestCode.A140102);
            Handler[14][1][3] = new Listen(QuestCode.A140103);
            Handler[14][1][4] = new Listen(QuestCode.A140104);
            Handler[14][1][5] = new Listen(QuestCode.A140105);
            Handler[14][1][6] = new Listen(QuestCode.A140106);
            Handler[14][1][7] = new Listen(QuestCode.A140107);
            Handler[14][1][8] = new Listen(QuestCode.A140108);
            Handler[14][1][9] = new Listen(QuestCode.A140109);
            Handler[14][2] = new Listen[40 + 1];
            Handler[14][2][6] = new Listen(QuestCode.A140206);
            Handler[14][2][7] = new Listen(QuestCode.A140207);
            Handler[14][2][8] = new Listen(QuestCode.A140208);
            Handler[14][2][9] = new Listen(QuestCode.A140209);
            Handler[14][2][11] = new Listen(QuestCode.A140211);
            Handler[14][2][12] = new Listen(QuestCode.A140212);
            Handler[14][2][13] = new Listen(QuestCode.A140213);
            Handler[14][2][14] = new Listen(QuestCode.A140214);
            Handler[14][2][16] = new Listen(QuestCode.A140216);
            Handler[14][2][17] = new Listen(QuestCode.A140217);
            Handler[14][2][18] = new Listen(QuestCode.A140218);
            Handler[14][2][19] = new Listen(QuestCode.A140219);
            Handler[14][2][21] = new Listen(QuestCode.A140221);
            Handler[14][2][22] = new Listen(QuestCode.A140222);
            Handler[14][2][23] = new Listen(QuestCode.A140223);
            Handler[14][2][24] = new Listen(QuestCode.A140224);
            Handler[14][2][25] = new Listen(QuestCode.A140225);
            Handler[14][2][26] = new Listen(QuestCode.A140226);
            Handler[14][2][27] = new Listen(QuestCode.A140227);
            Handler[14][2][28] = new Listen(QuestCode.A140228);
            Handler[14][2][29] = new Listen(QuestCode.A140229);
            Handler[14][2][30] = new Listen(QuestCode.A140230);
            Handler[14][2][31] = new Listen(QuestCode.A140231);
            Handler[14][2][32] = new Listen(QuestCode.A140232);
            Handler[14][2][33] = new Listen(QuestCode.A140233);
            Handler[14][2][34] = new Listen(QuestCode.A140234);
            Handler[14][2][35] = new Listen(QuestCode.A140235);
            Handler[14][2][36] = new Listen(QuestCode.A140236);
            Handler[14][2][37] = new Listen(QuestCode.A140237);
            Handler[14][2][38] = new Listen(QuestCode.A140238);
            Handler[14][2][39] = new Listen(QuestCode.A140239);
            Handler[14][2][40] = new Listen(QuestCode.A140240);
            Handler[14][3] = new Listen[84 + 1];
            Handler[14][3][9] = new Listen(QuestCode.A140309);
            Handler[14][3][10] = new Listen(QuestCode.A140310);
            Handler[14][3][11] = new Listen(QuestCode.A140311);
            Handler[14][3][12] = new Listen(QuestCode.A140312);
            Handler[14][3][13] = new Listen(QuestCode.A140313);
            Handler[14][3][14] = new Listen(QuestCode.A140314);
            Handler[14][3][15] = new Listen(QuestCode.A140315);
            Handler[14][3][16] = new Listen(QuestCode.A140316);
            Handler[14][3][17] = new Listen(QuestCode.A140317);
            Handler[14][3][18] = new Listen(QuestCode.A140318);
            Handler[14][3][19] = new Listen(QuestCode.A140319);
            Handler[14][3][22] = new Listen(QuestCode.A140322);
            Handler[14][3][23] = new Listen(QuestCode.A140323);
            Handler[14][3][24] = new Listen(QuestCode.A140324);
            Handler[14][3][25] = new Listen(QuestCode.A140325);
            Handler[14][3][26] = new Listen(QuestCode.A140326);
            Handler[14][3][27] = new Listen(QuestCode.A140327);
            Handler[14][3][28] = new Listen(QuestCode.A140328);
            Handler[14][3][29] = new Listen(QuestCode.A140329);
            Handler[14][3][30] = new Listen(QuestCode.A140330);
            Handler[14][3][31] = new Listen(QuestCode.A140331);
            Handler[14][3][32] = new Listen(QuestCode.A140332);
            Handler[14][3][35] = new Listen(QuestCode.A140335);
            Handler[14][3][36] = new Listen(QuestCode.A140336);
            Handler[14][3][37] = new Listen(QuestCode.A140337);
            Handler[14][3][38] = new Listen(QuestCode.A140338);
            Handler[14][3][39] = new Listen(QuestCode.A140339);
            Handler[14][3][40] = new Listen(QuestCode.A140340);
            Handler[14][3][41] = new Listen(QuestCode.A140341);
            Handler[14][3][42] = new Listen(QuestCode.A140342);
            Handler[14][3][43] = new Listen(QuestCode.A140343);
            Handler[14][3][46] = new Listen(QuestCode.A140346);
            Handler[14][3][47] = new Listen(QuestCode.A140347);
            Handler[14][3][48] = new Listen(QuestCode.A140348);
            Handler[14][3][49] = new Listen(QuestCode.A140349);
            Handler[14][3][50] = new Listen(QuestCode.A140350);
            Handler[14][3][51] = new Listen(QuestCode.A140351);
            Handler[14][3][52] = new Listen(QuestCode.A140352);
            Handler[14][3][53] = new Listen(QuestCode.A140353);
            Handler[14][3][54] = new Listen(QuestCode.A140354);
            Handler[14][3][55] = new Listen(QuestCode.A140355);
            Handler[14][3][56] = new Listen(QuestCode.A140356);
            Handler[14][3][57] = new Listen(QuestCode.A140357);
            Handler[14][3][58] = new Listen(QuestCode.A140358);
            Handler[14][3][59] = new Listen(QuestCode.A140359);
            Handler[14][3][60] = new Listen(QuestCode.A140360);
            Handler[14][3][61] = new Listen(QuestCode.A140361);
            Handler[14][3][62] = new Listen(QuestCode.A140362);
            Handler[14][3][63] = new Listen(QuestCode.A140363);
            Handler[14][3][64] = new Listen(QuestCode.A140364);
            Handler[14][3][65] = new Listen(QuestCode.A140365);
            Handler[14][3][66] = new Listen(QuestCode.A140366);
            Handler[14][3][67] = new Listen(QuestCode.A140367);
            Handler[14][3][68] = new Listen(QuestCode.A140368);
            Handler[14][3][69] = new Listen(QuestCode.A140369);
            Handler[14][3][70] = new Listen(QuestCode.A140370);
            Handler[14][3][71] = new Listen(QuestCode.A140371);
            Handler[14][3][72] = new Listen(QuestCode.A140372);
            Handler[14][3][73] = new Listen(QuestCode.A140373);
            Handler[14][3][74] = new Listen(QuestCode.A140374);
            Handler[14][3][75] = new Listen(QuestCode.A140375);
            Handler[14][3][76] = new Listen(QuestCode.A140376);
            Handler[14][3][77] = new Listen(QuestCode.A140377);
            Handler[14][3][78] = new Listen(QuestCode.A140378);
            Handler[14][3][79] = new Listen(QuestCode.A140379);
            Handler[14][3][80] = new Listen(QuestCode.A140380);
            Handler[14][3][81] = new Listen(QuestCode.A140381);
            Handler[14][3][82] = new Listen(QuestCode.A140382);
            Handler[14][3][83] = new Listen(QuestCode.A140383);
            Handler[14][3][84] = new Listen(QuestCode.A140384);
            Handler[14][4] = new Listen[40 + 1];
            Handler[14][4][6] = new Listen(QuestCode.A140406);
            Handler[14][4][7] = new Listen(QuestCode.A140407);
            Handler[14][4][8] = new Listen(QuestCode.A140408);
            Handler[14][4][9] = new Listen(QuestCode.A140409);
            Handler[14][4][11] = new Listen(QuestCode.A140411);
            Handler[14][4][12] = new Listen(QuestCode.A140412);
            Handler[14][4][13] = new Listen(QuestCode.A140413);
            Handler[14][4][14] = new Listen(QuestCode.A140414);
            Handler[14][4][16] = new Listen(QuestCode.A140416);
            Handler[14][4][17] = new Listen(QuestCode.A140417);
            Handler[14][4][18] = new Listen(QuestCode.A140418);
            Handler[14][4][19] = new Listen(QuestCode.A140419);
            Handler[14][4][21] = new Listen(QuestCode.A140421);
            Handler[14][4][22] = new Listen(QuestCode.A140422);
            Handler[14][4][23] = new Listen(QuestCode.A140423);
            Handler[14][4][24] = new Listen(QuestCode.A140424);
            Handler[14][4][25] = new Listen(QuestCode.A140425);
            Handler[14][4][26] = new Listen(QuestCode.A140426);
            Handler[14][4][27] = new Listen(QuestCode.A140427);
            Handler[14][4][28] = new Listen(QuestCode.A140428);
            Handler[14][4][29] = new Listen(QuestCode.A140429);
            Handler[14][4][30] = new Listen(QuestCode.A140430);
            Handler[14][4][31] = new Listen(QuestCode.A140431);
            Handler[14][4][32] = new Listen(QuestCode.A140432);
            Handler[14][4][33] = new Listen(QuestCode.A140433);
            Handler[14][4][34] = new Listen(QuestCode.A140434);
            Handler[14][4][35] = new Listen(QuestCode.A140435);
            Handler[14][4][36] = new Listen(QuestCode.A140436);
            Handler[14][4][37] = new Listen(QuestCode.A140437);
            Handler[14][4][38] = new Listen(QuestCode.A140438);
            Handler[14][4][39] = new Listen(QuestCode.A140439);
            Handler[14][4][40] = new Listen(QuestCode.A140440);
            Handler[14][5] = new Listen[9 + 1];
            Handler[14][5][2] = new Listen(QuestCode.A140502);
            Handler[14][5][3] = new Listen(QuestCode.A140503);
            Handler[14][5][4] = new Listen(QuestCode.A140504);
            Handler[14][5][5] = new Listen(QuestCode.A140505);
            Handler[14][5][6] = new Listen(QuestCode.A140506);
            Handler[14][5][7] = new Listen(QuestCode.A140507);
            Handler[14][5][8] = new Listen(QuestCode.A140508);
            Handler[14][5][9] = new Listen(QuestCode.A140509);
            Handler[14][6] = new Listen[83 + 1];
            Handler[14][6][9] = new Listen(QuestCode.A140609);
            Handler[14][6][10] = new Listen(QuestCode.A140610);
            Handler[14][6][11] = new Listen(QuestCode.A140611);
            Handler[14][6][12] = new Listen(QuestCode.A140612);
            Handler[14][6][13] = new Listen(QuestCode.A140613);
            Handler[14][6][14] = new Listen(QuestCode.A140614);
            Handler[14][6][15] = new Listen(QuestCode.A140615);
            Handler[14][6][16] = new Listen(QuestCode.A140616);
            Handler[14][6][17] = new Listen(QuestCode.A140617);
            Handler[14][6][18] = new Listen(QuestCode.A140618);
            Handler[14][6][19] = new Listen(QuestCode.A140619);
            Handler[14][6][22] = new Listen(QuestCode.A140622);
            Handler[14][6][23] = new Listen(QuestCode.A140623);
            Handler[14][6][24] = new Listen(QuestCode.A140624);
            Handler[14][6][25] = new Listen(QuestCode.A140625);
            Handler[14][6][26] = new Listen(QuestCode.A140626);
            Handler[14][6][27] = new Listen(QuestCode.A140627);
            Handler[14][6][28] = new Listen(QuestCode.A140628);
            Handler[14][6][29] = new Listen(QuestCode.A140629);
            Handler[14][6][30] = new Listen(QuestCode.A140630);
            Handler[14][6][31] = new Listen(QuestCode.A140631);
            Handler[14][6][32] = new Listen(QuestCode.A140632);
            Handler[14][6][35] = new Listen(QuestCode.A140635);
            Handler[14][6][36] = new Listen(QuestCode.A140636);
            Handler[14][6][37] = new Listen(QuestCode.A140637);
            Handler[14][6][38] = new Listen(QuestCode.A140638);
            Handler[14][6][39] = new Listen(QuestCode.A140639);
            Handler[14][6][40] = new Listen(QuestCode.A140640);
            Handler[14][6][41] = new Listen(QuestCode.A140641);
            Handler[14][6][42] = new Listen(QuestCode.A140642);
            Handler[14][6][43] = new Listen(QuestCode.A140643);
            Handler[14][6][46] = new Listen(QuestCode.A140646);
            Handler[14][6][47] = new Listen(QuestCode.A140647);
            Handler[14][6][48] = new Listen(QuestCode.A140648);
            Handler[14][6][49] = new Listen(QuestCode.A140649);
            Handler[14][6][50] = new Listen(QuestCode.A140650);
            Handler[14][6][51] = new Listen(QuestCode.A140651);
            Handler[14][6][52] = new Listen(QuestCode.A140652);
            Handler[14][6][53] = new Listen(QuestCode.A140653);
            Handler[14][6][54] = new Listen(QuestCode.A140654);
            Handler[14][6][55] = new Listen(QuestCode.A140655);
            Handler[14][6][56] = new Listen(QuestCode.A140656);
            Handler[14][6][57] = new Listen(QuestCode.A140657);
            Handler[14][6][58] = new Listen(QuestCode.A140658);
            Handler[14][6][59] = new Listen(QuestCode.A140659);
            Handler[14][6][60] = new Listen(QuestCode.A140660);
            Handler[14][6][61] = new Listen(QuestCode.A140661);
            Handler[14][6][62] = new Listen(QuestCode.A140662);
            Handler[14][6][63] = new Listen(QuestCode.A140663);
            Handler[14][6][64] = new Listen(QuestCode.A140664);
            Handler[14][6][65] = new Listen(QuestCode.A140665);
            Handler[14][6][66] = new Listen(QuestCode.A140666);
            Handler[14][6][67] = new Listen(QuestCode.A140667);
            Handler[14][6][68] = new Listen(QuestCode.A140668);
            Handler[14][6][69] = new Listen(QuestCode.A140669);
            Handler[14][6][70] = new Listen(QuestCode.A140670);
            Handler[14][6][71] = new Listen(QuestCode.A140671);
            Handler[14][6][72] = new Listen(QuestCode.A140672);
            Handler[14][6][73] = new Listen(QuestCode.A140673);
            Handler[14][6][74] = new Listen(QuestCode.A140674);
            Handler[14][6][75] = new Listen(QuestCode.A140675);
            Handler[14][6][76] = new Listen(QuestCode.A140676);
            Handler[14][6][77] = new Listen(QuestCode.A140677);
            Handler[14][6][78] = new Listen(QuestCode.A140678);
            Handler[14][6][79] = new Listen(QuestCode.A140679);
            Handler[14][6][80] = new Listen(QuestCode.A140680);
            Handler[14][6][81] = new Listen(QuestCode.A140681);
            Handler[14][6][82] = new Listen(QuestCode.A140682);
            Handler[14][6][83] = new Listen(QuestCode.A140683);
            Handler[14][7] = new Listen[40 + 1];
            Handler[14][7][6] = new Listen(QuestCode.A140706);
            Handler[14][7][7] = new Listen(QuestCode.A140707);
            Handler[14][7][8] = new Listen(QuestCode.A140708);
            Handler[14][7][9] = new Listen(QuestCode.A140709);
            Handler[14][7][11] = new Listen(QuestCode.A140711);
            Handler[14][7][12] = new Listen(QuestCode.A140712);
            Handler[14][7][13] = new Listen(QuestCode.A140713);
            Handler[14][7][14] = new Listen(QuestCode.A140714);
            Handler[14][7][16] = new Listen(QuestCode.A140716);
            Handler[14][7][17] = new Listen(QuestCode.A140717);
            Handler[14][7][18] = new Listen(QuestCode.A140718);
            Handler[14][7][19] = new Listen(QuestCode.A140719);
            Handler[14][7][21] = new Listen(QuestCode.A140721);
            Handler[14][7][22] = new Listen(QuestCode.A140722);
            Handler[14][7][23] = new Listen(QuestCode.A140723);
            Handler[14][7][24] = new Listen(QuestCode.A140724);
            Handler[14][7][25] = new Listen(QuestCode.A140725);
            Handler[14][7][26] = new Listen(QuestCode.A140726);
            Handler[14][7][27] = new Listen(QuestCode.A140727);
            Handler[14][7][28] = new Listen(QuestCode.A140728);
            Handler[14][7][29] = new Listen(QuestCode.A140729);
            Handler[14][7][30] = new Listen(QuestCode.A140730);
            Handler[14][7][31] = new Listen(QuestCode.A140731);
            Handler[14][7][32] = new Listen(QuestCode.A140732);
            Handler[14][7][33] = new Listen(QuestCode.A140733);
            Handler[14][7][34] = new Listen(QuestCode.A140734);
            Handler[14][7][35] = new Listen(QuestCode.A140735);
            Handler[14][7][36] = new Listen(QuestCode.A140736);
            Handler[14][7][37] = new Listen(QuestCode.A140737);
            Handler[14][7][38] = new Listen(QuestCode.A140738);
            Handler[14][7][39] = new Listen(QuestCode.A140739);
            Handler[14][7][40] = new Listen(QuestCode.A140740);
            Handler[14][8] = new Listen[40 + 1];
            Handler[14][8][6] = new Listen(QuestCode.A140806);
            Handler[14][8][7] = new Listen(QuestCode.A140807);
            Handler[14][8][8] = new Listen(QuestCode.A140808);
            Handler[14][8][9] = new Listen(QuestCode.A140809);
            Handler[14][8][11] = new Listen(QuestCode.A140811);
            Handler[14][8][12] = new Listen(QuestCode.A140812);
            Handler[14][8][13] = new Listen(QuestCode.A140813);
            Handler[14][8][14] = new Listen(QuestCode.A140814);
            Handler[14][8][16] = new Listen(QuestCode.A140816);
            Handler[14][8][17] = new Listen(QuestCode.A140817);
            Handler[14][8][18] = new Listen(QuestCode.A140818);
            Handler[14][8][19] = new Listen(QuestCode.A140819);
            Handler[14][8][21] = new Listen(QuestCode.A140821);
            Handler[14][8][22] = new Listen(QuestCode.A140822);
            Handler[14][8][23] = new Listen(QuestCode.A140823);
            Handler[14][8][24] = new Listen(QuestCode.A140824);
            Handler[14][8][25] = new Listen(QuestCode.A140825);
            Handler[14][8][26] = new Listen(QuestCode.A140826);
            Handler[14][8][27] = new Listen(QuestCode.A140827);
            Handler[14][8][28] = new Listen(QuestCode.A140828);
            Handler[14][8][29] = new Listen(QuestCode.A140829);
            Handler[14][8][30] = new Listen(QuestCode.A140830);
            Handler[14][8][31] = new Listen(QuestCode.A140831);
            Handler[14][8][32] = new Listen(QuestCode.A140832);
            Handler[14][8][33] = new Listen(QuestCode.A140833);
            Handler[14][8][34] = new Listen(QuestCode.A140834);
            Handler[14][8][35] = new Listen(QuestCode.A140835);
            Handler[14][8][36] = new Listen(QuestCode.A140836);
            Handler[14][8][37] = new Listen(QuestCode.A140837);
            Handler[14][8][38] = new Listen(QuestCode.A140838);
            Handler[14][8][39] = new Listen(QuestCode.A140839);
            Handler[14][8][40] = new Listen(QuestCode.A140840);
            Handler[14][9] = new Listen[18 + 1];
            Handler[14][9][3] = new Listen(QuestCode.A140903);
            Handler[14][9][4] = new Listen(QuestCode.A140904);
            Handler[14][9][5] = new Listen(QuestCode.A140905);
            Handler[14][9][6] = new Listen(QuestCode.A140906);
            Handler[14][9][7] = new Listen(QuestCode.A140907);
            Handler[14][9][8] = new Listen(QuestCode.A140908);
            Handler[14][9][9] = new Listen(QuestCode.A140909);
            Handler[14][9][10] = new Listen(QuestCode.A140910);
            Handler[14][9][11] = new Listen(QuestCode.A140911);
            Handler[14][9][12] = new Listen(QuestCode.A140912);
            Handler[14][9][13] = new Listen(QuestCode.A140913);
            Handler[14][9][14] = new Listen(QuestCode.A140914);
            Handler[14][9][15] = new Listen(QuestCode.A140915);
            Handler[14][9][16] = new Listen(QuestCode.A140916);
            Handler[14][9][17] = new Listen(QuestCode.A140917);
            Handler[14][9][18] = new Listen(QuestCode.A140918);
            Handler[14][10] = new Listen[9 + 1];
            Handler[14][10][2] = new Listen(QuestCode.A141002);
            Handler[14][10][3] = new Listen(QuestCode.A141003);
            Handler[14][10][4] = new Listen(QuestCode.A141004);
            Handler[14][10][5] = new Listen(QuestCode.A141005);
            Handler[14][10][6] = new Listen(QuestCode.A141006);
            Handler[14][10][7] = new Listen(QuestCode.A141007);
            Handler[14][10][8] = new Listen(QuestCode.A141008);
            Handler[14][10][9] = new Listen(QuestCode.A141009);


            Handler[15] = new Listen[0 + 1][];
            Handler[15][0] = new Listen[47 + 1];
            Handler[15][0][1] = new Listen(QuestCode.A150001);
            Handler[15][0][2] = new Listen(QuestCode.A150002);
            Handler[15][0][3] = new Listen(QuestCode.A150003);
            Handler[15][0][4] = new Listen(QuestCode.A150004);
            Handler[15][0][5] = new Listen(QuestCode.A150005);
            Handler[15][0][6] = new Listen(QuestCode.A150006);
            Handler[15][0][7] = new Listen(QuestCode.A150007);
            Handler[15][0][8] = new Listen(QuestCode.A150008);
            Handler[15][0][9] = new Listen(QuestCode.A150009);
            Handler[15][0][10] = new Listen(QuestCode.A150010);
            Handler[15][0][11] = new Listen(QuestCode.A150011);
            Handler[15][0][12] = new Listen(QuestCode.A150012);
            Handler[15][0][13] = new Listen(QuestCode.A150013);
            Handler[15][0][14] = new Listen(QuestCode.A150014);
            Handler[15][0][15] = new Listen(QuestCode.A150015);
            Handler[15][0][16] = new Listen(QuestCode.A150016);
            Handler[15][0][17] = new Listen(QuestCode.A150017);
            Handler[15][0][18] = new Listen(QuestCode.A150018);
            Handler[15][0][19] = new Listen(QuestCode.A150019);
            Handler[15][0][20] = new Listen(QuestCode.A150020);
            Handler[15][0][21] = new Listen(QuestCode.A150021);
            Handler[15][0][22] = new Listen(QuestCode.A150022);
            Handler[15][0][23] = new Listen(QuestCode.A150023);
            Handler[15][0][24] = new Listen(QuestCode.A150024);
            Handler[15][0][25] = new Listen(QuestCode.A150025);
            Handler[15][0][26] = new Listen(QuestCode.A150026);
            Handler[15][0][27] = new Listen(QuestCode.A150027);
            Handler[15][0][28] = new Listen(QuestCode.A150028);
            Handler[15][0][29] = new Listen(QuestCode.A150029);
            Handler[15][0][30] = new Listen(QuestCode.A150030);
            Handler[15][0][31] = new Listen(QuestCode.A150031);
            Handler[15][0][32] = new Listen(QuestCode.A150032);
            Handler[15][0][33] = new Listen(QuestCode.A150033);
            Handler[15][0][34] = new Listen(QuestCode.A150034);
            Handler[15][0][35] = new Listen(QuestCode.A150035);
            Handler[15][0][36] = new Listen(QuestCode.A150036);
            Handler[15][0][37] = new Listen(QuestCode.A150037);
            Handler[15][0][38] = new Listen(QuestCode.A150038);
            Handler[15][0][39] = new Listen(QuestCode.A150039);
            Handler[15][0][40] = new Listen(QuestCode.A150040);
            Handler[15][0][41] = new Listen(QuestCode.A150041);
            Handler[15][0][42] = new Listen(QuestCode.A150042);
            Handler[15][0][43] = new Listen(QuestCode.A150043);
            Handler[15][0][44] = new Listen(QuestCode.A150044);
            Handler[15][0][45] = new Listen(QuestCode.A150045);
            Handler[15][0][46] = new Listen(QuestCode.A150046);
            Handler[15][0][47] = new Listen(QuestCode.A150047);


          
        }

        internal static byte Parse(ConnectionInfo c, int QuestID)
        {

            string str = QuestID.ToString();
            if (str.Length != 6)
            {
                return 3;
            }

            int c1 = int.Parse(str.Substring(0, 2)),
                c2 = int.Parse(str.Substring(2, 2)),
                c3 = int.Parse(str.Substring(4, 2));


            if (c1 > -1 && c1 < Handler.Length)
            {

                if(c2>-1 && c2< Handler[c1].Length)
                {

                    if (c3 > -1 && c3 < Handler[c1][c2].Length)
                    {

                        byte r=Handler[c1][c2][c3].Invoke(c, QuestID);

                        if (r == 1)
                        {
                            c.Player().quest.RemoveAtask(QuestID);
                        }
                        return r;
                    }


                }

            }

            return 3;
        }

        /*
		internal static byte Parse(ConnectionInfo c,int QuestID)
		{
			switch(QuestID)
			{
				case 100001:
					//Ask Star Sage Halmir what to do next.
					if(QuestCommand.CanQuest(c,1)) break;
					return QuestCode.A100001(c,QuestID);
				case 100002:
					//Find Star Protector Stone, get a gift box from him.
					if(QuestCommand.CanQuest(c,2)) break;
					return QuestCode.A100002(c,QuestID);
				case 100003:
					//Equip weapon, then go to see Star Warrior Sophie.
					if(QuestCommand.CanQuest(c,3)) break;
					return QuestCode.A100003(c,QuestID);
				case 100005:
					//Learn skill, then look for Zodiac Instructor Darcy.
					if(QuestCommand.CanQuest(c,4)) break;
					return QuestCode.A100005(c,QuestID);
				case 100007:
					//Ask Virgo Kerry for a cloth.
					if(QuestCommand.CanQuest(c,5)) break;
					return QuestCode.A100007(c,QuestID);
				case 100009:
					//Find Zodiac Priest Moville outside of Zodiac Academy and finish his requirement.
					if(QuestCommand.CanQuest(c,5)) break;
					return QuestCode.A100009(c,QuestID);
				case 100010:
					//Kill Beedas at the outside of Zodiac Academy and then report to Zodiac Priest Moville.
					if(QuestCommand.CanQuest(c,6)) break;
					return QuestCode.A100010(c,QuestID);
				case 100012:
					//Ask Zodiac Priest Lily for the opportunity of getting next proof.
					if(QuestCommand.CanQuest(c,7)) break;
					return QuestCode.A100012(c,QuestID);
				case 100013:
					//Kill 1 Vampire Bat outside of Zodiac Academy and then report to Zodiac Priest Lily.
					if(QuestCommand.CanQuest(c,7)) break;
					return QuestCode.A100013(c,QuestID);
				case 100014:
					//Kill 1 Hiram outside of Zodiac Academy and then report to Zodiac Priest Lily.
					if(QuestCommand.CanQuest(c,7)) break;
					return QuestCode.A100014(c,QuestID);
				case 100015:
					//Get the last proof from Zodiac Officiant Roger, and match constellations.
					if(QuestCommand.CanQuest(c,8)) break;
					return QuestCode.A100015(c,QuestID);
				case 100016:
					//Kill 1 Treant outside of Zodiac Academy, then report to Zodiac Officiant Roger.
					if(QuestCommand.CanQuest(c,8)) break;
					return QuestCode.A100016(c,QuestID);
				case 100017:
					//Learn new skill with the guidance of Zodiac Instructor Barral.
					if(QuestCommand.CanQuest(c,8)) break;
					return QuestCode.A100017(c,QuestID);
				case 100020:
					//Ask Star Warlock Ekland to activate the Zodiac Medal.
					if(QuestCommand.CanQuest(c,9)) break;
					return QuestCode.A100020(c,QuestID);
				case 100023:
					//Go go Empire Capital, Contact Oracle.
					if(QuestCommand.CanQuest(c,10)) break;
					return QuestCode.A100023(c,QuestID);
				case 100024:
					//Go go Empire Capital, Contact Oracle.
					if(QuestCommand.CanQuest(c,10)) break;
					return QuestCode.A100024(c,QuestID);
				case 100025:
					//Go go Empire Capital, Contact Oracle.
					if(QuestCommand.CanQuest(c,10)) break;
					return QuestCode.A100025(c,QuestID);
				case 100026:
					//Choose a faction.
					if(QuestCommand.CanQuest(c,10)) break;
					return QuestCode.A100026(c,QuestID);
				case 110016:
					//Collect 1 Aquamarine Grass from Sunshine Cliff and give it to Allen.
					if(QuestCommand.CanQuest(c,14)) break;
					return QuestCode.A110016(c,QuestID);
				case 110017:
					//Ask Cecil about how to clean the bloodstain on the secret letter.
					if(QuestCommand.CanQuest(c,14)) break;
					return QuestCode.A110017(c,QuestID);
				case 110020:
					//Tekk Allen the method of cleaning bloodstain.
					if(QuestCommand.CanQuest(c,15)) break;
					return QuestCode.A110020(c,QuestID);
				case 110021:
					//Kill 4 Gold Wire Snakes at Sunshine Cliff, collect their venom and bring it back to Allen.
					if(QuestCommand.CanQuest(c,15)) break;
					return QuestCode.A110021(c,QuestID);
				case 110022:
					//Contact Bernice and do whatever she tells you.
					if(QuestCommand.CanQuest(c,15)) break;
					return QuestCode.A110022(c,QuestID);
				case 110024:
					//Kill 4 Troll Spiders at Sunshine Cliff, clear the way to Emma.
					if(QuestCommand.CanQuest(c,16)) break;
					return QuestCode.A110024(c,QuestID);
				case 110025:
					//Contact Sunshine Cliff\'s Emma.
					if(QuestCommand.CanQuest(c,16)) break;
					return QuestCode.A110025(c,QuestID);
				case 110027:
					//Collect 1 Mandela Tulip at Sunshine Cliff and give it to Emma.
					if(QuestCommand.CanQuest(c,16)) break;
					return QuestCode.A110027(c,QuestID);
				case 110028:
					//Tell Bernice the identity of the victim who\'s confirmed by Emma.
					if(QuestCommand.CanQuest(c,16)) break;
					return QuestCode.A110028(c,QuestID);
				case 110029:
					//Contact Sunshine Cliff\'s Barlow.
					if(QuestCommand.CanQuest(c,17)) break;
					return QuestCode.A110029(c,QuestID);
				case 110030:
					//Capture 4 Forest Bears at Sunshine Cliff, bring them back to Barlow.
					if(QuestCommand.CanQuest(c,17)) break;
					return QuestCode.A110030(c,QuestID);
				case 110032:
					//Collect 1 Phosphate Rock from Sunshine Cliff, bring it back to Barlow to make Phosphate Powder.
					if(QuestCommand.CanQuest(c,17)) break;
					return QuestCode.A110032(c,QuestID);
				case 110033:
					//Go to Sunshine Cliff, contact Janet.
					if(QuestCommand.CanQuest(c,17)) break;
					return QuestCode.A110033(c,QuestID);
				case 110035:
					//Collect 1 Death Flower from Sunshine Cliff and give it to Janet.
					if(QuestCommand.CanQuest(c,18)) break;
					return QuestCode.A110035(c,QuestID);
				case 110036:
					//Visit awakening Donald.
					if(QuestCommand.CanQuest(c,18)) break;
					return QuestCode.A110036(c,QuestID);
				case 110038:
					//Capture 4 Thunderhawk from Sunshine Cliff, bring them back to Donald.
					if(QuestCommand.CanQuest(c,18)) break;
					return QuestCode.A110038(c,QuestID);
				case 110039:
					//Ask Janet to help you extract information from Thunderhawk\'s eyes.
					if(QuestCommand.CanQuest(c,19)) break;
					return QuestCode.A110039(c,QuestID);
				case 110040:
					//Tell Donald the analysis made by Janet, let him make the final decision.
					if(QuestCommand.CanQuest(c,19)) break;
					return QuestCode.A110040(c,QuestID);
				case 110041:
					//Defeat Alva at Sunshine Cliff and report to Donald.
					if(QuestCommand.CanQuest(c,19)) break;
					return QuestCode.A110041(c,QuestID);
				case 110045:
					//Ask Edith about the information collected.
					if(QuestCommand.CanQuest(c,21)) break;
					return QuestCode.A110045(c,QuestID);
				case 110048:
					//Capture 5 Rubble Rat in Rubble Wasteland, bring them back to Edith.
					if(QuestCommand.CanQuest(c,21)) break;
					return QuestCode.A110048(c,QuestID);
				case 110049:
					//Bring the paper and ask Herbert what information he has gathered.
					if(QuestCommand.CanQuest(c,22)) break;
					return QuestCode.A110049(c,QuestID);
				case 110050:
					//Ask Joshua for the other half o the information.
					if(QuestCommand.CanQuest(c,22)) break;
					return QuestCode.A110050(c,QuestID);
				case 110051:
					//Tell Edith the information collected by Herbert and Joshua.
					if(QuestCommand.CanQuest(c,22)) break;
					return QuestCode.A110051(c,QuestID);
				case 110058:
					//Ask Leonard for the information he has gathered.
					if(QuestCommand.CanQuest(c,22)) break;
					return QuestCode.A110058(c,QuestID);
				case 110059:
					//Capture 8 Mottle Snakes in Rubble Wasteland and bring them back to Leonard.
					if(QuestCommand.CanQuest(c,22)) break;
					return QuestCode.A110059(c,QuestID);
				case 110060:
					//Ask Moore for the other half of the information.
					if(QuestCommand.CanQuest(c,23)) break;
					return QuestCode.A110060(c,QuestID);
				case 110061:
					//Listen to Moore tell how he lost the information.
					if(QuestCommand.CanQuest(c,23)) break;
					return QuestCode.A110061(c,QuestID);
				case 110062:
					//Catch Erica in Rubble Wasteland, get the lost half of information and take it to Moore.
					if(QuestCommand.CanQuest(c,23)) break;
					return QuestCode.A110062(c,QuestID);
				case 110063:
					//Bring the information collected by Leonard and Moore to Edith.
					if(QuestCommand.CanQuest(c,23)) break;
					return QuestCode.A110063(c,QuestID);
				case 110064:
					//Find Jason in Lune Oasis, tell him Edith\'s instructions.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A110064(c,QuestID);
				case 110089:
					//Contact Lune Oasis\'s Aldrich.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A110089(c,QuestID);
				case 110090:
					//Find Andy according to Aldrich\'s instruction, follow Andy\'s instruction.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A110090(c,QuestID);
				case 110091:
					//Ask Benedict for the investigation report.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A110091(c,QuestID);
				case 110092:
					//Bring Benedict\'s magic paper to Andy.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A110092(c,QuestID);
				case 110093:
					//Kill 15 Toothy Gerbils in Darksand Land and then report to Andy.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A110093(c,QuestID);
				case 110094:
					//Collect 4 Darkthorn Cactus in Darksand Land and bring them back to Edwina.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A110094(c,QuestID);
				case 110095:
					//Help Edwina to ask Andy when can they get normal water supply again.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A110095(c,QuestID);
				case 110096:
					//Find Chester, help Andy ask about Chester\'s findings.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A110096(c,QuestID);
				case 110097:
					//Bring Chester\'s investigation report to Andy.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A110097(c,QuestID);
				case 110098:
					//Capture 20 Rattlesnakes in Darksand Land and bring them back to Andy.
					if(QuestCommand.CanQuest(c,32)) break;
					return QuestCode.A110098(c,QuestID);
				case 110099:
					//Follow Andy\'s instruction to find Claude, asking him about how to increase the number of Rattlesnakes.
					if(QuestCommand.CanQuest(c,32)) break;
					return QuestCode.A110099(c,QuestID);
				case 110100:
					//Capture 20 Dire Wolves in Darksand Land and bring them back to Claude.
					if(QuestCommand.CanQuest(c,32)) break;
					return QuestCode.A110100(c,QuestID);
				case 110101:
					//Go to Darksand Land, talk to Claude\'s student Nelson.
					if(QuestCommand.CanQuest(c,33)) break;
					return QuestCode.A110101(c,QuestID);
				case 110102:
					//Collect 4 Buckthorn Grasses from Darksand Land and take them to Nelson.
					if(QuestCommand.CanQuest(c,33)) break;
					return QuestCode.A110102(c,QuestID);
				case 110103:
					//According to Nelson\'s request, ask Willa for some hairs.
					if(QuestCommand.CanQuest(c,33)) break;
					return QuestCode.A110103(c,QuestID);
				case 110104:
					//Kill Swantony in Darksand, seize back Willa\'s ring.
					if(QuestCommand.CanQuest(c,34)) break;
					return QuestCode.A110104(c,QuestID);
				case 110105:
					//Give Willa the ring and ask her for some hairs again.
					if(QuestCommand.CanQuest(c,34)) break;
					return QuestCode.A110105(c,QuestID);
				case 110106:
					//Bring Willa\'s hair back to Nelson.
					if(QuestCommand.CanQuest(c,34)) break;
					return QuestCode.A110106(c,QuestID);
				case 110107:
					//Give Claude materials collected by Nelson.
					if(QuestCommand.CanQuest(c,35)) break;
					return QuestCode.A110107(c,QuestID);
				case 110108:
					//Capture 35 Toothy Gerbils from Darksand Land and bring them back to Claude.
					if(QuestCommand.CanQuest(c,35)) break;
					return QuestCode.A110108(c,QuestID);
				case 110109:
					//Bring the woman from the Darksand Land to Andy.
					if(QuestCommand.CanQuest(c,35)) break;
					return QuestCode.A110109(c,QuestID);
				case 110110:
					//As Andy asked, Tell Ingrid to heal the mysterious woman as soon as possible.
					if(QuestCommand.CanQuest(c,36)) break;
					return QuestCode.A110110(c,QuestID);
				case 110111:
					//Ask Darksand Land\'s Miles for some Styptic.
					if(QuestCommand.CanQuest(c,36)) break;
					return QuestCode.A110111(c,QuestID);
				case 110112:
					//Collect 4 Buckthorn Flowers in Darksand Land and take them to Miles.
					if(QuestCommand.CanQuest(c,36)) break;
					return QuestCode.A110112(c,QuestID);
				case 110113:
					//Give Ingrid the Styptic made by Miles.
					if(QuestCommand.CanQuest(c,36)) break;
					return QuestCode.A110113(c,QuestID);
				case 110114:
					//Help Colin to ask Cornell for Benson\'s whereabouts.
					if(QuestCommand.CanQuest(c,37)) break;
					return QuestCode.A110114(c,QuestID);
				case 110115:
					//Tell Andy about Benson\'s missing and the lost data.
					if(QuestCommand.CanQuest(c,37)) break;
					return QuestCode.A110115(c,QuestID);
				case 110116:
					//Find Esther, let her to get the mysterious woman\'s testimony.
					if(QuestCommand.CanQuest(c,37)) break;
					return QuestCode.A110116(c,QuestID);
				case 110117:
					//Catch 35 Bactrian Camels in Darksand Land and take them to Esther.
					if(QuestCommand.CanQuest(c,37)) break;
					return QuestCode.A110117(c,QuestID);
				case 110118:
					//Find Lyle in Darksand Land, tell him Andy\'s instructions.
					if(QuestCommand.CanQuest(c,38)) break;
					return QuestCode.A110118(c,QuestID);
				case 110119:
					//Ask Julian to think some ways to find Benson.
					if(QuestCommand.CanQuest(c,38)) break;
					return QuestCode.A110119(c,QuestID);
				case 110120:
					//Catch 35 Trade Wind Foxes in Darksand Land and take them back to Julian.
					if(QuestCommand.CanQuest(c,38)) break;
					return QuestCode.A110120(c,QuestID);
				case 110121:
					//Arrest Benson in Darksand Land and take him to Lyle.
					if(QuestCommand.CanQuest(c,39)) break;
					return QuestCode.A110121(c,QuestID);
				case 110122:
					//Ask Ogden about the origin of the badge.
					if(QuestCommand.CanQuest(c,39)) break;
					return QuestCode.A110122(c,QuestID);
				case 110123:
					//Report to Andy about how to deal with Benson.
					if(QuestCommand.CanQuest(c,39)) break;
					return QuestCode.A110123(c,QuestID);
				case 110124:
					//Go to Tramp Camp, contact Duke.
					if(QuestCommand.CanQuest(c,40)) break;
					return QuestCode.A110124(c,QuestID);
				case 110125:
					//Go to see Edgar, ask to join the tramp guild.
					if(QuestCommand.CanQuest(c,40)) break;
					return QuestCode.A110125(c,QuestID);
				case 110126:
					//Catch 40 Phantom Monkeys from Vine Rainforest and take them to Edgar.
					if(QuestCommand.CanQuest(c,40)) break;
					return QuestCode.A110126(c,QuestID);
				case 110127:
					//Register at Hoare and accept his test.
					if(QuestCommand.CanQuest(c,40)) break;
					return QuestCode.A110127(c,QuestID);
				case 110128:
					//Kill 40 Man-eating Trees in Vine Rainforest and report to Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A110128(c,QuestID);
				case 110129:
					//Follow Hoare\'s instruction to meet Ansel.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A110129(c,QuestID);
				case 110130:
					//Tell Duke Ansel\'s requirement for the alliance.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A110130(c,QuestID);
				case 110131:
					//Tell Ansel Duke\'s reply.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A110131(c,QuestID);
				case 110132:
					//Find Monlisa, ask her to brew one Vow Potion.
					if(QuestCommand.CanQuest(c,42)) break;
					return QuestCode.A110132(c,QuestID);
				case 110133:
					//Collect 5 Delusion Herbs in Vine Rainforest and give them to Monlisa.
					if(QuestCommand.CanQuest(c,42)) break;
					return QuestCode.A110133(c,QuestID);
				case 110134:
					//Take Vow Potion to Ansel and drink it in front of him.
					if(QuestCommand.CanQuest(c,42)) break;
					return QuestCode.A110134(c,QuestID);
				case 110135:
					//Ask Elder Levi to make one Eye of Truth.
					if(QuestCommand.CanQuest(c,43)) break;
					return QuestCode.A110135(c,QuestID);
				case 110136:
					//Kill 40 Wraith Spiders in Vine Rainforest, take their eyes to Levi.
					if(QuestCommand.CanQuest(c,43)) break;
					return QuestCode.A110136(c,QuestID);
				case 110137:
					//Find Ansel, see what request he has.
					if(QuestCommand.CanQuest(c,43)) break;
					return QuestCode.A110137(c,QuestID);
				case 110138:
					//Ask Joyce for Tramp\'s headscarf.
					if(QuestCommand.CanQuest(c,44)) break;
					return QuestCode.A110138(c,QuestID);
				case 110139:
					//Kill Baird in Vine Rainforest, take back the stolen Tramp\'s headscarf.
					if(QuestCommand.CanQuest(c,44)) break;
					return QuestCode.A110139(c,QuestID);
				case 110140:
					//Take Tramp\'s headscarf and report to Ansel.
					if(QuestCommand.CanQuest(c,44)) break;
					return QuestCode.A110140(c,QuestID);
				case 110141:
					//Ask Monlisa to make one Mystic Potion.
					if(QuestCommand.CanQuest(c,45)) break;
					return QuestCode.A110141(c,QuestID);
				case 110142:
					//Collect 5 Vampire Vines in Vine Rainforest and tale them back to Monlisa.
					if(QuestCommand.CanQuest(c,45)) break;
					return QuestCode.A110142(c,QuestID);
				case 110143:
					//Listen to Ansel talk about the use of Mystic Potion.
					if(QuestCommand.CanQuest(c,45)) break;
					return QuestCode.A110143(c,QuestID);
				case 110144:
					//Find Jerome in Vine Rainforest, capture Archer with him.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A110144(c,QuestID);
				case 110145:
					//Ask Kyle if he can remove the giant stone which blocks the way.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A110145(c,QuestID);
				case 110146:
					//Catch 45 Giant Jaw Ants in Vine Rainforest and take them to Kyle.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A110146(c,QuestID);
				case 110147:
					//Ask Thera if she can find out the disappeared trace.
					if(QuestCommand.CanQuest(c,47)) break;
					return QuestCode.A110147(c,QuestID);
				case 110148:
					//Ask Winnie to make some Revealing Potion.
					if(QuestCommand.CanQuest(c,47)) break;
					return QuestCode.A110148(c,QuestID);
				case 110149:
					//Collect 5 Luminous Grasses in Vine Rainforest and take them back to Winnie.
					if(QuestCommand.CanQuest(c,47)) break;
					return QuestCode.A110149(c,QuestID);
				case 110150:
					//Catch Archer in Vine Rainforest and take him to Jerome.
					if(QuestCommand.CanQuest(c,48)) break;
					return QuestCode.A110150(c,QuestID);
				case 110151:
					//Take Archer to Tramp Camp\'s Ansel.
					if(QuestCommand.CanQuest(c,48)) break;
					return QuestCode.A110151(c,QuestID);
				case 110152:
					//Take Archer to Morris.
					if(QuestCommand.CanQuest(c,48)) break;
					return QuestCode.A110152(c,QuestID);
				case 110153:
					//Catch 45 Mud Monsters in Vine Rainforest and take them to Morris.
					if(QuestCommand.CanQuest(c,49)) break;
					return QuestCode.A110153(c,QuestID);
				case 110154:
					//Take Archer from Morris to Ansel.
					if(QuestCommand.CanQuest(c,49)) break;
					return QuestCode.A110154(c,QuestID);
				case 110155:
					//Tell Duke that Archer was poisoned to death.
					if(QuestCommand.CanQuest(c,49)) break;
					return QuestCode.A110155(c,QuestID);
				case 110156:
					//Go to Pearl Village, meet Colby dispatched by Duke.
					if(QuestCommand.CanQuest(c,50)) break;
					return QuestCode.A110156(c,QuestID);
				case 110157:
					//Visit Ashbur, ask him about where to find the Blade.
					if(QuestCommand.CanQuest(c,50)) break;
					return QuestCode.A110157(c,QuestID);
				case 110158:
					//Tell Mabel about what the Village Head said.
					if(QuestCommand.CanQuest(c,50)) break;
					return QuestCode.A110158(c,QuestID);
				case 110159:
					//Kill 50 Venom Monsters in Redcloud Marsh and then go back and tell Mabel.
					if(QuestCommand.CanQuest(c,50)) break;
					return QuestCode.A110159(c,QuestID);
				case 110160:
					//Take the red material to Raymond, ask him to analyze its component.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A110160(c,QuestID);
				case 110161:
					//Kill 50 Venom Monsters in Redcloud Marsh, collect the red materials for Raymond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A110161(c,QuestID);
				case 110162:
					//Tell Mabel about Raymond\'s finding.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A110162(c,QuestID);
				case 110163:
					//Find Vermal in Redcloud Marsh, ask him if anything unusual has happened.
					if(QuestCommand.CanQuest(c,52)) break;
					return QuestCode.A110163(c,QuestID);
				case 110164:
					//Give Simona the data collected by Vermal, ask here to make a comprehensive analysis.
					if(QuestCommand.CanQuest(c,52)) break;
					return QuestCode.A110164(c,QuestID);
				case 110165:
					//Catch 50 Short-wing Rats in Redcloud Marsh and take them to Simona.
					if(QuestCommand.CanQuest(c,52)) break;
					return QuestCode.A110165(c,QuestID);
				case 110166:
					//Ask Raymond about the solution.
					if(QuestCommand.CanQuest(c,53)) break;
					return QuestCode.A110166(c,QuestID);
				case 110167:
					//Catch 50 Medusa in Redcloud Marsh and take back to Raymond.
					if(QuestCommand.CanQuest(c,53)) break;
					return QuestCode.A110167(c,QuestID);
				case 110168:
					//Collect 6 Fluorescent Herbs in Redcloud Marsh and take them to Raymond.
					if(QuestCommand.CanQuest(c,53)) break;
					return QuestCode.A110168(c,QuestID);
				case 110169:
					//Take Simona\'s analysis report to Vermal.
					if(QuestCommand.CanQuest(c,54)) break;
					return QuestCode.A110169(c,QuestID);
				case 110170:
					//Take Simona\'s analysis report to Mabel.
					if(QuestCommand.CanQuest(c,54)) break;
					return QuestCode.A110170(c,QuestID);
				case 110171:
					//Kill 50 Mugger Crocodiles in Redcloud Marsh and then to to tell Mabel.
					if(QuestCommand.CanQuest(c,54)) break;
					return QuestCode.A110171(c,QuestID);
				case 110172:
					//Defeat Olive in Redcloud Marsh and then to to tell Mabel.
					if(QuestCommand.CanQuest(c,55)) break;
					return QuestCode.A110172(c,QuestID);
				case 110173:
					//Take the mysterious woman back to village, ask village head Ashbur if he can find out any clues.
					if(QuestCommand.CanQuest(c,55)) break;
					return QuestCode.A110173(c,QuestID);
				case 110174:
					//Ask Olive about the whereabout of the village head\'s son.
					if(QuestCommand.CanQuest(c,55)) break;
					return QuestCode.A110174(c,QuestID);
				case 110175:
					//Take Olive to Nicolas for treatment.
					if(QuestCommand.CanQuest(c,56)) break;
					return QuestCode.A110175(c,QuestID);
				case 110176:
					//Catch 55 Medusa in Redcloud Marsh and take them to Nicolas.
					if(QuestCommand.CanQuest(c,56)) break;
					return QuestCode.A110176(c,QuestID);
				case 110177:
					//Talk with Olive.
					if(QuestCommand.CanQuest(c,56)) break;
					return QuestCode.A110177(c,QuestID);
				case 110178:
					//Ask Raymond to extract some nectar from Rotten Flower.
					if(QuestCommand.CanQuest(c,57)) break;
					return QuestCode.A110178(c,QuestID);
				case 110179:
					//Collect 6 Rotten Flowers in Redcloud Marsh and take them to Raymond.
					if(QuestCommand.CanQuest(c,57)) break;
					return QuestCode.A110179(c,QuestID);
				case 110180:
					//Take the Rotten Flower to Olive.
					if(QuestCommand.CanQuest(c,57)) break;
					return QuestCode.A110180(c,QuestID);
				case 110181:
					//Ask Olive about the whereabouts of the murderer.
					if(QuestCommand.CanQuest(c,58)) break;
					return QuestCode.A110181(c,QuestID);
				case 110182:
					//Go to Redcloud Marsh, ask Blair to help to find out the mark Olive left.
					if(QuestCommand.CanQuest(c,58)) break;
					return QuestCode.A110182(c,QuestID);
				case 110183:
					//Kill 55 Carrions in Redcloud Marsh and then tell Blair.
					if(QuestCommand.CanQuest(c,58)) break;
					return QuestCode.A110183(c,QuestID);
				case 110184:
					//Destroy Giant Carrion in Redcloud Marsh, take back the box and then tell Blair.
					if(QuestCommand.CanQuest(c,59)) break;
					return QuestCode.A110184(c,QuestID);
				case 110185:
					//Go to Pearl Village, take the box to Colby.
					if(QuestCommand.CanQuest(c,59)) break;
					return QuestCode.A110185(c,QuestID);
				case 110186:
					//Take the box to Gregory to identify.
					if(QuestCommand.CanQuest(c,59)) break;
					return QuestCode.A110186(c,QuestID);
				case 110187:
					//Find Colby, let him make the final decision.
					if(QuestCommand.CanQuest(c,59)) break;
					return QuestCode.A110187(c,QuestID);
				case 110188:
					//Go to the Lost City to meet Mario.
					if(QuestCommand.CanQuest(c,60)) break;
					return QuestCode.A110188(c,QuestID);
				case 110189:
					//Find Amos, ask him about the progress of excavation.
					if(QuestCommand.CanQuest(c,60)) break;
					return QuestCode.A110189(c,QuestID);
				case 110190:
					//Catch 60 Darkwind Wolves in Darkwind Canyon and bring them back to Amos.
					if(QuestCommand.CanQuest(c,60)) break;
					return QuestCode.A110190(c,QuestID);
				case 110191:
					//Tell Veronica about Amos\' request.
					if(QuestCommand.CanQuest(c,60)) break;
					return QuestCode.A110191(c,QuestID);
				case 110192:
					//Take Haemin extracted by Veronica to Amos.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A110192(c,QuestID);
				case 110193:
					//Catch 60 Darkwind Hunters in Darkwind Canyon and bring them back to Amos.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A110193(c,QuestID);
				case 110194:
					//See Veronica, tell her Amos\' requirement and promise.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A110194(c,QuestID);
				case 110195:
					//Take Haemin extracted by Veronica to Amos.
					if(QuestCommand.CanQuest(c,62)) break;
					return QuestCode.A110195(c,QuestID);
				case 110196:
					//Catch 60 Canyon Centaurs in Darkwind Canyon and bring them back to Amos.
					if(QuestCommand.CanQuest(c,62)) break;
					return QuestCode.A110196(c,QuestID);
				case 110197:
					//See Jeffrey, ask him to come to Amos and discuss the reason of Lost City\'s decline.
					if(QuestCommand.CanQuest(c,62)) break;
					return QuestCode.A110197(c,QuestID);
				case 110198:
					//Ask Mario about the negligence of duty.
					if(QuestCommand.CanQuest(c,62)) break;
					return QuestCode.A110198(c,QuestID);
				case 110199:
					//Ask Omar to save Amos as soon as possible.
					if(QuestCommand.CanQuest(c,63)) break;
					return QuestCode.A110199(c,QuestID);
				case 110200:
					//Collect 6 Cruor Grasses in Darkwind Canyon and bring them back to Omar.
					if(QuestCommand.CanQuest(c,63)) break;
					return QuestCode.A110200(c,QuestID);
				case 110201:
					//Ask Veronica to make purer Antidotes.
					if(QuestCommand.CanQuest(c,63)) break;
					return QuestCode.A110201(c,QuestID);
				case 110202:
					//See Omar, give him Veronica\'s Antidotes.
					if(QuestCommand.CanQuest(c,64)) break;
					return QuestCode.A110202(c,QuestID);
				case 110203:
					//Catch 60 Canyon Centaurs in Darkwind Canyon and bring them back to Omar.
					if(QuestCommand.CanQuest(c,64)) break;
					return QuestCode.A110203(c,QuestID);
				case 110204:
					//Bring Alger the list of materials needed for holding Soul Ritual.
					if(QuestCommand.CanQuest(c,64)) break;
					return QuestCode.A110204(c,QuestID);
				case 110205:
					//Catch 65 Darkwind Wolves in Darkwind Canyon and bring them back to Alger.
					if(QuestCommand.CanQuest(c,65)) break;
					return QuestCode.A110205(c,QuestID);
				case 110206:
					//Catch 65 Darkwind Hunters in Darkwind Canyon and bring them back to Alger.
					if(QuestCommand.CanQuest(c,65)) break;
					return QuestCode.A110206(c,QuestID);
				case 110207:
					//Catch 25 Canyon Eagles, 25 Stone Lizards, 25 Canyon Centaurs in Darkwind Canyon and bring them back to Alger.
					if(QuestCommand.CanQuest(c,65)) break;
					return QuestCode.A110207(c,QuestID);
				case 110208:
					//Bring materials collected by Alger to Omar.
					if(QuestCommand.CanQuest(c,66)) break;
					return QuestCode.A110208(c,QuestID);
				case 110209:
					//Ask Amos about the assassination.
					if(QuestCommand.CanQuest(c,66)) break;
					return QuestCode.A110209(c,QuestID);
				case 110210:
					//Ask Theodore to catch the assassin.
					if(QuestCommand.CanQuest(c,66)) break;
					return QuestCode.A110210(c,QuestID);
				case 110211:
					//Find Angelo in Darkwind Canyon, asking him to catch the assassin as soon as possible.
					if(QuestCommand.CanQuest(c,66)) break;
					return QuestCode.A110211(c,QuestID);
				case 110212:
					//Kill 1 Shadow Assassin in Darkwind Canyon and bring him back to Angelo.
					if(QuestCommand.CanQuest(c,66)) break;
					return QuestCode.A110212(c,QuestID);
				case 110213:
					//Ask Tiffany how to restore Amos\' memory.
					if(QuestCommand.CanQuest(c,67)) break;
					return QuestCode.A110213(c,QuestID);
				case 110214:
					//Collect 6 Hyacinth from Darkwind Canyon and bring them back to Tiffany.
					if(QuestCommand.CanQuest(c,67)) break;
					return QuestCode.A110214(c,QuestID);
				case 110215:
					//Bring the Potion of Time made by Tiffany to Amos.
					if(QuestCommand.CanQuest(c,67)) break;
					return QuestCode.A110215(c,QuestID);
				case 110216:
					//Tell Mario what Amos has found, ask him to report that to the capital.
					if(QuestCommand.CanQuest(c,68)) break;
					return QuestCode.A110216(c,QuestID);
				case 110217:
					//Find Stanley, ask him to summon the souls of the dead assassin.
					if(QuestCommand.CanQuest(c,68)) break;
					return QuestCode.A110217(c,QuestID);
				case 110218:
					//Catch 65 Canyon Centaurs in Darkwind Canyon and bring them back to Stanley.
					if(QuestCommand.CanQuest(c,68)) break;
					return QuestCode.A110218(c,QuestID);
				case 110219:
					//Tell Mario about Stanley\'s finding.
					if(QuestCommand.CanQuest(c,69)) break;
					return QuestCode.A110219(c,QuestID);
				case 110220:
					//Catch 3 Head Centaurs in Darkwind Canyon and bring them back to Mario.
					if(QuestCommand.CanQuest(c,69)) break;
					return QuestCode.A110220(c,QuestID);
				case 110221:
					//Enter Dark Castle, contact Burnell.
					if(QuestCommand.CanQuest(c,70)) break;
					return QuestCode.A110221(c,QuestID);
				case 110222:
					//Ask Jabman about the dagger.
					if(QuestCommand.CanQuest(c,70)) break;
					return QuestCode.A110222(c,QuestID);
				case 110223:
					//Kill 70 Foggy Bears in Foggy Forest and then tell Jabman.
					if(QuestCommand.CanQuest(c,70)) break;
					return QuestCode.A110223(c,QuestID);
				case 110224:
					//Kill 70 Foggy Vampires in Foggy Forest and then tell Jabman.
					if(QuestCommand.CanQuest(c,70)) break;
					return QuestCode.A110224(c,QuestID);
				case 110225:
					//Find Claymond, ask him what usual things have happened recently.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A110225(c,QuestID);
				case 110226:
					//Find Xaviera, asking her to try to find some Light of Life.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A110226(c,QuestID);
				case 110227:
					//Kill 70 Berserk Warriors in Foggy Forest and then find Xaviera.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A110227(c,QuestID);
				case 110228:
					//Find Hiddrick, asking him where the World Tree\'s seed is.
					if(QuestCommand.CanQuest(c,72)) break;
					return QuestCode.A110228(c,QuestID);
				case 110229:
					//Ask Jabman for Tree of Life\'s seed.
					if(QuestCommand.CanQuest(c,72)) break;
					return QuestCode.A110229(c,QuestID);
				case 110230:
					//Kill 70 Dawn Elves in Foggy Forest and then find Jabman.
					if(QuestCommand.CanQuest(c,72)) break;
					return QuestCode.A110230(c,QuestID);
				case 110231:
					//Bring the Light of Life to Claymond.
					if(QuestCommand.CanQuest(c,73)) break;
					return QuestCode.A110231(c,QuestID);
				case 110232:
					//Ask Cyril about the history of Dark Castle.
					if(QuestCommand.CanQuest(c,73)) break;
					return QuestCode.A110232(c,QuestID);
				case 110233:
					//Find Zelene, listen to him talk about what happened next.
					if(QuestCommand.CanQuest(c,73)) break;
					return QuestCode.A110233(c,QuestID);
				case 110234:
					//Find Claymond, listen to him talk about what happened next.
					if(QuestCommand.CanQuest(c,73)) break;
					return QuestCode.A110234(c,QuestID);
				case 110235:
					//Kill 70 Berserk Warriors in Foggy Forest, then go back and tell Claymond.
					if(QuestCommand.CanQuest(c,74)) break;
					return QuestCode.A110235(c,QuestID);
				case 110236:
					//Kill 70 Dawn Elves in Foggy Forest, then go back and tell Claymond.
					if(QuestCommand.CanQuest(c,74)) break;
					return QuestCode.A110236(c,QuestID);
				case 110237:
					//Collect 6 Foggy Roses in Foggy Forest and bring them back to Claymond.
					if(QuestCommand.CanQuest(c,74)) break;
					return QuestCode.A110237(c,QuestID);
				case 110238:
					//Tell Cesar about Claymond\'s instructions.
					if(QuestCommand.CanQuest(c,75)) break;
					return QuestCode.A110238(c,QuestID);
				case 110239:
					//Ask Yuna who\'s been to Seal Room recently.
					if(QuestCommand.CanQuest(c,75)) break;
					return QuestCode.A110239(c,QuestID);
				case 110240:
					//Catch 75 Foggy Spiders in Foggy Forest and bring them back to Yuna.
					if(QuestCommand.CanQuest(c,75)) break;
					return QuestCode.A110240(c,QuestID);
				case 110241:
					//Find Dark in Foggy Forest and ask him about Riel\'s trend.
					if(QuestCommand.CanQuest(c,76)) break;
					return QuestCode.A110241(c,QuestID);
				case 110242:
					//Catch 75 Dawn Elves in Foggy Forest and bring them back to Dark.
					if(QuestCommand.CanQuest(c,76)) break;
					return QuestCode.A110242(c,QuestID);
				case 110243:
					//Tell Dark Castle\'s Claymond the information Dark has learnt.
					if(QuestCommand.CanQuest(c,76)) break;
					return QuestCode.A110243(c,QuestID);
				case 110244:
					//Go to Foggy Forest Wind Rider Rita， Blade of Light。
					if(QuestCommand.CanQuest(c,77)) break;
					return QuestCode.A110244(c,QuestID);
				case 110245:
					//Ask Jabman if there\'s any remedy.
					if(QuestCommand.CanQuest(c,77)) break;
					return QuestCode.A110245(c,QuestID);
				case 110246:
					//Find Candice, tell her Jabman\'s demand.
					if(QuestCommand.CanQuest(c,77)) break;
					return QuestCode.A110246(c,QuestID);
				case 110247:
					//Collect 6 Blood Mosses in Foggy Forest and bring them back to Candice.
					if(QuestCommand.CanQuest(c,78)) break;
					return QuestCode.A110247(c,QuestID);
				case 110248:
					//Bring Deadsoul Potion mae by Candice to Parker.
					if(QuestCommand.CanQuest(c,78)) break;
					return QuestCode.A110248(c,QuestID);
				case 110249:
					//Catch 75 Berserk Warriors in Foggy Forest and bring them back to Parker.
					if(QuestCommand.CanQuest(c,78)) break;
					return QuestCode.A110249(c,QuestID);
				case 110250:
					//Bring the Chaos Crystal extracted by Candice to Jabman.
					if(QuestCommand.CanQuest(c,79)) break;
					return QuestCode.A110250(c,QuestID);
				case 110251:
					//Kill 5 Head Berserks in Foggy Forest and then tell Jabman.
					if(QuestCommand.CanQuest(c,79)) break;
					return QuestCode.A110251(c,QuestID);
				case 110252:
					//Find Burnell, tell him about Jabman\'s words.
					if(QuestCommand.CanQuest(c,79)) break;
					return QuestCode.A110252(c,QuestID);
				case 110253:
					//Go to Henan Mountain, contact Burnell.
					if(QuestCommand.CanQuest(c,80)) break;
					return QuestCode.A110253(c,QuestID);
				case 110254:
					//Ask Herman about what to do next for Harold.
					if(QuestCommand.CanQuest(c,80)) break;
					return QuestCode.A110254(c,QuestID);
				case 110255:
					//Find Sigrid and ask him to save the unconscious advance agent.
					if(QuestCommand.CanQuest(c,80)) break;
					return QuestCode.A110255(c,QuestID);
				case 110256:
					//Catch 80 Carefree Beasts in the Henan Mountainside, and bring them to Sigrid.
					if(QuestCommand.CanQuest(c,80)) break;
					return QuestCode.A110256(c,QuestID);
				case 110257:
					//Find Jeremy and ask him about the way to remove the Blessing Mark of Lord of Oracle
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A110257(c,QuestID);
				case 110258:
					//Tell Sigrid Jeremy\'s words.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A110258(c,QuestID);
				case 110259:
					//Collect 6 Despair Herbs on the Henan Mountainside and give them to Sigrid.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A110259(c,QuestID);
				case 110260:
					//Bring the advance agent that saved by Sigrid to Herman.
					if(QuestCommand.CanQuest(c,82)) break;
					return QuestCode.A110260(c,QuestID);
				case 110261:
					//Catch 80 Spirit Dragons on the Henan Mountainside, and bring them to Herman.
					if(QuestCommand.CanQuest(c,82)) break;
					return QuestCode.A110261(c,QuestID);
				case 110262:
					//Find Kelly and ask her to break the Circle of Memory Sealing.
					if(QuestCommand.CanQuest(c,82)) break;
					return QuestCode.A110262(c,QuestID);
				case 110263:
					//Find Sigrid and ask her for a Imaging Restore Potion.
					if(QuestCommand.CanQuest(c,83)) break;
					return QuestCode.A110263(c,QuestID);
				case 110264:
					//Catch 80 Spirit Dragons on the Henan Mountainside, and bring them to Sigrid.
					if(QuestCommand.CanQuest(c,83)) break;
					return QuestCode.A110264(c,QuestID);
				case 110265:
					//Find Renee and ask her to refine the Magic Elements in the Spirit Dragons.
					if(QuestCommand.CanQuest(c,83)) break;
					return QuestCode.A110265(c,QuestID);
				case 110266:
					//Give the refined Magic Elements to Sigrid.
					if(QuestCommand.CanQuest(c,84)) break;
					return QuestCode.A110266(c,QuestID);
				case 110267:
					//Find Eunice and ask her about the way of increasing the density of the Magic Elements.
					if(QuestCommand.CanQuest(c,84)) break;
					return QuestCode.A110267(c,QuestID);
				case 110268:
					//Collect 6 Silver Mines on the Henan Mountainside and give them to Eunice.
					if(QuestCommand.CanQuest(c,84)) break;
					return QuestCode.A110268(c,QuestID);
				case 110269:
					//Give the refined Silver Mine to Sigrid.
					if(QuestCommand.CanQuest(c,84)) break;
					return QuestCode.A110269(c,QuestID);
				case 110270:
					//Give the configured Imaging Restore Potion to Sigrid.
					if(QuestCommand.CanQuest(c,85)) break;
					return QuestCode.A110270(c,QuestID);
				case 110271:
					//Kill 85 Lost Acolytes on the Henan Mountainside then go back and tell tell Kelly.
					if(QuestCommand.CanQuest(c,85)) break;
					return QuestCode.A110271(c,QuestID);
				case 110272:
					//Tell Herman Kelly\'s discovery.
					if(QuestCommand.CanQuest(c,85)) break;
					return QuestCode.A110272(c,QuestID);
				case 110273:
					//Tell Mitchell Herman\'s request.
					if(QuestCommand.CanQuest(c,86)) break;
					return QuestCode.A110273(c,QuestID);
				case 110274:
					//Tell Eunice Mitchell\'s request.
					if(QuestCommand.CanQuest(c,86)) break;
					return QuestCode.A110274(c,QuestID);
				case 110275:
					//Catch 50 Carefree Beasts and 50 Bubble Beasts on Henan Mountainside and bring them to Eunice.
					if(QuestCommand.CanQuest(c,86)) break;
					return QuestCode.A110275(c,QuestID);
				case 110276:
					//Tell Mitchell Eunice\'s discovery.
					if(QuestCommand.CanQuest(c,87)) break;
					return QuestCode.A110276(c,QuestID);
				case 110277:
					//Catch 85 Bubble Beasts on Henan Mountainside and bring them to Mitchell.
					if(QuestCommand.CanQuest(c,87)) break;
					return QuestCode.A110277(c,QuestID);
				case 110278:
					//Give the Track Potion made by Mitchell to Herman.
					if(QuestCommand.CanQuest(c,87)) break;
					return QuestCode.A110278(c,QuestID);
				case 110279:
					//Defeat the Guarder Sissi on the Henan Mountainside then go back and tell Herman.
					if(QuestCommand.CanQuest(c,88)) break;
					return QuestCode.A110279(c,QuestID);
				case 110280:
					//Ask Jared about the way to defeat Guarder Sissi for Herman.
					if(QuestCommand.CanQuest(c,88)) break;
					return QuestCode.A110280(c,QuestID);
				case 110281:
					//Catch 50 Skyish Beasts and 50 Dark Carefree Beast on the Henan Mountainside then bring them to Jared.
					if(QuestCommand.CanQuest(c,88)) break;
					return QuestCode.A110281(c,QuestID);
				case 110282:
					//Kill 10 Guarder Sissi on the Henan Mountainside then go back and tell Jared.
					if(QuestCommand.CanQuest(c,89)) break;
					return QuestCode.A110282(c,QuestID);
				case 110283:
					//Tell Herman Jared\'s suggestion.
					if(QuestCommand.CanQuest(c,89)) break;
					return QuestCode.A110283(c,QuestID);
				case 110284:
					//Go to Peak of the World and contact Herman.
					if(QuestCommand.CanQuest(c,90)) break;
					return QuestCode.A110284(c,QuestID);
				case 111001:
					//Find Old Blacksmith, get the gift from the Old Blacksmith.
					if(QuestCommand.CanQuest(c,11)) break;
					return QuestCode.A111001(c,QuestID);
				case 111004:
					//Learn new skill from Warrior Leader.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A111004(c,QuestID);
				case 111006:
					//Get a better weapon from the Warrior Leader.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A111006(c,QuestID);
				case 111008:
					//Ask Grocer for some Teleport Scrolls.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A111008(c,QuestID);
				case 111010:
					//Get a better magic cloth from the Tailor.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A111010(c,QuestID);
				case 111011:
					//Go to see the Stargazer and get to know your horoscopes.
					if(QuestCommand.CanQuest(c,13)) break;
					return QuestCode.A111011(c,QuestID);
				case 111012:
					//See the Preparatory Officer, let him arrange the following things.
					if(QuestCommand.CanQuest(c,13)) break;
					return QuestCode.A111012(c,QuestID);
				case 111015:
					//Go to Sunshine Cliff, meet Allen.
					if(QuestCommand.CanQuest(c,14)) break;
					return QuestCode.A111015(c,QuestID);
				case 111044:
					//Go to the City of Genesis and contact Grover.
					if(QuestCommand.CanQuest(c,20)) break;
					return QuestCode.A111044(c,QuestID);
				case 112001:
					//Find Old Blacksmith, get the gift from the Old Blacksmith.
					if(QuestCommand.CanQuest(c,11)) break;
					return QuestCode.A112001(c,QuestID);
				case 112004:
					//Learn new skill from Warrior Leader.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A112004(c,QuestID);
				case 112006:
					//Get a better weapon from the Warrior Leader.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A112006(c,QuestID);
				case 112008:
					//Ask Grocer for some Teleport Scrolls.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A112008(c,QuestID);
				case 112010:
					//Get a better magic cloth from the Tailor.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A112010(c,QuestID);
				case 112011:
					//Go to see the Stargazer and get to know your horoscopes.
					if(QuestCommand.CanQuest(c,13)) break;
					return QuestCode.A112011(c,QuestID);
				case 112012:
					//See the Preparatory Officer, let him arrange the following things.
					if(QuestCommand.CanQuest(c,13)) break;
					return QuestCode.A112012(c,QuestID);
				case 112015:
					//Go to Sunshine Cliff, meet Allen.
					if(QuestCommand.CanQuest(c,14)) break;
					return QuestCode.A112015(c,QuestID);
				case 113001:
					//Find Old Blacksmith, get the gift from the Old Blacksmith.
					if(QuestCommand.CanQuest(c,11)) break;
					return QuestCode.A113001(c,QuestID);
				case 113004:
					//Learn new skill from Warrior Leader.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A113004(c,QuestID);
				case 113006:
					//Get a better weapon from the Warrior Leader.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A113006(c,QuestID);
				case 113008:
					//Ask Grocer for some Teleport Scrolls.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A113008(c,QuestID);
				case 113010:
					//Get a better magic cloth from the Tailor.
					if(QuestCommand.CanQuest(c,12)) break;
					return QuestCode.A113010(c,QuestID);
				case 113011:
					//Go to see the Stargazer and get to know your horoscopes.
					if(QuestCommand.CanQuest(c,13)) break;
					return QuestCode.A113011(c,QuestID);
				case 113012:
					//See the Preparatory Officer, let him arrange the following things.
					if(QuestCommand.CanQuest(c,13)) break;
					return QuestCode.A113012(c,QuestID);
				case 113015:
					//Go to Sunshine Cliff, meet Allen.
					if(QuestCommand.CanQuest(c,14)) break;
					return QuestCode.A113015(c,QuestID);
				case 119001:
					//Ask Ernest for the weapon Grover has prepared.
					if(QuestCommand.CanQuest(c,20)) break;
					return QuestCode.A119001(c,QuestID);
				case 119002:
					//Ask Larry about the whole thing.
					if(QuestCommand.CanQuest(c,21)) break;
					return QuestCode.A119002(c,QuestID);
				case 119003:
					//Kill Mentor Quentin at Dawn Pier, then tell this news to Jeff.
					if(QuestCommand.CanQuest(c,21)) break;
					return QuestCode.A119003(c,QuestID);
				case 119004:
					//Get VIP Trial Card from Larry.
					if(QuestCommand.CanQuest(c,21)) break;
					return QuestCode.A119004(c,QuestID);
				case 119005:
					//Try zodiac transformation under Grover\'s guidance.
					if(QuestCommand.CanQuest(c,20)) break;
					return QuestCode.A119005(c,QuestID);
				case 119006:
					//Find Goya and finish her request.
					if(QuestCommand.CanQuest(c,20)) break;
					return QuestCode.A119006(c,QuestID);
				case 119007:
					//Tell Spendo about Donald\'s news.
					if(QuestCommand.CanQuest(c,19)) break;
					return QuestCode.A119007(c,QuestID);
				case 119009:
					//Synthesize one Armor Shred with Magic Seed, then go to see Herbert.
					if(QuestCommand.CanQuest(c,26)) break;
					return QuestCode.A119009(c,QuestID);
				case 119010:
					//Synthesize one Ice Enchant with Magic Seed, then go to see Herbert.
					if(QuestCommand.CanQuest(c,26)) break;
					return QuestCode.A119010(c,QuestID);
				case 119011:
					//Synthesize one Death Inspire with Magic Seed, then go to see Herbert.
					if(QuestCommand.CanQuest(c,26)) break;
					return QuestCode.A119011(c,QuestID);
				case 119012:
					//Find Feig, buy one HP Potion B and talk to him.
					if(QuestCommand.CanQuest(c,26)) break;
					return QuestCode.A119012(c,QuestID);
				case 119013:
					//Enter Sky City, kill 4 Cloud Elves, then go to see Beryl.
					if(QuestCommand.CanQuest(c,26)) break;
					return QuestCode.A119013(c,QuestID);
				case 119014:
					//Go to City of Genesis, find Morton and listen to his instructions.
					if(QuestCommand.CanQuest(c,27)) break;
					return QuestCode.A119014(c,QuestID);
				case 119016:
					//Find Edith, ask her how to make money.
					if(QuestCommand.CanQuest(c,28)) break;
					return QuestCode.A119016(c,QuestID);
				case 119017:
					//Complete Escort Supplies once, then go to see Edith.
					if(QuestCommand.CanQuest(c,28)) break;
					return QuestCode.A119017(c,QuestID);
				case 119018:
					//Enter Dragon Cave, kill 5 Bronze Drakes, and then find Quenton.
					if(QuestCommand.CanQuest(c,29)) break;
					return QuestCode.A119018(c,QuestID);
				case 119020:
					//Collect 2 Dusk Dew in Lune Oasis, and then find Pine.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A119020(c,QuestID);
				case 119021:
					//Kill 8 Moonlight Beasts in Lune Oasis, then find Ralph.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A119021(c,QuestID);
				case 119022:
					//Kill 8 Gangtooth Spiders in Lune Oasis, then find Gemma.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A119022(c,QuestID);
				case 119023:
					//Kill 8 Desert Lizards in Lune Oasis, then find Claude.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A119023(c,QuestID);
				case 119024:
					//Kill 8 Desert Arks in Lune Oasis, then find Claude.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A119024(c,QuestID);
				case 119025:
					//Find Jason in Lune Oasis, listen to his command.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A119025(c,QuestID);
				case 120004:
					//Add 1 friend and find Leonard to finish the quest.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A120004(c,QuestID);
				case 120022:
					//Join a guild and find Edith to complete the task.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A120022(c,QuestID);
				case 120027:
					//Ask Cleveland how to take a leave successfully.
					if(QuestCommand.CanQuest(c,23)) break;
					return QuestCode.A120027(c,QuestID);
				case 120028:
					//Persuade Curtis to agree the work shift with Edith.
					if(QuestCommand.CanQuest(c,23)) break;
					return QuestCode.A120028(c,QuestID);
				case 120029:
					//Catch 8 Fire Bats at Rubble Wasteland and take them back to Curtis.
					if(QuestCommand.CanQuest(c,23)) break;
					return QuestCode.A120029(c,QuestID);
				case 120030:
					//Kill 5 Stone Ants at Rubble Wasteland and then tell Curtis.
					if(QuestCommand.CanQuest(c,24)) break;
					return QuestCode.A120030(c,QuestID);
				case 120031:
					//Take Dulcie the weapon enhanced by Curtis.
					if(QuestCommand.CanQuest(c,24)) break;
					return QuestCode.A120031(c,QuestID);
				case 120035:
					//Kill 8 The Decayed at Rubble Wasteland and then tell Dulcie.
					if(QuestCommand.CanQuest(c,24)) break;
					return QuestCode.A120035(c,QuestID);
				case 120036:
					//Go to see Elroy, ask the reason of Treant\'s attack for Dulcie.
					if(QuestCommand.CanQuest(c,24)) break;
					return QuestCode.A120036(c,QuestID);
				case 120037:
					//Catch 5 Wind Weasels at Rubble Wasteland and take back to Moore.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A120037(c,QuestID);
				case 120038:
					//Help Elroy to find Magee and find out if there\'s some way to restore the magic array on the sword.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A120038(c,QuestID);
				case 120039:
					//Catch 5 Tarantulas at Rubble Wasteland and take back to Ralph.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A120039(c,QuestID);
				case 120040:
					//Take the sword enchanted by Magee to Beryl.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A120040(c,QuestID);
				case 120058:
					//Kill 15 Toothy Gerbil at Darksand Land and report to Andy.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A120058(c,QuestID);
				case 120059:
					//Ask Ingrid how to heal rheumatism for Colin.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A120059(c,QuestID);
				case 120060:
					//Catch 30 Toxic Scorpions at Darksand Land and take back to Ingrid.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A120060(c,QuestID);
				case 120061:
					//Ask Benedict about how to get food.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A120061(c,QuestID);
				case 120062:
					//Tell Andy Benedict\'s suggestion.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A120062(c,QuestID);
				case 120063:
					//Catch 20 Toothy Gerbils at Darksand Land and take them back to Andy.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A120063(c,QuestID);
				case 120064:
					//Ask Claude to detoxify for Chester\'s wife.
					if(QuestCommand.CanQuest(c,32)) break;
					return QuestCode.A120064(c,QuestID);
				case 120065:
					//Catch 20 Toxic Scorpions at Darksand Land, take them to Claude to make antidotes.
					if(QuestCommand.CanQuest(c,32)) break;
					return QuestCode.A120065(c,QuestID);
				case 120066:
					//Take Claude\'s antidotes to Chester.
					if(QuestCommand.CanQuest(c,32)) break;
					return QuestCode.A120066(c,QuestID);
				case 120067:
					//Ask Claude about salary increase.
					if(QuestCommand.CanQuest(c,32)) break;
					return QuestCode.A120067(c,QuestID);
				case 120068:
					//Tell Nelson Claude\'s promise.
					if(QuestCommand.CanQuest(c,32)) break;
					return QuestCode.A120068(c,QuestID);
				case 120069:
					//Ask Colin to derust weapon.
					if(QuestCommand.CanQuest(c,33)) break;
					return QuestCode.A120069(c,QuestID);
				case 120070:
					//Collect 4 Darksand Essence at Darksand Land and take back to Colin.
					if(QuestCommand.CanQuest(c,33)) break;
					return QuestCode.A120070(c,QuestID);
				case 120071:
					//Take the weapon reforged by Colin to Esther.
					if(QuestCommand.CanQuest(c,33)) break;
					return QuestCode.A120071(c,QuestID);
				case 120072:
					//Kill 30 Dire Wolves at Darksand Land and report to Andy.
					if(QuestCommand.CanQuest(c,34)) break;
					return QuestCode.A120072(c,QuestID);
				case 120073:
					//Ask Claude how to let Rattlesnakes quiet down at night
					if(QuestCommand.CanQuest(c,34)) break;
					return QuestCode.A120073(c,QuestID);
				case 120074:
					//Tell Lyle Claude\'s method.
					if(QuestCommand.CanQuest(c,34)) break;
					return QuestCode.A120074(c,QuestID);
				case 120075:
					//Catch 30 Toothy Gerbils at Darksand Land and take them back to Lyle.
					if(QuestCommand.CanQuest(c,34)) break;
					return QuestCode.A120075(c,QuestID);
				case 120076:
					//Catch 35 Toxic Scorpions at Darksand Land and take them back to Julian.
					if(QuestCommand.CanQuest(c,35)) break;
					return QuestCode.A120076(c,QuestID);
				case 120077:
					//Catch 35 Dire Wolves at Darksand Land and take them back to Julian.
					if(QuestCommand.CanQuest(c,35)) break;
					return QuestCode.A120077(c,QuestID);
				case 120078:
					//Catch 35 Bactrian Camels at Darksand Land and take them back to Julian.
					if(QuestCommand.CanQuest(c,35)) break;
					return QuestCode.A120078(c,QuestID);
				case 120079:
					//Catch 35 Bactrian Camels at Darksand Land and take them back to Andy.
					if(QuestCommand.CanQuest(c,36)) break;
					return QuestCode.A120079(c,QuestID);
				case 120080:
					//Ask Julian how to get fuels.
					if(QuestCommand.CanQuest(c,36)) break;
					return QuestCode.A120080(c,QuestID);
				case 120081:
					//Catch 35 Sand Fire Lizard at Darksand Land and take back to Julian.
					if(QuestCommand.CanQuest(c,36)) break;
					return QuestCode.A120081(c,QuestID);
				case 120085:
					//Catch 35 Dire Wolves at Darksand Land and take them back to Nelson.
					if(QuestCommand.CanQuest(c,38)) break;
					return QuestCode.A120085(c,QuestID);
				case 120086:
					//Tell Willa that Nelson has done what she asks.
					if(QuestCommand.CanQuest(c,38)) break;
					return QuestCode.A120086(c,QuestID);
				case 120087:
					//Catch 35 Trade Wind Fox at Darksand Land and take back to Cornell.
					if(QuestCommand.CanQuest(c,37)) break;
					return QuestCode.A120087(c,QuestID);
				case 120088:
					//Take Lyle and his broken arm to Ingrid.
					if(QuestCommand.CanQuest(c,39)) break;
					return QuestCode.A120088(c,QuestID);
				case 120089:
					//Catch 35 Sand Fire Lizards at Darksand Land and take them to Ingrid.
					if(QuestCommand.CanQuest(c,39)) break;
					return QuestCode.A120089(c,QuestID);
				case 120090:
					//Kill 35 Toxic Scorpions at Darksand Land and report to Andy.
					if(QuestCommand.CanQuest(c,39)) break;
					return QuestCode.A120090(c,QuestID);
				case 120091:
					//Ask Edgar to take out some bananas from the Inventory.
					if(QuestCommand.CanQuest(c,40)) break;
					return QuestCode.A120091(c,QuestID);
				case 120092:
					//Ask Joyce to get bananas before sunset.
					if(QuestCommand.CanQuest(c,40)) break;
					return QuestCode.A120092(c,QuestID);
				case 120093:
					//Catch 40 Phantom Monkeys in Vine Rainforest and take back to Joyce.
					if(QuestCommand.CanQuest(c,40)) break;
					return QuestCode.A120093(c,QuestID);
				case 120094:
					//Catch 40 Phantom Monkeys in Vine Rainforest and then tell Shalom.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A120094(c,QuestID);
				case 120095:
					//Find Leopold in Vine Rainforest and investigate the missing man with him.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A120095(c,QuestID);
				case 120096:
					//Catch 40 Man-eating Trees in Vine Rainforest and take back to Leopold.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A120096(c,QuestID);
				case 120097:
					//Report to Edgar the investigation result.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A120097(c,QuestID);
				case 120098:
					//Ask Monlisa how to prevent food from mouldiness.
					if(QuestCommand.CanQuest(c,42)) break;
					return QuestCode.A120098(c,QuestID);
				case 120099:
					//Catch 40 Man-eating Trees in Vine Rainforest and take back to Monlisa.
					if(QuestCommand.CanQuest(c,42)) break;
					return QuestCode.A120099(c,QuestID);
				case 120100:
					//Kill 40 Wraith Spiders in Vine Rainforest and then tell Laurie.
					if(QuestCommand.CanQuest(c,42)) break;
					return QuestCode.A120100(c,QuestID);
				case 120101:
					//Catch 40 Wraith Spiders in Vine Rainforest and take back to Thera.
					if(QuestCommand.CanQuest(c,43)) break;
					return QuestCode.A120101(c,QuestID);
				case 120102:
					//Ask Winnie how to deal with spider\'s thread.
					if(QuestCommand.CanQuest(c,43)) break;
					return QuestCode.A120102(c,QuestID);
				case 120103:
					//Take Wraith\'s Spider Thread to Thera.
					if(QuestCommand.CanQuest(c,43)) break;
					return QuestCode.A120103(c,QuestID);
				case 120104:
					//Catch 40 Wraith Spiders in Vine Rainforest and take back to Shalom.
					if(QuestCommand.CanQuest(c,44)) break;
					return QuestCode.A120104(c,QuestID);
				case 120105:
					//Ask Monlisa to help Shalom extract Wraith Spider\'s poison.
					if(QuestCommand.CanQuest(c,44)) break;
					return QuestCode.A120105(c,QuestID);
				case 120106:
					//Ask Shalom why she need to extract the poison.
					if(QuestCommand.CanQuest(c,44)) break;
					return QuestCode.A120106(c,QuestID);
				case 120107:
					//Tell Joyce Hoare\'s task.
					if(QuestCommand.CanQuest(c,45)) break;
					return QuestCode.A120107(c,QuestID);
				case 120108:
					//Catch 45 Giant Jaw Ants in Vine Rainforest and take back to Joyce.
					if(QuestCommand.CanQuest(c,45)) break;
					return QuestCode.A120108(c,QuestID);
				case 120109:
					//Catch 45 Mud Monsters in Vine Rainforest and take back to Levi.
					if(QuestCommand.CanQuest(c,45)) break;
					return QuestCode.A120109(c,QuestID);
				case 120110:
					//Ask Levi to repair the broken magic test crystal.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A120110(c,QuestID);
				case 120111:
					//Collect 5 Water Mana Spar in Vine Rainforest and take them back to Levi.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A120111(c,QuestID);
				case 120112:
					//Take the repaired Test Crystal to Hoare.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A120112(c,QuestID);
				case 120113:
					//Kill 15 Wraith Spiders, 15 Man-eating Trees, 15 Mud Monsters in Vine Rainforest and report to Ansel.
					if(QuestCommand.CanQuest(c,47)) break;
					return QuestCode.A120113(c,QuestID);
				case 120114:
					//Kill 45 Mud Monsters in Vine Rainforest and then tell Leopold.
					if(QuestCommand.CanQuest(c,47)) break;
					return QuestCode.A120114(c,QuestID);
				case 120115:
					//Ask Monlisa how to heal rheumatism.
					if(QuestCommand.CanQuest(c,48)) break;
					return QuestCode.A120115(c,QuestID);
				case 120116:
					//Catch 45 Giant Jaw Ants in Vine Rainforest and take them to Monlisa.
					if(QuestCommand.CanQuest(c,48)) break;
					return QuestCode.A120116(c,QuestID);
				case 120117:
					//Tell Levi Monlisa\'s treatment.
					if(QuestCommand.CanQuest(c,48)) break;
					return QuestCode.A120117(c,QuestID);
				case 120118:
					//Tell Levi Ansel\'s instructions.
					if(QuestCommand.CanQuest(c,49)) break;
					return QuestCode.A120118(c,QuestID);
				case 120119:
					//Catch 45 Mud Monsters in Vine Rainforest and take back to Levi.
					if(QuestCommand.CanQuest(c,49)) break;
					return QuestCode.A120119(c,QuestID);
				case 120120:
					//Ask Hyman to give Weisz a good weapon to pay the debt of gratitude.
					if(QuestCommand.CanQuest(c,50)) break;
					return QuestCode.A120120(c,QuestID);
				case 120121:
					//Ask Raymond how to get Curare Wood.
					if(QuestCommand.CanQuest(c,50)) break;
					return QuestCode.A120121(c,QuestID);
				case 120122:
					//Catch 50 Venom Monsters in Redcloud Marsh and take back to Raymond.
					if(QuestCommand.CanQuest(c,50)) break;
					return QuestCode.A120122(c,QuestID);
				case 120123:
					//Take Raymond\'s Corrosion Potion to Hyman.
					if(QuestCommand.CanQuest(c,50)) break;
					return QuestCode.A120123(c,QuestID);
				case 120124:
					//Take Hyman\'s weapon to Weisz.
					if(QuestCommand.CanQuest(c,50)) break;
					return QuestCode.A120124(c,QuestID);
				case 120125:
					//Catch 50 Venom Monsters in Redcloud Marsh and take back to Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A120125(c,QuestID);
				case 120126:
					//Ask Rodney to get a Venom Monster with wings.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A120126(c,QuestID);
				case 120127:
					//Catch 50 Short-wing Rats in Redcloud Marsh and take back to Rodney.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A120127(c,QuestID);
				case 120128:
					//Take Rodney\'s Venom Monster to Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A120128(c,QuestID);
				case 120129:
					//Tell Nicolas that Weisz has absorbed miasma in the village and ask him to solve this.
					if(QuestCommand.CanQuest(c,52)) break;
					return QuestCode.A120129(c,QuestID);
				case 120130:
					//Kill 50 Medusa in Redcloud Marsh and take their eyes to Nicolas.
					if(QuestCommand.CanQuest(c,52)) break;
					return QuestCode.A120130(c,QuestID);
				case 120131:
					//Catch 50 Venom Monsters in Redcloud Marsh and take back to Vermal.
					if(QuestCommand.CanQuest(c,52)) break;
					return QuestCode.A120131(c,QuestID);
				case 120132:
					//Catch 50 Medusa in Redcloud Marsh and take back to Raymond.
					if(QuestCommand.CanQuest(c,53)) break;
					return QuestCode.A120132(c,QuestID);
				case 120133:
					//Ask Simona to analyze the crystal crumble.
					if(QuestCommand.CanQuest(c,53)) break;
					return QuestCode.A120133(c,QuestID);
				case 120134:
					//Tell Raymond Simona\'s analysis result.
					if(QuestCommand.CanQuest(c,53)) break;
					return QuestCode.A120134(c,QuestID);
				case 120135:
					//Tell Raymond that Serena needs a bottle of colorant.
					if(QuestCommand.CanQuest(c,54)) break;
					return QuestCode.A120135(c,QuestID);
				case 120136:
					//Catch 20 Venom Monsters, 20 Medusa and 20 Mugger Crocodiles in Redcloud Marsh and take back to Raymond.
					if(QuestCommand.CanQuest(c,54)) break;
					return QuestCode.A120136(c,QuestID);
				case 120137:
					//Collect 6 Greenbell Flowers in Redcloud Marsh and take back to Raymond.
					if(QuestCommand.CanQuest(c,54)) break;
					return QuestCode.A120137(c,QuestID);
				case 120138:
					//Tell Bertram the news that his brother is murdered.
					if(QuestCommand.CanQuest(c,55)) break;
					return QuestCode.A120138(c,QuestID);
				case 120139:
					//Kill 55 Carrion in Redcloud Marsh and then tell Bertram.
					if(QuestCommand.CanQuest(c,55)) break;
					return QuestCode.A120139(c,QuestID);
				case 120140:
					//Kill 5 Giant Carrion in Redcloud Marsh and then tell Bertram.
					if(QuestCommand.CanQuest(c,55)) break;
					return QuestCode.A120140(c,QuestID);
				case 120141:
					//Kill 55 Carrion in Redcloud Marsh and then tell Serena.
					if(QuestCommand.CanQuest(c,56)) break;
					return QuestCode.A120141(c,QuestID);
				case 120142:
					//Ask Rodney where to find the stones to build house.
					if(QuestCommand.CanQuest(c,56)) break;
					return QuestCode.A120142(c,QuestID);
				case 120143:
					//Catch 55 Short-wing Rats in Redcloud Marsh and take back to Rodney.
					if(QuestCommand.CanQuest(c,56)) break;
					return QuestCode.A120143(c,QuestID);
				case 120144:
					//Tell Blair Osmond\'s requirement and conditions.
					if(QuestCommand.CanQuest(c,57)) break;
					return QuestCode.A120144(c,QuestID);
				case 120145:
					//Catch 55 Mugger Crocodiles in Redcloud Marsh and take back to Blair.
					if(QuestCommand.CanQuest(c,57)) break;
					return QuestCode.A120145(c,QuestID);
				case 120146:
					//Catch 55 Short-wing Rats in Redcloud Marsh and take back to Blair.
					if(QuestCommand.CanQuest(c,57)) break;
					return QuestCode.A120146(c,QuestID);
				case 120147:
					//Tell Mabel Osmond\'s task and ask her to find out the truth asap.
					if(QuestCommand.CanQuest(c,58)) break;
					return QuestCode.A120147(c,QuestID);
				case 120148:
					//Tell Osmond Mabel\'s findings.
					if(QuestCommand.CanQuest(c,58)) break;
					return QuestCode.A120148(c,QuestID);
				case 120149:
					//Kill 55 Carrion in Redcloud Marsh and then tell Osmond.
					if(QuestCommand.CanQuest(c,58)) break;
					return QuestCode.A120149(c,QuestID);
				case 120150:
					//Help Weisz to ask Serena the materials for making quality leather bag.
					if(QuestCommand.CanQuest(c,59)) break;
					return QuestCode.A120150(c,QuestID);
				case 120151:
					//Tell Weisz Serena\'s advice.
					if(QuestCommand.CanQuest(c,59)) break;
					return QuestCode.A120151(c,QuestID);
				case 120152:
					//Kill 55 Mugger Crocodiles in Redcloud Marsh and take the crocodile skin to Weisz.
					if(QuestCommand.CanQuest(c,59)) break;
					return QuestCode.A120152(c,QuestID);
				case 120153:
					//Ask Angelo the where Atwood is.
					if(QuestCommand.CanQuest(c,60)) break;
					return QuestCode.A120153(c,QuestID);
				case 120154:
					//Ask Omar to make some potions that can remove petrification.
					if(QuestCommand.CanQuest(c,60)) break;
					return QuestCode.A120154(c,QuestID);
				case 120155:
					//Catch 60 Stone Lizards in Darkwind Canyon and bring them back to Omar.
					if(QuestCommand.CanQuest(c,60)) break;
					return QuestCode.A120155(c,QuestID);
				case 120156:
					//Kill 60 Darkwind Wolves in Darkwind Canyon and then tell Bertha.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A120156(c,QuestID);
				case 120157:
					//Find Morgan, ask him to identify the thing Bertha just dug out.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A120157(c,QuestID);
				case 120158:
					//Catch 60 Canyon Centaurs in Darkwind Canyon and bring them back to Morgan.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A120158(c,QuestID);
				case 120159:
					//Ask Atwood about being smashed.
					if(QuestCommand.CanQuest(c,62)) break;
					return QuestCode.A120159(c,QuestID);
				case 120160:
					//Ask Bella what kind of beast Black Dot is.
					if(QuestCommand.CanQuest(c,62)) break;
					return QuestCode.A120160(c,QuestID);
				case 120161:
					//Kill 60 Canyon Eagles in Darkwind Canyon and then tell Bella.
					if(QuestCommand.CanQuest(c,62)) break;
					return QuestCode.A120161(c,QuestID);
				case 120162:
					//Ask Angelo why Canyon Eagle attacked human.
					if(QuestCommand.CanQuest(c,63)) break;
					return QuestCode.A120162(c,QuestID);
				case 120163:
					//Kill 60 Canyon Centaurs in Darkwind Canyon and then tell Angelo.
					if(QuestCommand.CanQuest(c,63)) break;
					return QuestCode.A120163(c,QuestID);
				case 120164:
					//Ask Omar if there\'s anything that can help Jeffrey to sleep.
					if(QuestCommand.CanQuest(c,63)) break;
					return QuestCode.A120164(c,QuestID);
				case 120165:
					//Catch 60 Stone Lizards in Darkwind Canyon and bring them back to Omar.
					if(QuestCommand.CanQuest(c,63)) break;
					return QuestCode.A120165(c,QuestID);
				case 120166:
					//Ask Bertha what kind of pact with beast she wants.
					if(QuestCommand.CanQuest(c,64)) break;
					return QuestCode.A120166(c,QuestID);
				case 120167:
					//Tell Theodore Bertha\'s decision.
					if(QuestCommand.CanQuest(c,64)) break;
					return QuestCode.A120167(c,QuestID);
				case 120168:
					//Catch 60 Darkwind Hunters in Darkwind Canyon and bring them back to Theodore.
					if(QuestCommand.CanQuest(c,64)) break;
					return QuestCode.A120168(c,QuestID);
				case 120169:
					//Ask Jeffrey if there\'s a way to calm down the wolves in the canyon.
					if(QuestCommand.CanQuest(c,65)) break;
					return QuestCode.A120169(c,QuestID);
				case 120170:
					//Kill 65 Darkwind Wolves in Darkwind Canyon and then report to Jeffrey.
					if(QuestCommand.CanQuest(c,65)) break;
					return QuestCode.A120170(c,QuestID);
				case 120171:
					//Tell Angelo about Jeffrey\'s warning, asking him not to confront the werewolves directly.
					if(QuestCommand.CanQuest(c,65)) break;
					return QuestCode.A120171(c,QuestID);
				case 120172:
					//Catch 65 Darkwind Hunters in Darkwind Canyon and bring them back to Veronica.
					if(QuestCommand.CanQuest(c,66)) break;
					return QuestCode.A120172(c,QuestID);
				case 120173:
					//Catch 65 Darkwind Wolves in Darkwind Canyon and bring them back to Veronica.
					if(QuestCommand.CanQuest(c,66)) break;
					return QuestCode.A120173(c,QuestID);
				case 120174:
					//Catch 65 Darkwind Eagles in Darkwind Canyon and bring them back to Veronica.
					if(QuestCommand.CanQuest(c,66)) break;
					return QuestCode.A120174(c,QuestID);
				case 120175:
					//Ask Alger about how to deal with Canyon Centaur.
					if(QuestCommand.CanQuest(c,67)) break;
					return QuestCode.A120175(c,QuestID);
				case 120176:
					//Kill 3 Head Centaurs in Darkwind Canyon and then tell Alger.
					if(QuestCommand.CanQuest(c,67)) break;
					return QuestCode.A120176(c,QuestID);
				case 120177:
					//Kill 65 Canyon Centaurs in Darkwind Canyon and then tell Alger.
					if(QuestCommand.CanQuest(c,67)) break;
					return QuestCode.A120177(c,QuestID);
				case 120178:
					//Catch 65 Darkwind Wolves in Darkwind Canyon and bring them back to Omar.
					if(QuestCommand.CanQuest(c,68)) break;
					return QuestCode.A120178(c,QuestID);
				case 120179:
					//Catch 65 Darkwind Hunters in Darkwind Canyon and bring them back to Omar.
					if(QuestCommand.CanQuest(c,68)) break;
					return QuestCode.A120179(c,QuestID);
				case 120180:
					//Catch 65 Stone Lizards in Darkwind Canyon and bring them back to Omar.
					if(QuestCommand.CanQuest(c,68)) break;
					return QuestCode.A120180(c,QuestID);
				case 120181:
					//Ask Omar if there\'s a way to make a potion that contains wind element.
					if(QuestCommand.CanQuest(c,69)) break;
					return QuestCode.A120181(c,QuestID);
				case 120182:
					//Catch 65 Canyon Eagles in Darkwind Canyon and bring them back to Omar.
					if(QuestCommand.CanQuest(c,69)) break;
					return QuestCode.A120182(c,QuestID);
				case 120183:
					//Bring the wind crystal stone made by Omar to Amos.
					if(QuestCommand.CanQuest(c,69)) break;
					return QuestCode.A120183(c,QuestID);
				case 120184:
					//Ask Gavin whether beasts to be used in this year\'s Beast\'s Festival are ready.
					if(QuestCommand.CanQuest(c,70)) break;
					return QuestCode.A120184(c,QuestID);
				case 120185:
					//Kill 70 Foggy Vampires in Foggy Forest and bring them back to Francis.
					if(QuestCommand.CanQuest(c,70)) break;
					return QuestCode.A120185(c,QuestID);
				case 120186:
					//Bring the Foggy Vampire trained by Gavin to Francis.
					if(QuestCommand.CanQuest(c,70)) break;
					return QuestCode.A120186(c,QuestID);
				case 120187:
					//Help Cesar to ask Xaviera if she received the gift.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A120187(c,QuestID);
				case 120188:
					//Kill 70 Foggy Bears in Foggy Forest and then tell Xaviera.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A120188(c,QuestID);
				case 120189:
					//Collect 6 Foggy Roses in Foggy Forest and bring them back to Xaviera.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A120189(c,QuestID);
				case 120190:
					//Kill 70 Foggy Spiders in Foggy Forest and bring them back to Cyril.
					if(QuestCommand.CanQuest(c,72)) break;
					return QuestCode.A120190(c,QuestID);
				case 120191:
					//Bring the fried spider leg made by Cyril to Claire.
					if(QuestCommand.CanQuest(c,72)) break;
					return QuestCode.A120191(c,QuestID);
				case 120192:
					//Catch 70 Foggy Bears in Foggy Forest and bring them back to Claire.
					if(QuestCommand.CanQuest(c,72)) break;
					return QuestCode.A120192(c,QuestID);
				case 120193:
					//Ask Jabman to make a Promotion Test for you.
					if(QuestCommand.CanQuest(c,73)) break;
					return QuestCode.A120193(c,QuestID);
				case 120194:
					//Kill 70 Foggy Vampires in Foggy Forest and them tell Jabman.
					if(QuestCommand.CanQuest(c,73)) break;
					return QuestCode.A120194(c,QuestID);
				case 120195:
					//Kill 5 Head Berserks in Foggy Forest and then tell Jabman.
					if(QuestCommand.CanQuest(c,73)) break;
					return QuestCode.A120195(c,QuestID);
				case 120196:
					//Kill 70 Dawn Elves in Foggy Forest and then tell Gavin.
					if(QuestCommand.CanQuest(c,74)) break;
					return QuestCode.A120196(c,QuestID);
				case 120197:
					//Tell Dark Castle\'s Jabman about Gavin\'s finding.
					if(QuestCommand.CanQuest(c,74)) break;
					return QuestCode.A120197(c,QuestID);
				case 120198:
					//Kill 70 Berserk Warriors in Foggy Forest and then tell Teddy.
					if(QuestCommand.CanQuest(c,74)) break;
					return QuestCode.A120198(c,QuestID);
				case 120199:
					//Go to Dark Castle and ask Inquiry how to solve the problem of too cold to sleep.
					if(QuestCommand.CanQuest(c,75)) break;
					return QuestCode.A120199(c,QuestID);
				case 120200:
					//Kill 75 Foggy Spiders in Foggy Forest and bring them back to Zelene.
					if(QuestCommand.CanQuest(c,75)) break;
					return QuestCode.A120200(c,QuestID);
				case 120201:
					//Bring the cobweb extracted by Zelene to Candice.
					if(QuestCommand.CanQuest(c,75)) break;
					return QuestCode.A120201(c,QuestID);
				case 120202:
					//Ask Gavin for a batch of magic scrolls.
					if(QuestCommand.CanQuest(c,76)) break;
					return QuestCode.A120202(c,QuestID);
				case 120203:
					//Catch 75 Foggy Bears in Foggy Forest and bring them back to Gavin.
					if(QuestCommand.CanQuest(c,76)) break;
					return QuestCode.A120203(c,QuestID);
				case 120204:
					//Bring the foggy bear fur made by Gavin to Yuna.
					if(QuestCommand.CanQuest(c,76)) break;
					return QuestCode.A120204(c,QuestID);
				case 120205:
					//Catch 75 Berserk Warriors in Foggy Forest and bring them back to Parker.
					if(QuestCommand.CanQuest(c,77)) break;
					return QuestCode.A120205(c,QuestID);
				case 120206:
					//Catch 5 Head Berserks in Foggy Forest and bring them back to Parker.
					if(QuestCommand.CanQuest(c,77)) break;
					return QuestCode.A120206(c,QuestID);
				case 120207:
					//Tell Claymond about Parker\'s finding.
					if(QuestCommand.CanQuest(c,77)) break;
					return QuestCode.A120207(c,QuestID);
				case 120208:
					//Tell Dark about Jabman\'s instructions.
					if(QuestCommand.CanQuest(c,78)) break;
					return QuestCode.A120208(c,QuestID);
				case 120209:
					//Catch 3000 Foggy Vampires in Foggy Forest and bring them back to Dark.
					if(QuestCommand.CanQuest(c,78)) break;
					return QuestCode.A120209(c,QuestID);
				case 120210:
					//Tell Jabman that Dark is training Foggy Vampire.
					if(QuestCommand.CanQuest(c,78)) break;
					return QuestCode.A120210(c,QuestID);
				case 120211:
					//Ask Jabman how to break through the magic barrier.
					if(QuestCommand.CanQuest(c,79)) break;
					return QuestCode.A120211(c,QuestID);
				case 120212:
					//Catch 75 Foggy Spiders in Foggy Forest and bring them back to Jabman.
					if(QuestCommand.CanQuest(c,79)) break;
					return QuestCode.A120212(c,QuestID);
				case 120213:
					//Bring the Foggy Spider trained by Jabman to Gavin.
					if(QuestCommand.CanQuest(c,79)) break;
					return QuestCode.A120213(c,QuestID);
				case 120214:
					//Help Isaac to ask Jonas if he had any new findings.
					if(QuestCommand.CanQuest(c,80)) break;
					return QuestCode.A120214(c,QuestID);
				case 120215:
					//Catch 80 Lost Acolytes on the Henan Mountainside and bring them to Jonas.
					if(QuestCommand.CanQuest(c,80)) break;
					return QuestCode.A120215(c,QuestID);
				case 120216:
					//Go to Henan Mountain and tell Isaac Jonas\'s discovery.
					if(QuestCommand.CanQuest(c,80)) break;
					return QuestCode.A120216(c,QuestID);
				case 120217:
					//Follow Marlon\'s order and go to Henan Mountainside to find Nate.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A120217(c,QuestID);
				case 120218:
					//Catch 80 Carefree Beasts on the Henan Mountainside and bring them to Nate.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A120218(c,QuestID);
				case 120219:
					//Give Marlon the Carefree Beast\'s Blood that collected by Nade.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A120219(c,QuestID);
				case 120220:
					//Ask Lance about the way of making Crystal for Kim.
					if(QuestCommand.CanQuest(c,82)) break;
					return QuestCode.A120220(c,QuestID);
				case 120221:
					//Catch 80 Spirit Dragons on the Henan Mountainside and bring them to Lance.
					if(QuestCommand.CanQuest(c,82)) break;
					return QuestCode.A120221(c,QuestID);
				case 120222:
					//Give Kim the Crystal made by Lance.
					if(QuestCommand.CanQuest(c,82)) break;
					return QuestCode.A120222(c,QuestID);
				case 120223:
					//Ask Mitchell about the way of keeping scent for Grace.
					if(QuestCommand.CanQuest(c,83)) break;
					return QuestCode.A120223(c,QuestID);
				case 120224:
					//Catch 80 Carefree Beasts on the Henan Mountainside and bring them to Mitchell.
					if(QuestCommand.CanQuest(c,83)) break;
					return QuestCode.A120224(c,QuestID);
				case 120225:
					//Give Grace the perfume made by Mitchell.
					if(QuestCommand.CanQuest(c,83)) break;
					return QuestCode.A120225(c,QuestID);
				case 120226:
					//Defeat 30 Dark Carefree Beasts on the Henan Moutainside then go back and tell Jeremy.
					if(QuestCommand.CanQuest(c,84)) break;
					return QuestCode.A120226(c,QuestID);
				case 120227:
					//Ask Isaac about the reason why the Dark Carefree Beast went mad for Jeremy.
					if(QuestCommand.CanQuest(c,84)) break;
					return QuestCode.A120227(c,QuestID);
				case 120228:
					//Go to Henan Mountain and tell Jeremy Isaac\'s warning.
					if(QuestCommand.CanQuest(c,84)) break;
					return QuestCode.A120228(c,QuestID);
				case 120229:
					//Ask Marlon about how to repair the armor for Kelly.
					if(QuestCommand.CanQuest(c,85)) break;
					return QuestCode.A120229(c,QuestID);
				case 120230:
					//Catch 85 Skyish Beasts on the Henan Mountainside and bring them to Marlon.
					if(QuestCommand.CanQuest(c,85)) break;
					return QuestCode.A120230(c,QuestID);
				case 120231:
					//Give the armor that fixed by Markon to Kelly.
					if(QuestCommand.CanQuest(c,85)) break;
					return QuestCode.A120231(c,QuestID);
				case 120232:
					//Ask Jonas about the way of making magic gloves for Nate.
					if(QuestCommand.CanQuest(c,86)) break;
					return QuestCode.A120232(c,QuestID);
				case 120233:
					//Catch 85 Bubble Beasts on the Henan Mountainside and bring them to Jonas.
					if(QuestCommand.CanQuest(c,86)) break;
					return QuestCode.A120233(c,QuestID);
				case 120234:
					//Give the magic gloves that made by Jonas to Nate.
					if(QuestCommand.CanQuest(c,86)) break;
					return QuestCode.A120234(c,QuestID);
				case 120235:
					//Ask Jared about the way to treat red rash for Grace.
					if(QuestCommand.CanQuest(c,87)) break;
					return QuestCode.A120235(c,QuestID);
				case 120236:
					//Catch 85 Skyish Beasts on the Henan Mountainside and bring them to Jared.
					if(QuestCommand.CanQuest(c,87)) break;
					return QuestCode.A120236(c,QuestID);
				case 120237:
					//Give Grace the perfume made by Jared.
					if(QuestCommand.CanQuest(c,87)) break;
					return QuestCode.A120237(c,QuestID);
				case 120238:
					//Kill 85 Carefree Beasts on the Henan Mountainside then go back and report to Jeremy.
					if(QuestCommand.CanQuest(c,88)) break;
					return QuestCode.A120238(c,QuestID);
				case 120239:
					//Kill 85 Spirit Dragons on the Henan Mountainside then go back and report to Jeremy.
					if(QuestCommand.CanQuest(c,88)) break;
					return QuestCode.A120239(c,QuestID);
				case 120240:
					//Kill 30 Dark Carefree Beasts on the Henan Moutainside then go back and tell Jeremy.
					if(QuestCommand.CanQuest(c,88)) break;
					return QuestCode.A120240(c,QuestID);
				case 120241:
					//Catch 85 Spirit Dragons on the Henan Mountainside and bring them to Jared.
					if(QuestCommand.CanQuest(c,89)) break;
					return QuestCode.A120241(c,QuestID);
				case 120242:
					//Give Mitchell Jared\'s Dragon Scale.
					if(QuestCommand.CanQuest(c,89)) break;
					return QuestCode.A120242(c,QuestID);
				case 120243:
					//Give Jared the Dragon Scale Shield made by Mitchell.
					if(QuestCommand.CanQuest(c,89)) break;
					return QuestCode.A120243(c,QuestID);
				case 129001:
					//Ask General Mandel the origin of Zodiac Wings.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A129001(c,QuestID);
				case 129002:
					//Kill the man of specified constellation to get starsoul with specified attribute. When the total fusion level of the attribute constellation reaches lv.4, star wings will be unlocked.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A129002(c,QuestID);
				case 129004:
					//Top up once and get your reward from Edith.
					if(QuestCommand.CanQuest(c,22)) break;
					return QuestCode.A129004(c,QuestID);
				case 129011:
					//Find Edith for Charles.
					if(QuestCommand.CanQuest(c,25)) break;
					return QuestCode.A129011(c,QuestID);
				case 129016:
					//Go to City of Genesis, upgrade your level at Stargazer Goya.
					if(QuestCommand.CanQuest(c,27)) break;
					return QuestCode.A129016(c,QuestID);
				case 129017:
					//Enter Stargazer\'s Tower, defeat one Puppet Man·Green and one Puppet Mage·Green, then find Goya to complete the quest.
					if(QuestCommand.CanQuest(c,27)) break;
					return QuestCode.A129017(c,QuestID);
				case 129019:
					//Enter Zodiac Dream1, defeat Little Suslik*2 and Green Gulu*2, then find Jason to complete the quest.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A129019(c,QuestID);
				case 130001:
					//Enter Dawn Pier, kill Meister Warlock*4, Meister Guard*4, Blade Master·Gudark*1, then report to Jeff.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130001(c,QuestID);
				case 130002:
					//Enter Sky City, kill Sky Crocodile*6, Cloud Dragon*6, Sky Mask*6, Faux· Emohill*1, then report to Beryl.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130002(c,QuestID);
				case 130003:
					//Go to 4 God Temple, kill 5 Priest of Fear, 5 Priest of Envy, 1 Priest of Greed, 1 Oracle of Pride, and then report to Blanche.
					if(QuestCommand.CanQuest(c,34)) break;
					return QuestCode.A130003(c,QuestID);
				case 130005:
					//Go to Blade Hill, defeat 4 Sword\'s Slaves, 4 Spirit Beasts, 1 Sword!$Starry Sky, 1 Sword!$Moonlight, then report to Aubrey.
					if(QuestCommand.CanQuest(c,40)) break;
					return QuestCode.A130005(c,QuestID);
				case 130006:
					//Go to Holy Land, defeat 5 Battle Spirit, 5 Sage Mentors, 1 Mentor!$Swift, 1 Shine\'s Father, then report to Adonis.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A130006(c,QuestID);
				case 130007:
					//Go to Holy Fire Origin, defeat 5 Life Element, 5 Death Element, 1 War God\'s Image, 1 War God\'s Image, then report to Barton.
					if(QuestCommand.CanQuest(c,52)) break;
					return QuestCode.A130007(c,QuestID);
				case 130009:
					//Transport supplies through City of Genesis and Land of Trial, and then take them to the Empire\'s Supply Officer.
					if(QuestCommand.CanQuest(c,28)) break;
					return QuestCode.A130009(c,QuestID);
				case 130010:
					//Transport supplies through City of Genesis and Land of Trial, and then take them to the Empire\'s Supply Officer.
					if(QuestCommand.CanQuest(c,28)) break;
					return QuestCode.A130010(c,QuestID);
				case 130011:
					//Transport supplies through City of Genesis and Land of Trial, and then take them to the Empire\'s Supply Officer.
					if(QuestCommand.CanQuest(c,28)) break;
					return QuestCode.A130011(c,QuestID);
				case 130022:
					//Defeat a player of the opponent country, then go to City of Genesis to find General Mandel.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A130022(c,QuestID);
				case 130023:
					//Defeat a player of the opponent country, then go to City of Genesis to find General Mandel.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A130023(c,QuestID);
				case 130024:
					//Defeat a player of the opponent country, then go to City of Genesis to find General Mandel.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A130024(c,QuestID);
				case 130054:
					//Kill 30 Toothy Gerbil in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130054(c,QuestID);
				case 130055:
					//Kill 30 Toxic Scorpions in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130055(c,QuestID);
				case 130056:
					//Kill 30 Rattlesnakes in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130056(c,QuestID);
				case 130057:
					//Kill 10 Swantony in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130057(c,QuestID);
				case 130058:
					//Kill 40 Dire Wolf in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130058(c,QuestID);
				case 130059:
					//Kill 40 Toothy Gerbil in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130059(c,QuestID);
				case 130060:
					//Kill 10 Benson in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130060(c,QuestID);
				case 130061:
					//Kill 50 Sand Fire Lizards in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130061(c,QuestID);
				case 130062:
					//Kill 50 Trade Wind Foxes in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130062(c,QuestID);
				case 130063:
					//Kill 10 Swantony in Darksand and then tell Lune Oasis\'s Chester.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130063(c,QuestID);
				case 130073:
					//Defeat 30 Toothy Gerbil in Darksand and then tell Darksand\'s Lyle.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130073(c,QuestID);
				case 130074:
					//Defeat 30 Dire Wolves in Darksand and then tell Darksand\'s Lyle.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130074(c,QuestID);
				case 130075:
					//Defeat 5 Swantony and 5 Benson in Darksand and then tell Darksand\'s Lyle.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130075(c,QuestID);
				case 130076:
					//Defeat 40 Toxic Scorpions in Darksand and then tell Darksand\'s Lyle.
					if(QuestCommand.CanQuest(c,35)) break;
					return QuestCode.A130076(c,QuestID);
				case 130077:
					//Defeat 40 Bactrian Camels in Darksand and then tell Darksand\'s Lyle.
					if(QuestCommand.CanQuest(c,35)) break;
					return QuestCode.A130077(c,QuestID);
				case 130078:
					//Defeat 5 Swantony and 5 Benson in Darksand and then tell Darksand\'s Lyle.
					if(QuestCommand.CanQuest(c,35)) break;
					return QuestCode.A130078(c,QuestID);
				case 130079:
					//Defeat 50 Rattlesnakes in Darksand and then tell Darksand\'s Lyle.
					if(QuestCommand.CanQuest(c,38)) break;
					return QuestCode.A130079(c,QuestID);
				case 130080:
					//Defeat 50 Trade Wind Fox in Darksand and then tell Darksand\'s Lyle.
					if(QuestCommand.CanQuest(c,38)) break;
					return QuestCode.A130080(c,QuestID);
				case 130081:
					//Defeat 5 Swantony and 5 Benson in Darksand and then tell Darksand\'s Lyle.
					if(QuestCommand.CanQuest(c,38)) break;
					return QuestCode.A130081(c,QuestID);
				case 130082:
					//Kill 30 Phantom Monkeys in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130082(c,QuestID);
				case 130083:
					//Kill 30 Man-eating Trees in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130083(c,QuestID);
				case 130084:
					//Kill 30 Giant Jaw Ants in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130084(c,QuestID);
				case 130085:
					//Kill 10 Baird in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130085(c,QuestID);
				case 130086:
					//Kill 40 Wraith Spiders in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130086(c,QuestID);
				case 130087:
					//Kill 40 Phantom Monkeys in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130087(c,QuestID);
				case 130088:
					//Kill 10 Archer in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130088(c,QuestID);
				case 130089:
					//Kill 50 Mud Monsters in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130089(c,QuestID);
				case 130090:
					//Kill 50 Giant Jaw Ants in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130090(c,QuestID);
				case 130091:
					//Kill 10 Baird in Vine Rainforest and then tell Tramp Camp\'s Hoare.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130091(c,QuestID);
				case 130101:
					//Defeat 30 Phantom Monkeys in Vine Rainforest and then tell Tramp Camp\'s Levi.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130101(c,QuestID);
				case 130102:
					//Defeat 30 Wraith Spiders in Vine Rainforest and then tell Tramp Camp\'s Levi.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130102(c,QuestID);
				case 130103:
					//Defeat 5 Baird and 5 Archer in Vine Rainforest and then tell Tramp Camp\'s Levi.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A130103(c,QuestID);
				case 130104:
					//Defeat 40 Man-eating Tree in Vine Rainforest and then tell Tramp Camp\'s Levi.
					if(QuestCommand.CanQuest(c,45)) break;
					return QuestCode.A130104(c,QuestID);
				case 130105:
					//Defeat 40 Giant Jaw Ants in Vine Rainforest and then tell Tramp Camp\'s Levi.
					if(QuestCommand.CanQuest(c,45)) break;
					return QuestCode.A130105(c,QuestID);
				case 130106:
					//Defeat 5 Baird and 5 Archer in Vine Rainforest and then tell Tramp Camp\'s Levi.
					if(QuestCommand.CanQuest(c,45)) break;
					return QuestCode.A130106(c,QuestID);
				case 130107:
					//Defeat 50 Mud Monsters in Vine Rainforest and then tell Tramp Camp\'s Levi.
					if(QuestCommand.CanQuest(c,48)) break;
					return QuestCode.A130107(c,QuestID);
				case 130108:
					//Defeat 50 Giant Jaw Ants in Vine Rainforest and then tell Tramp Camp\'s Levi.
					if(QuestCommand.CanQuest(c,48)) break;
					return QuestCode.A130108(c,QuestID);
				case 130109:
					//Defeat 5 Baird and 5 Archer in Vine Rainforest and then tell Tramp Camp\'s Levi.
					if(QuestCommand.CanQuest(c,48)) break;
					return QuestCode.A130109(c,QuestID);
				case 130110:
					//Enter Dawn Pier, kill Meister Swordsman*4, Head Warlock Karl*1, Lead Guard Danton*1, then go to City of Genesis and tell Burton.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130110(c,QuestID);
				case 130111:
					//Enter Sky City, kill Kamaitachi*6, Cloud Elf*6, Head Sky Crocodile*1, Cloud Elf King*1, then go to City of Genesis and tell Burton.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130111(c,QuestID);
				case 130112:
					//Go to 4 God Temple, kill 5 Priest of Pride, 5 Bishop of Greed, 1 Oracle of Envy, 1 Oracle of Terror, then go back to the City of Genesis and tell Larry.
					if(QuestCommand.CanQuest(c,34)) break;
					return QuestCode.A130112(c,QuestID);
				case 130114:
					//Go to Blade Hill, Defeat 4 Sword\'s Spirit, 4 Fierce Beast, 1 Scabbard!$Chaos, then go back to the City of Genesis and tell Larry.
					if(QuestCommand.CanQuest(c,40)) break;
					return QuestCode.A130114(c,QuestID);
				case 130115:
					//Go to Holy Land, Defeat 5 Element Spirit, 5 Killer Mentors, 1 Mentor!$Fearless, then go back to the City of Genesis and tell Larry.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A130115(c,QuestID);
				case 130116:
					//Go to Holy Fire Origin, defeat 5 Light Element, 5 Dark Element, 1 War God\'s Image, 1 Wisdom God\'s Image, then go back to the City of Genesis and tell Larry.
					if(QuestCommand.CanQuest(c,52)) break;
					return QuestCode.A130116(c,QuestID);
				case 130117:
					//Attack Dragon Cave and then report to Quenton.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A130117(c,QuestID);
				case 130118:
					//Attack Dragon Cave and then report to Quenton.
					if(QuestCommand.CanQuest(c,37)) break;
					return QuestCode.A130118(c,QuestID);
				case 130119:
					//Attack Dragon Cave and then report to Quenton.
					if(QuestCommand.CanQuest(c,47)) break;
					return QuestCode.A130119(c,QuestID);
				case 130120:
					//Complete Stargazer\'s Tower, then report to Stargazer Goya.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A130120(c,QuestID);
				case 130121:
					//Complete Stargazer\'s Tower, then report to Stargazer Goya.
					if(QuestCommand.CanQuest(c,36)) break;
					return QuestCode.A130121(c,QuestID);
				case 130122:
					//Complete Stargazer\'s Tower, then report to Stargazer Goya.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A130122(c,QuestID);
				case 130123:
					//Kill 30 Venom Monsters in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130123(c,QuestID);
				case 130124:
					//Kill 30 Short-wing Rats in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130124(c,QuestID);
				case 130125:
					//Kill 30 Medusa in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130125(c,QuestID);
				case 130126:
					//Kill 10 Olive in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130126(c,QuestID);
				case 130127:
					//Kill 40 Short-wing Rats in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130127(c,QuestID);
				case 130128:
					//Kill 40 Mugger Crocodiles in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130128(c,QuestID);
				case 130129:
					//Kill 10 Giant Carrion in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130129(c,QuestID);
				case 130130:
					//Kill 50 Carrion in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130130(c,QuestID);
				case 130131:
					//Kill 50 Medusa in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130131(c,QuestID);
				case 130132:
					//Kill 10 Olive in Redcloud Marsh and then tell Pearl Village\'s Osmond.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130132(c,QuestID);
				case 130136:
					//Defeat 30 Medusa in Redcloud Marsh and then tell Redcloud Marsh\'s Simona.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130136(c,QuestID);
				case 130137:
					//Defeat 30 Mugger Crocodiles in Redcloud Marsh and then tell Redcloud Marsh\'s Simona.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130137(c,QuestID);
				case 130138:
					//Defeat 5 Olive and 5 Giant Carrion in Redcloud Marsh and then tell Redcloud Marsh\'s Simona.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A130138(c,QuestID);
				case 130139:
					//Defeat 40 Venom Monsters in Redcloud Marsh and then tell Redcloud Marsh\'s Simona.
					if(QuestCommand.CanQuest(c,55)) break;
					return QuestCode.A130139(c,QuestID);
				case 130140:
					//Defeat 40 Medusa in Redcloud Marsh and then tell Redcloud Marsh\'s Simona.
					if(QuestCommand.CanQuest(c,55)) break;
					return QuestCode.A130140(c,QuestID);
				case 130141:
					//Defeat 5 Olive and 5 Giant Carrion in Redcloud Marsh and then tell Redcloud Marsh\'s Simona.
					if(QuestCommand.CanQuest(c,55)) break;
					return QuestCode.A130141(c,QuestID);
				case 130142:
					//Defeat 50 Short-wing Rats in Redcloud Marsh and then tell Redcloud Marsh\'s Simona.
					if(QuestCommand.CanQuest(c,58)) break;
					return QuestCode.A130142(c,QuestID);
				case 130143:
					//Defeat 50 Carrion in Redcloud Marsh and then tell Redcloud Marsh\'s Simona.
					if(QuestCommand.CanQuest(c,58)) break;
					return QuestCode.A130143(c,QuestID);
				case 130144:
					//Defeat 5 Olive and 5 Giant Carrion in Redcloud Marsh and then tell Redcloud Marsh\'s Simona.
					if(QuestCommand.CanQuest(c,58)) break;
					return QuestCode.A130144(c,QuestID);
				case 130145:
					//Kill 30 Darkwind Wolves in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130145(c,QuestID);
				case 130146:
					//Kill 30 Darkwind Hunters in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130146(c,QuestID);
				case 130147:
					//Kill 30 Canyon Centaurs in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130147(c,QuestID);
				case 130148:
					//Kill 10 Shadow Assassins in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130148(c,QuestID);
				case 130149:
					//Kill 40 Darkwind Wolves in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130149(c,QuestID);
				case 130150:
					//Kill 40 Stone Lizards in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130150(c,QuestID);
				case 130151:
					//Kill 10 Head Centaurs in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130151(c,QuestID);
				case 130152:
					//Kill 50 Darkwind Hunters in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130152(c,QuestID);
				case 130153:
					//Kill 50 Canyon Eagles in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130153(c,QuestID);
				case 130154:
					//Kill 10 Shadow Assassins in Darkwind Canyon and then tell Darkwind Canyon\'s Angelo.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130154(c,QuestID);
				case 130155:
					//Kill 30 Darkwind Hunters in Darkwind Canyon and then tell Darkwind Canyon\'s Atwood.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130155(c,QuestID);
				case 130156:
					//Kill 30 Darkwind Centaurs in Darkwind Canyon and then tell Darkwind Canyon\'s Atwood.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130156(c,QuestID);
				case 130157:
					//Defeat 5 Shadow Assassins and 5 Head Centaurs in Darkwind Canyon and then tell Darkwind Canyon\'s Atwood。
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A130157(c,QuestID);
				case 130158:
					//Kill 40 Darkwind Wolves in Darkwind Canyon and then tell Darkwind Canyon\'s Atwood.
					if(QuestCommand.CanQuest(c,65)) break;
					return QuestCode.A130158(c,QuestID);
				case 130159:
					//Kill 40 Darkwind Hunters in Darkwind Canyon and then tell Darkwind Canyon\'s Atwood.
					if(QuestCommand.CanQuest(c,65)) break;
					return QuestCode.A130159(c,QuestID);
				case 130160:
					//Defeat 5 Shadow Assassins and 5 Head Centaurs in Darkwind Canyon and then tell Darkwind Canyon\'s Atwood.
					if(QuestCommand.CanQuest(c,65)) break;
					return QuestCode.A130160(c,QuestID);
				case 130161:
					//Kill 50 Stone Lizards in Darkwind Canyon and then tell Darkwind Canyon\'s Atwood.
					if(QuestCommand.CanQuest(c,68)) break;
					return QuestCode.A130161(c,QuestID);
				case 130162:
					//Kill 50 Canyon Eagles in Darkwind Canyon and then tell Darkwind Canyon\'s Atwood.
					if(QuestCommand.CanQuest(c,68)) break;
					return QuestCode.A130162(c,QuestID);
				case 130163:
					//Defeat 5 Shadow Assassins and 5 Head Centaurs in Darkwind Canyon and then tell Darkwind Canyon\'s Atwood.
					if(QuestCommand.CanQuest(c,68)) break;
					return QuestCode.A130163(c,QuestID);
				case 130164:
					//Enter Starsoul instance, kill Ghost Sage·Borg, then go to see Morton.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130164(c,QuestID);
				case 130165:
					//Enter Starsoul instance, use 5 dream points, then go to see Charles.
					if(QuestCommand.CanQuest(c,30)) break;
					return QuestCode.A130165(c,QuestID);
				case 130166:
					//Enter Pharmacy, kill 3 Mana Potion Tyro, 3 HP Potion Tyro, 1 Druggist Kein, then report to Druggist Elo.
					if(QuestCommand.CanQuest(c,62)) break;
					return QuestCode.A130166(c,QuestID);
				case 130167:
					//Enter Pharmacy, kill 3 STR Potion Tyro, 3 DEF Potion Tyro, 1 Druggist Luyer, then back to City of Genesis and tell Burton.
					if(QuestCommand.CanQuest(c,62)) break;
					return QuestCode.A130167(c,QuestID);
				case 130168:
					//Kill 30 Foggy Bears in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130168(c,QuestID);
				case 130169:
					//Kill 30 Foggy Vampires in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130169(c,QuestID);
				case 130170:
					//Kill 30 Berserk Warriors in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130170(c,QuestID);
				case 130171:
					//Kill 10 Head Berserks in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130171(c,QuestID);
				case 130172:
					//Kill 40 Foggy Bears in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130172(c,QuestID);
				case 130173:
					//Kill 40 Foggy Spiders in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130173(c,QuestID);
				case 130174:
					//Kill 10 Wind Rider Rita in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130174(c,QuestID);
				case 130175:
					//Kill 50 Foggy Vampires in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130175(c,QuestID);
				case 130176:
					//Kill 50 Dawn Elves in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130176(c,QuestID);
				case 130177:
					//Kill 10 Head Berserks in Foggy Forest and then tell Foggy Forest\'s Gavin.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130177(c,QuestID);
				case 130178:
					//Kill 30 Foggy Vampires in Foggy Forest and then tell Foggy Forest\'s Dark.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130178(c,QuestID);
				case 130179:
					//Kill 30 Berserk Warriors in Foggy Forest and then tell Foggy Forest\'s Dark.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130179(c,QuestID);
				case 130180:
					//Kill 5 Head Berserks and 5 Wind Rider Rita in Foggy Forest and then tell Foggy Forest\'s Dark.
					if(QuestCommand.CanQuest(c,71)) break;
					return QuestCode.A130180(c,QuestID);
				case 130181:
					//Kill 40 Foggy Bears in Foggy Forest and then tell Foggy Forest\'s Dark.
					if(QuestCommand.CanQuest(c,75)) break;
					return QuestCode.A130181(c,QuestID);
				case 130182:
					//Kill 40 Foggy Vampires in Foggy Forest and then tell Foggy Forest\'s Dark.
					if(QuestCommand.CanQuest(c,75)) break;
					return QuestCode.A130182(c,QuestID);
				case 130183:
					//Kill 5 Head Berserks and 5 Wind Rider Rita in Foggy Forest and then tell Foggy Forest\'s Dark.
					if(QuestCommand.CanQuest(c,75)) break;
					return QuestCode.A130183(c,QuestID);
				case 130184:
					//Kill 50 Foggy Spiders in Foggy Forest and then tell Foggy Forest\'s Dark.
					if(QuestCommand.CanQuest(c,78)) break;
					return QuestCode.A130184(c,QuestID);
				case 130185:
					//Kill 50 Dawn Elves in Foggy Forest and then tell Foggy Forest\'s Dark.
					if(QuestCommand.CanQuest(c,78)) break;
					return QuestCode.A130185(c,QuestID);
				case 130186:
					//Kill 5 Head Berserks and 5 Wind Rider Rita in Foggy Forest and then tell Foggy Forest\'s Dark.
					if(QuestCommand.CanQuest(c,78)) break;
					return QuestCode.A130186(c,QuestID);
				case 130188:
					//Enter Candy Shop, kill 3 Chocolate Guards, 3 Milk Guards, 1 Tooth Decay King, then report to Alchemist Nami.
					if(QuestCommand.CanQuest(c,72)) break;
					return QuestCode.A130188(c,QuestID);
				case 130189:
					//Enter Candy Shop, kill 3 Mango Milktea Guards, 3 Strawberry Milktea Guards, 1 Biscuit Princess, then back to City of Genesis and tell Burton.
					if(QuestCommand.CanQuest(c,72)) break;
					return QuestCode.A130189(c,QuestID);
				case 130190:
					//Kill 30 Spirit Dragons on the Henan Mountainside then go back and report to Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130190(c,QuestID);
				case 130191:
					//Kill 30 Carefree Beasts on the Henan Mountainside then go back and report to Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130191(c,QuestID);
				case 130192:
					//Kill 30 Lost Acolytes on the Henan Mountainside then go back and report to Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130192(c,QuestID);
				case 130193:
					//Kill 10 Dark Carefree Beasts on the Henan Moutainside then go back and tell Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130193(c,QuestID);
				case 130194:
					//Kill 40 Spirit Dragons on the Henan Mountainside then go back and tell Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130194(c,QuestID);
				case 130195:
					//Kill 40 Bubble Beasts on the Henan Mountainside then go back and tell Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130195(c,QuestID);
				case 130196:
					//Kill 10 Guarder Sissi on the Henan Mountainside then go back and tell Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130196(c,QuestID);
				case 130197:
					//Kill 50 Carefree Beasts on the Henan Mountainside then go back and tell Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130197(c,QuestID);
				case 130198:
					//Kill 50 Skyish Beasts on the Henan Mountainside then go back and tell Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130198(c,QuestID);
				case 130199:
					//Kill 10 Dark Carefree Beasts on the Henan Moutainside then go back and tell Herman.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130199(c,QuestID);
				case 130200:
					//Defeat 30 Carefree Beasts on the Henan Mountainside then go back and report to Mitchell.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130200(c,QuestID);
				case 130201:
					//Defeat 30 Lost Acolytes on the Henan Mountainside then go back and report to Mitchell.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130201(c,QuestID);
				case 130202:
					//Defeat 5 Dark Carefree Beasts and 5 Guarder Sissi on the Henan Moutainside then go back and tell Mitchell.
					if(QuestCommand.CanQuest(c,81)) break;
					return QuestCode.A130202(c,QuestID);
				case 130203:
					//Defeat 40 Spirit Dragons on the Henan Mountainside then go back and tell Mitchell.
					if(QuestCommand.CanQuest(c,85)) break;
					return QuestCode.A130203(c,QuestID);
				case 130204:
					//Defeat 40 Carefree Beasts on the Henan Mountainside then go back and report to Mitchell.
					if(QuestCommand.CanQuest(c,85)) break;
					return QuestCode.A130204(c,QuestID);
				case 130205:
					//Defeat 5 Dark Carefree Beasts and 5 Guarder Sissi on the Henan Moutainside then go back and tell Mitchell.
					if(QuestCommand.CanQuest(c,85)) break;
					return QuestCode.A130205(c,QuestID);
				case 130206:
					//Defeat 50 Bubble Beasts on the Henan Mountainside then go back and tell  Mitchell.
					if(QuestCommand.CanQuest(c,88)) break;
					return QuestCode.A130206(c,QuestID);
				case 130207:
					//Defeat 50 Skyish Beasts on the Henan Mountainside then go back and tell Mitchell
					if(QuestCommand.CanQuest(c,88)) break;
					return QuestCode.A130207(c,QuestID);
				case 130208:
					//Defeat 5 Dark Carefree Beasts and 5 Guarder Sissi on the Henan Moutainside then go back and tell Mitchell.
					if(QuestCommand.CanQuest(c,88)) break;
					return QuestCode.A130208(c,QuestID);
				case 130209:
					//Enter the toy factory, kill 3 Raw Material Buyers, 3 Lost Secretaries and 1 Fallen Earl Charlie then report to Lord Terry .
					if(QuestCommand.CanQuest(c,82)) break;
					return QuestCode.A130209(c,QuestID);
				case 130210:
					//Enter the toy factory, kill 3 QA Inspectors, 3 Lost Guards，and 1 Dark Witch Avri, then go back to City of Genesis and report to Larry.
					if(QuestCommand.CanQuest(c,82)) break;
					return QuestCode.A130210(c,QuestID);
				case 140102:
					//Go to City of Genesis, ask Earl Kleist about the origin of the world.
					if(QuestCommand.CanQuest(c,31)) break;
					return QuestCode.A140102(c,QuestID);
				case 140103:
					//Go to City of Genesis, ask Earl Kleist about the origin of the world.
					if(QuestCommand.CanQuest(c,36)) break;
					return QuestCode.A140103(c,QuestID);
				case 140104:
					//Go to City of Genesis, ask Earl Kleist about the origin of the world.
					if(QuestCommand.CanQuest(c,41)) break;
					return QuestCode.A140104(c,QuestID);
				case 140105:
					//Go to City of Genesis, ask Earl Kleist about the origin of the world.
					if(QuestCommand.CanQuest(c,46)) break;
					return QuestCode.A140105(c,QuestID);
				case 140106:
					//Go to City of Genesis, ask Earl Kleist about the origin of the world.
					if(QuestCommand.CanQuest(c,51)) break;
					return QuestCode.A140106(c,QuestID);
				case 140107:
					//Go to City of Genesis, ask Earl Kleist about the origin of the world.
					if(QuestCommand.CanQuest(c,56)) break;
					return QuestCode.A140107(c,QuestID);
				case 140108:
					//Go to City of Genesis, ask Earl Kleist about the origin of the world.
					if(QuestCommand.CanQuest(c,61)) break;
					return QuestCode.A140108(c,QuestID);
				case 140109:
					//Go to City of Genesis, ask Earl Kleist about the origin of the world.
					if(QuestCommand.CanQuest(c,66)) break;
					return QuestCode.A140109(c,QuestID);
				case 140206:
					//Go to City of Genesis, ask General Alston about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140206(c,QuestID);
				case 140207:
					//Go to Glory City, ask Haglos about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140207(c,QuestID);
				case 140208:
					//Go to City of Rage, ask Berger about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140208(c,QuestID);
				case 140209:
					//Go to City of Trees, ask Makhlou about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140209(c,QuestID);
				case 140211:
					//Go to City of Genesis, ask General Alston about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140211(c,QuestID);
				case 140212:
					//Go to Glory City, ask Haglos about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140212(c,QuestID);
				case 140213:
					//Go to City of Rage, ask Berger about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140213(c,QuestID);
				case 140214:
					//Go to City of Trees, ask Makhlou about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140214(c,QuestID);
				case 140216:
					//Go to City of Genesis, ask General Alston about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140216(c,QuestID);
				case 140217:
					//Go to Glory City, ask Haglos about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140217(c,QuestID);
				case 140218:
					//Go to City of Rage, ask Berger about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140218(c,QuestID);
				case 140219:
					//Go to City of Trees, ask Makhlou about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140219(c,QuestID);
				case 140221:
					//Go to City of Genesis, ask General Alston about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140221(c,QuestID);
				case 140222:
					//Go to Glory City, ask Haglos about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140222(c,QuestID);
				case 140223:
					//Go to City of Rage, ask Berger about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140223(c,QuestID);
				case 140224:
					//Go to City of Trees, ask Makhlou about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140224(c,QuestID);
				case 140225:
					//Go to City of Genesis, ask General Alston about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140225(c,QuestID);
				case 140226:
					//Go to Glory City, ask Haglos about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140226(c,QuestID);
				case 140227:
					//Go to City of Rage, ask Berger about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140227(c,QuestID);
				case 140228:
					//Go to City of Trees, ask Makhlou about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140228(c,QuestID);
				case 140229:
					//Go to City of Genesis, ask General Alston about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140229(c,QuestID);
				case 140230:
					//Go to Glory City, ask Haglos about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140230(c,QuestID);
				case 140231:
					//Go to City of Rage, ask Berger about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140231(c,QuestID);
				case 140232:
					//Go to City of Trees, ask Makhlou about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140232(c,QuestID);
				case 140233:
					//Go to City of Genesis, ask General Alston about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140233(c,QuestID);
				case 140234:
					//Go to Glory City, ask Haglos about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140234(c,QuestID);
				case 140235:
					//Go to City of Rage, ask Berger about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140235(c,QuestID);
				case 140236:
					//Go to City of Trees, ask Makhlou about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140236(c,QuestID);
				case 140237:
					//Go to City of Genesis, ask General Alston about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140237(c,QuestID);
				case 140238:
					//Go to Glory City, ask Haglos about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140238(c,QuestID);
				case 140239:
					//Go to City of Rage, ask Berger about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140239(c,QuestID);
				case 140240:
					//Go to City of Trees, ask Makhlou about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140240(c,QuestID);
				case 140309:
					//Defeat 50 Toothy Gerbils, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140309(c,QuestID);
				case 140310:
					//Defeat 50 Bactrian Camels, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140310(c,QuestID);
				case 140311:
					//Defeat 50 Rattlesnakes, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140311(c,QuestID);
				case 140312:
					//Defeat 50 Dire Wolves, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140312(c,QuestID);
				case 140313:
					//Defeat 50 Trade Wind Foxes, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140313(c,QuestID);
				case 140314:
					//Defeat 50 Toxic Scorpions, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140314(c,QuestID);
				case 140315:
					//Defeat 50 Sand Fire Lizards, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140315(c,QuestID);
				case 140316:
					//Collect 10 Darkthorn Cactus, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140316(c,QuestID);
				case 140317:
					//Collect 10 Buckthorn Grass, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140317(c,QuestID);
				case 140318:
					//Collect 10 Buckthorn Flowers, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140318(c,QuestID);
				case 140319:
					//Collect 10 Darksand Essences, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140319(c,QuestID);
				case 140322:
					//Defeat 60 Toothy Gerbils, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140322(c,QuestID);
				case 140323:
					//Defeat 60 Bactrian Camels, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140323(c,QuestID);
				case 140324:
					//Defeat 60 Rattlesnakes, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140324(c,QuestID);
				case 140325:
					//Defeat 60 Dire Wolves, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140325(c,QuestID);
				case 140326:
					//Defeat 60 Trade Wind Foxes, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140326(c,QuestID);
				case 140327:
					//Defeat 60 Toxic Scorpions, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140327(c,QuestID);
				case 140328:
					//Defeat 60 Sand Fire Lizards, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140328(c,QuestID);
				case 140329:
					//Collect 10 Darkthorn Cactus, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140329(c,QuestID);
				case 140330:
					//Collect 10 Buckthorn Grass, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140330(c,QuestID);
				case 140331:
					//Collect 10 Buckthorn Flowers, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140331(c,QuestID);
				case 140332:
					//Collect 10 Darksand Essences, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140332(c,QuestID);
				case 140335:
					//Defeat 70 Giant Jaw Ants, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140335(c,QuestID);
				case 140336:
					//Defeat 70 Mud Monsters, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140336(c,QuestID);
				case 140337:
					//Defeat 70 Man-eating Trees, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140337(c,QuestID);
				case 140338:
					//Defeat 70 Phantom Monkeys, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140338(c,QuestID);
				case 140339:
					//Defeat 70 Wraith Spiders, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140339(c,QuestID);
				case 140340:
					//Collect 10 Delusion Herbs, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140340(c,QuestID);
				case 140341:
					//Collect 10 Vampire Vines, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140341(c,QuestID);
				case 140342:
					//Collect 10 Luminous Grass, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140342(c,QuestID);
				case 140343:
					//Collect 10 Water Mana Spar, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140343(c,QuestID);
				case 140346:
					//Defeat 80 Giant Jaw Ants, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140346(c,QuestID);
				case 140347:
					//Defeat 80 Mud Monsters, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140347(c,QuestID);
				case 140348:
					//Defeat 80 Man-eating Trees, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140348(c,QuestID);
				case 140349:
					//Defeat 80 Phantom Monkeys, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140349(c,QuestID);
				case 140350:
					//Defeat 80 Wraith Spiders, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140350(c,QuestID);
				case 140351:
					//Collect 10 Delusion Herbs, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140351(c,QuestID);
				case 140352:
					//Collect 10 Vampire Vines, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140352(c,QuestID);
				case 140353:
					//Collect 10 Luminous Grass, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140353(c,QuestID);
				case 140354:
					//Collect 10 Water Mana Spar, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140354(c,QuestID);
				case 140355:
					//Defeat 90 Venom Monsters, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140355(c,QuestID);
				case 140356:
					//Defeat 90 Short-wing Rats, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140356(c,QuestID);
				case 140357:
					//Defeat 90 Medusa, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140357(c,QuestID);
				case 140358:
					//Defeat 90 Mugger Crocodiles, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140358(c,QuestID);
				case 140359:
					//Defeat 90 Carrion, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140359(c,QuestID);
				case 140360:
					//Collect 10 Fluorescent Herbs, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140360(c,QuestID);
				case 140361:
					//Collect 10 Rotten Flowers, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140361(c,QuestID);
				case 140362:
					//Collect 10 Greenbell Flowers, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140362(c,QuestID);
				case 140363:
					//Defeat 100 Venom Monsters, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140363(c,QuestID);
				case 140364:
					//Defeat 100 Short-wing Rats, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140364(c,QuestID);
				case 140365:
					//Defeat 100 Medusa, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140365(c,QuestID);
				case 140366:
					//Defeat 100 Mugger Crocodiles, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140366(c,QuestID);
				case 140367:
					//Defeat 100 Carrion, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140367(c,QuestID);
				case 140368:
					//Collect 10 Fluorescent Herbs, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140368(c,QuestID);
				case 140369:
					//Collect 10 Rotten Flowers, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140369(c,QuestID);
				case 140370:
					//Collect 10 Greenbell Flowers, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140370(c,QuestID);
				case 140371:
					//Defeat 110 Dire Wolves, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140371(c,QuestID);
				case 140372:
					//Defeat 110 Darkwind Hunters, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140372(c,QuestID);
				case 140373:
					//Defeat 110 Canyon Centaurs, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140373(c,QuestID);
				case 140374:
					//Defeat 110 Stone Lizards, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140374(c,QuestID);
				case 140375:
					//Defeat 110 Canyon Eagles, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140375(c,QuestID);
				case 140376:
					//Collect 10 Cruor Grasses, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140376(c,QuestID);
				case 140377:
					//Collect 10 Hyacinths, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140377(c,QuestID);
				case 140378:
					//Defeat 120 Darkwind Wolves, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140378(c,QuestID);
				case 140379:
					//Defeat 120 Darkwind Hunters, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140379(c,QuestID);
				case 140380:
					//Defeat 120 Canyon Centaurs, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140380(c,QuestID);
				case 140381:
					//Defeat 120 Stone Lizards, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140381(c,QuestID);
				case 140382:
					//Defeat 120 Canyon Eagles, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140382(c,QuestID);
				case 140383:
					//Collect 10 Cruor Grasses, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140383(c,QuestID);
				case 140384:
					//Collect 10 Hyacinths, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140384(c,QuestID);
				case 140406:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140406(c,QuestID);
				case 140407:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140407(c,QuestID);
				case 140408:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140408(c,QuestID);
				case 140409:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140409(c,QuestID);
				case 140411:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140411(c,QuestID);
				case 140412:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140412(c,QuestID);
				case 140413:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140413(c,QuestID);
				case 140414:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140414(c,QuestID);
				case 140416:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140416(c,QuestID);
				case 140417:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140417(c,QuestID);
				case 140418:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140418(c,QuestID);
				case 140419:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140419(c,QuestID);
				case 140421:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140421(c,QuestID);
				case 140422:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140422(c,QuestID);
				case 140423:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140423(c,QuestID);
				case 140424:
					//Go to City of Trees, ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140424(c,QuestID);
				case 140425:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140425(c,QuestID);
				case 140426:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140426(c,QuestID);
				case 140427:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140427(c,QuestID);
				case 140428:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140428(c,QuestID);
				case 140429:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140429(c,QuestID);
				case 140430:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140430(c,QuestID);
				case 140431:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140431(c,QuestID);
				case 140432:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140432(c,QuestID);
				case 140433:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140433(c,QuestID);
				case 140434:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140434(c,QuestID);
				case 140435:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140435(c,QuestID);
				case 140436:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140436(c,QuestID);
				case 140437:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140437(c,QuestID);
				case 140438:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140438(c,QuestID);
				case 140439:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140439(c,QuestID);
				case 140440:
					//Ask Scarce about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140440(c,QuestID);
				case 140502:
					//Go to City of Genesis, ask Dempsey about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140502(c,QuestID);
				case 140503:
					//Go to City of Genesis, ask Dempsey about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140503(c,QuestID);
				case 140504:
					//Go to City of Genesis, ask Dempsey about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140504(c,QuestID);
				case 140505:
					//Go to City of Genesis, ask Dempsey about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140505(c,QuestID);
				case 140506:
					//Go to City of Genesis, ask Dempsey about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140506(c,QuestID);
				case 140507:
					//Go to City of Genesis, ask Dempsey about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140507(c,QuestID);
				case 140508:
					//Go to City of Genesis, ask Dempsey about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140508(c,QuestID);
				case 140509:
					//Go to City of Genesis, ask Dempsey about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140509(c,QuestID);
				case 140609:
					//Defeat 50 Toothy Gerbils, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140609(c,QuestID);
				case 140610:
					//Defeat 50 Bactrian Camels, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140610(c,QuestID);
				case 140611:
					//Defeat 50 Rattlesnakes, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140611(c,QuestID);
				case 140612:
					//Defeat 50 Dire Wolves, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140612(c,QuestID);
				case 140613:
					//Defeat 50 Trade Wind Foxes, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140613(c,QuestID);
				case 140614:
					//Defeat 50 Toxic Scorpions, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140614(c,QuestID);
				case 140615:
					//Defeat 50 Sand Fire Lizards, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140615(c,QuestID);
				case 140616:
					//Collect 10 Darkthorn Cactuses, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140616(c,QuestID);
				case 140617:
					//Collect 10 Buckthorn Grasses, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140617(c,QuestID);
				case 140618:
					//Collect 10 Buckthorn Flowers, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140618(c,QuestID);
				case 140619:
					//Collect 10 Darksand Essences, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140619(c,QuestID);
				case 140622:
					//Defeat 60 Toothy Gerbils, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140622(c,QuestID);
				case 140623:
					//Defeat 60 Bactrian Camels, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140623(c,QuestID);
				case 140624:
					//Defeat 60 Rattlesnakes, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140624(c,QuestID);
				case 140625:
					//Defeat 60 Dire Wolves, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140625(c,QuestID);
				case 140626:
					//Defeat 60 Trade Wind Foxes, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140626(c,QuestID);
				case 140627:
					//Defeat 60 Toxic Scorpions, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140627(c,QuestID);
				case 140628:
					//Defeat 60 Sand Fire Lizards, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140628(c,QuestID);
				case 140629:
					//Collect 10 Darkthorn Cactuses, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140629(c,QuestID);
				case 140630:
					//Collect 10 Buckthorn Grasses, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140630(c,QuestID);
				case 140631:
					//Collect 10 Buckthorn Flowers, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140631(c,QuestID);
				case 140632:
					//Collect 10 Darksand Essences, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140632(c,QuestID);
				case 140635:
					//Defeat 70 Giant Jaw Ants, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140635(c,QuestID);
				case 140636:
					//Defeat 70 Mud Monsters, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140636(c,QuestID);
				case 140637:
					//Defeat 70 Man-eating Trees, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140637(c,QuestID);
				case 140638:
					//Defeat 70 Phantom Monkeys, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140638(c,QuestID);
				case 140639:
					//Defeat 70 Wraith Spiders, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140639(c,QuestID);
				case 140640:
					//Collect 10 Delusion Herbs, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140640(c,QuestID);
				case 140641:
					//Collect 10 Vampire Vines, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140641(c,QuestID);
				case 140642:
					//Collect 10 Luminous Grasses, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140642(c,QuestID);
				case 140643:
					//Collect 10 Water Mana Spars, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140643(c,QuestID);
				case 140646:
					//Defeat 80 Giant Jaw Ants, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140646(c,QuestID);
				case 140647:
					//Defeat 80 Mud Monsters, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140647(c,QuestID);
				case 140648:
					//Defeat 80 Man-eating Trees, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140648(c,QuestID);
				case 140649:
					//Defeat 80 Phantom Monkeys, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140649(c,QuestID);
				case 140650:
					//Defeat 80 Wraith Spiders, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140650(c,QuestID);
				case 140651:
					//Collect 10 Delusion Herbs, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140651(c,QuestID);
				case 140652:
					//Collect 10 Vampire Vines, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140652(c,QuestID);
				case 140653:
					//Collect 10 Luminous Grasses, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140653(c,QuestID);
				case 140654:
					//Collect 10 Water Mana Spars, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140654(c,QuestID);
				case 140655:
					//Defeat 90 Venom Monsters, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140655(c,QuestID);
				case 140656:
					//Defeat 90 Short-wing Rats, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140656(c,QuestID);
				case 140657:
					//Defeat 90 Medusa, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140657(c,QuestID);
				case 140658:
					//Defeat 90 Mugger Crocodiles, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140658(c,QuestID);
				case 140659:
					//Defeat 90 Carrions, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140659(c,QuestID);
				case 140660:
					//Collect 10 Fluorescent Herbs, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140660(c,QuestID);
				case 140661:
					//Collect 10 Rotten Flowers, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140661(c,QuestID);
				case 140662:
					//Defeat 100 Venom Monsters, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140662(c,QuestID);
				case 140663:
					//Defeat 100 Short-wing Rats, then go to Glory City, ask Yehar about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140663(c,QuestID);
				case 140664:
					//Defeat 100 Medusa, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140664(c,QuestID);
				case 140665:
					//Defeat 100 Mugger Crocodiles, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140665(c,QuestID);
				case 140666:
					//Defeat 100 Carrions, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140666(c,QuestID);
				case 140667:
					//Collect 10 Fluorescent Herbs, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140667(c,QuestID);
				case 140668:
					//Collect 10 Rotten Flowers, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140668(c,QuestID);
				case 140669:
					//Collect 10 Greenbell Flowers, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140669(c,QuestID);
				case 140670:
					//Defeat 110 Darkwind Wolves, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140670(c,QuestID);
				case 140671:
					//Defeat 110 Darkwind Hunters, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140671(c,QuestID);
				case 140672:
					//Defeat 110 Canyon Centaurs, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140672(c,QuestID);
				case 140673:
					//Defeat 110 Stone Lizards, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140673(c,QuestID);
				case 140674:
					//Defeat 110 Canyon Eagles, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140674(c,QuestID);
				case 140675:
					//Collect 10 Cruor Grasses, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140675(c,QuestID);
				case 140676:
					//Collect 10 Hyacinths, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140676(c,QuestID);
				case 140677:
					//Defeat 120 Darkwind Wolves, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140677(c,QuestID);
				case 140678:
					//Defeat 120 Darkwind Hunters, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140678(c,QuestID);
				case 140679:
					//Defeat 120 Canyon Centaurs, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140679(c,QuestID);
				case 140680:
					//Defeat 120 Stone Lizards, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140680(c,QuestID);
				case 140681:
					//Defeat 120 Canyon Eagles, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140681(c,QuestID);
				case 140682:
					//Collect 10 Cruor Grasses, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140682(c,QuestID);
				case 140683:
					//Collect 10 Hyacinths, then go to City of Rage, ask Cliff about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140683(c,QuestID);
				case 140706:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140706(c,QuestID);
				case 140707:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140707(c,QuestID);
				case 140708:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140708(c,QuestID);
				case 140709:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140709(c,QuestID);
				case 140711:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140711(c,QuestID);
				case 140712:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140712(c,QuestID);
				case 140713:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140713(c,QuestID);
				case 140714:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140714(c,QuestID);
				case 140716:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140716(c,QuestID);
				case 140717:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140717(c,QuestID);
				case 140718:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140718(c,QuestID);
				case 140719:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140719(c,QuestID);
				case 140721:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140721(c,QuestID);
				case 140722:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140722(c,QuestID);
				case 140723:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140723(c,QuestID);
				case 140724:
					//Go to Glory City, ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140724(c,QuestID);
				case 140725:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140725(c,QuestID);
				case 140726:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140726(c,QuestID);
				case 140727:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140727(c,QuestID);
				case 140728:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140728(c,QuestID);
				case 140729:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140729(c,QuestID);
				case 140730:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140730(c,QuestID);
				case 140731:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140731(c,QuestID);
				case 140732:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140732(c,QuestID);
				case 140733:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140733(c,QuestID);
				case 140734:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140734(c,QuestID);
				case 140735:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140735(c,QuestID);
				case 140736:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140736(c,QuestID);
				case 140737:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140737(c,QuestID);
				case 140738:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140738(c,QuestID);
				case 140739:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140739(c,QuestID);
				case 140740:
					//Ask Kon about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140740(c,QuestID);
				case 140806:
					//Go to City of Trees, ask Nana about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140806(c,QuestID);
				case 140807:
					//Go to City of Rage, ask Amelia about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140807(c,QuestID);
				case 140808:
					//Go to Glory City, ask Minny about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140808(c,QuestID);
				case 140809:
					//Go to City of Genesis, ask Eugene about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140809(c,QuestID);
				case 140811:
					//Go to City of Trees, ask Nana about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140811(c,QuestID);
				case 140812:
					//Go to City of Rage, ask Amelia about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140812(c,QuestID);
				case 140813:
					//Go to Glory City, ask Minny about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140813(c,QuestID);
				case 140814:
					//Go to City of Genesis, ask Eugene about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140814(c,QuestID);
				case 140816:
					//Go to City of Trees, ask Nana about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140816(c,QuestID);
				case 140817:
					//Go to City of Rage, ask Amelia about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140817(c,QuestID);
				case 140818:
					//Go to Glory City, ask Minny about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140818(c,QuestID);
				case 140819:
					//Go to City of Genesis, ask Eugene about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140819(c,QuestID);
				case 140821:
					//Go to City of Trees, ask Nana about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140821(c,QuestID);
				case 140822:
					//Go to City of Rage, ask Amelia about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140822(c,QuestID);
				case 140823:
					//Go to Glory City, ask Minny about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140823(c,QuestID);
				case 140824:
					//Go to City of Genesis, ask Eugene about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140824(c,QuestID);
				case 140825:
					//Go to City of Trees, ask Nana about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140825(c,QuestID);
				case 140826:
					//Go to City of Rage, ask Amelia about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140826(c,QuestID);
				case 140827:
					//Go to Glory City, ask Minny about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140827(c,QuestID);
				case 140828:
					//Go to City of Genesis, ask Eugene about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140828(c,QuestID);
				case 140829:
					//Go to City of Trees, ask Nana about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140829(c,QuestID);
				case 140830:
					//Go to City of Rage, ask Amelia about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140830(c,QuestID);
				case 140831:
					//Go to Glory City, ask Minny about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140831(c,QuestID);
				case 140832:
					//Go to City of Genesis, ask Eugene about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140832(c,QuestID);
				case 140833:
					//Go to City of Trees, ask Nana about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140833(c,QuestID);
				case 140834:
					//Go to City of Rage, ask Amelia about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140834(c,QuestID);
				case 140835:
					//Go to Glory City, ask Minny about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140835(c,QuestID);
				case 140836:
					//Go to City of Genesis, ask Eugene about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140836(c,QuestID);
				case 140837:
					//Go to City of Trees, ask Nana about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140837(c,QuestID);
				case 140838:
					//Go to City of Rage, ask Amelia about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140838(c,QuestID);
				case 140839:
					//Go to Glory City, ask Minny about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140839(c,QuestID);
				case 140840:
					//Go to City of Genesis, ask Eugene about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140840(c,QuestID);
				case 140903:
					//Defeat 15 Swantony, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140903(c,QuestID);
				case 140904:
					//Defeat 15 Benson, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140904(c,QuestID);
				case 140905:
					//Defeat 15 Swantony, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140905(c,QuestID);
				case 140906:
					//Defeat 15 Benson, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140906(c,QuestID);
				case 140907:
					//Defeat 15 Baird, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140907(c,QuestID);
				case 140908:
					//Defeat 15 Archer, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140908(c,QuestID);
				case 140909:
					//Defeat 15 Baird, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140909(c,QuestID);
				case 140910:
					//Defeat 15 Archer, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140910(c,QuestID);
				case 140911:
					//Defeat 15 Olive, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140911(c,QuestID);
				case 140912:
					//Defeat 15 Giant Carrion, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140912(c,QuestID);
				case 140913:
					//Defeat 15 Olive, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140913(c,QuestID);
				case 140914:
					//Defeat 15 Giant Carrion, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140914(c,QuestID);
				case 140915:
					//Defeat 15 Shadow Assassins, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140915(c,QuestID);
				case 140916:
					//Defeat 15 Head Centaurs, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140916(c,QuestID);
				case 140917:
					//Defeat 15 Shadow Assassins, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140917(c,QuestID);
				case 140918:
					//Defeat 15 Head Centaurs, then go to City of Rage, ask Marie about the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A140918(c,QuestID);
				case 141002:
					//Find Doreen and tell her that you\'ve known the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A141002(c,QuestID);
				case 141003:
					//Find Doreen and tell her that you\'ve known the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A141003(c,QuestID);
				case 141004:
					//Find Doreen and tell her that you\'ve known the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A141004(c,QuestID);
				case 141005:
					//Find Doreen and tell her that you\'ve known the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A141005(c,QuestID);
				case 141006:
					//Find Doreen and tell her that you\'ve known the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A141006(c,QuestID);
				case 141007:
					//Find Doreen and tell her that you\'ve known the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A141007(c,QuestID);
				case 141008:
					//Find Doreen and tell her that you\'ve known the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A141008(c,QuestID);
				case 141009:
					//Find Doreen and tell her that you\'ve known the origin of the world.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A141009(c,QuestID);
				case 150001:
					//Accept Zodiac Temple\'s order, kill any monster*20 at Lune Oasis.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150001(c,QuestID);
				case 150002:
					//Accept Zodiac Temple\'s order, kill any monster*40 at Lune Oasis.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150002(c,QuestID);
				case 150003:
					//Accept Zodiac Temple\'s order, kill any monster*60 at Lune Oasis.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150003(c,QuestID);
				case 150004:
					//Accept Zodiac Temple\'s order, kill any monster*80 at Lune Oasis.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150004(c,QuestID);
				case 150005:
					//Accept Zodiac Temple\'s order, kill any monster*100 at Lune Oasis.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150005(c,QuestID);
				case 150006:
					//Accept Zodiac Temple\'s order, kill any monster*30 at Darksand.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150006(c,QuestID);
				case 150007:
					//Accept Zodiac Temple\'s order, kill any monster*60 at Darksand.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150007(c,QuestID);
				case 150008:
					//Accept Zodiac Temple\'s order, kill any monster*90 at Darksand.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150008(c,QuestID);
				case 150009:
					//Accept Zodiac Temple\'s order, kill any monster*120 at Darksand.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150009(c,QuestID);
				case 150010:
					//Accept Zodiac Temple\'s order, any monster*150 at Darksand.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150010(c,QuestID);
				case 150011:
					//Accept Zodiac Temple\'s order, kill any monster*50 in Vine Rainforest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150011(c,QuestID);
				case 150012:
					//Accept Zodiac Temple\'s order, kill any monster*100 in Vine Rainforest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150012(c,QuestID);
				case 150013:
					//Accept Zodiac Temple\'s order, kill any monster*150 in Vine Rainforest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150013(c,QuestID);
				case 150014:
					//Accept Zodiac Temple\'s order, kill any monster*200 in Vine Rainforest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150014(c,QuestID);
				case 150015:
					//Accept Zodiac Temple\'s order, kill any monster*250 in Vine Rainforest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150015(c,QuestID);
				case 150016:
					//Accept Zodiac Temple\'s order, kill any monster*50 in Redcloud Marsh.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150016(c,QuestID);
				case 150017:
					//Accept Zodiac Temple\'s order,kill any monster*100 in Redcloud Marsh.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150017(c,QuestID);
				case 150018:
					//Accept Zodiac Temple\'s order, kill any monster*150 in Redcloud Marsh.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150018(c,QuestID);
				case 150019:
					//Accept Zodiac Temple\'s order, kill any monster*200 in Redcloud Marsh.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150019(c,QuestID);
				case 150020:
					//Accept Zodiac Temple\'s order, kill any monster*250 in Redcloud Marsh.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150020(c,QuestID);
				case 150021:
					//Accept Zodiac Temple\'s order, kill any monster*50 in Darkwind Canyon.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150021(c,QuestID);
				case 150022:
					//Accept Zodiac Temple\'s order, kill any monster*100 in Darkwind Canyon.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150022(c,QuestID);
				case 150023:
					//Accept Zodiac Temple\'s order, kill any monster*150 in Darkwind Canyon.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150023(c,QuestID);
				case 150024:
					//Accept Zodiac Temple\'s order, kill any monster*200 in Darkwind Canyon.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150024(c,QuestID);
				case 150025:
					//Accept Zodiac Temple\'s order, kill any monster*250 in Darkwind Canyon.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150025(c,QuestID);
				case 150026:
					//Accept Zodiac Temple\'s order, kill any monster*50 in Foggy Forest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150026(c,QuestID);
				case 150027:
					//Accept Zodiac Temple\'s order, kill any monster*100 in Foggy Forest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150027(c,QuestID);
				case 150028:
					//Accept Zodiac Temple\'s order, kill any monster*150 in Foggy Forest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150028(c,QuestID);
				case 150029:
					//Accept Zodiac Temple\'s order, kill any monster*200 in Foggy Forest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150029(c,QuestID);
				case 150030:
					//Accept Zodiac Temple\'s order, kill any monster*250 in Foggy Forest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150030(c,QuestID);
				case 150031:
					//Accept Zodiac Temple\'s order, any monster*300 at Darksand Land.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150031(c,QuestID);
				case 150032:
					//Accept Zodiac Temple\'s order, kill any monster*500 in Vine Rainforest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150032(c,QuestID);
				case 150033:
					//Accept Zodiac Temple\'s order, kill any monster*500 in Redcloud Marsh.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150033(c,QuestID);
				case 150034:
					//Accept Zodiac Temple\'s order, kill any monster*500 in Darkwind Canyon.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150034(c,QuestID);
				case 150035:
					//Accept Zodiac Temple\'s order, kill any monster*500 in Foggy Forest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150035(c,QuestID);
				case 150036:
					//Accept Zodiac Temple\'s order, collect 20 Darksand Essences from Darksand Land.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150036(c,QuestID);
				case 150037:
					//Accept Zodiac Temple\'s order, collect 20 Water Mana Spars from Vine Rainforest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150037(c,QuestID);
				case 150038:
					//Accept Zodiac Temple\'s order, collect 20 Greenbell Flowers from Redcloud Marsh.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150038(c,QuestID);
				case 150039:
					//Accept Zodiac Temple\'s order, collect 20 Hyacinths from Darkwind Canyon.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150039(c,QuestID);
				case 150040:
					//Accept Zodiac Temple\'s order, collect 20 Hyacinths from Foggy Forest.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150040(c,QuestID);
				case 150041:
					//Accept Zodiac Temple\'s order, kill any monster*50 at Henan Mountainside.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150041(c,QuestID);
				case 150042:
					//Accept Zodiac Temple\'s order, kill any monster*100 at Henan Mountainside.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150042(c,QuestID);
				case 150043:
					//Accept Zodiac Temple\'s order, kill any monster*150 at Henan Mountainside.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150043(c,QuestID);
				case 150044:
					//Accept Zodiac Temple\'s order, kill any monster*200 at Henan Mountainside.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150044(c,QuestID);
				case 150045:
					//Accept Zodiac Temple\'s order, kill any monster*250 at Henan Mountainside.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150045(c,QuestID);
				case 150046:
					//Accept Zodiac Temple\'s order, kill any monster*500 at Henan Mountainside.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150046(c,QuestID);
				case 150047:
					//Accept Zodiac Temple\'s order, collect 20 Despair Herbs at Henan Mountainside.
					if(QuestCommand.CanQuest(c,200)) break;
					return QuestCode.A150047(c,QuestID);
			}

			return 3;
		}
	*/
    }
}
