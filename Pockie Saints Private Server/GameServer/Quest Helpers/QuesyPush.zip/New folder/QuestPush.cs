using System;
using System.Collections.Generic;

namespace GameServer
{
	internal static class QuestPush
	{
		public static byte P100003(ConnectionInfo c)
		{

			if(!Players.GetPlayer(c.rlid).bag.CanBagAdd(1)) return 3;

			switch(Players.GetPlayer(c.rlid).charz.career)
			{
				case 1:
					Players.GetPlayer(c.rlid).bag.AddBagItem(1010001,1,2);
					break;
				case 2:
					Players.GetPlayer(c.rlid).bag.AddBagItem(1010002,1,2);
					break;
				case 3:
					Players.GetPlayer(c.rlid).bag.AddBagItem(1010003,1,2);
					break;
			}

			return 1;
		}

		public static byte P100005(ConnectionInfo c)
		{

			switch(Players.GetPlayer(c.rlid).charz.career)
			{
				case 1:
					 Players.GetPlayer(c.rlid).skill.AddSkill(101101);
					break;
				case 2:
					 Players.GetPlayer(c.rlid).skill.AddSkill(201101);
					break;
				case 3:
					 Players.GetPlayer(c.rlid).skill.AddSkill(301101);
					break;
			}
			Players.GetPlayer(c.rlid).skill.Save(c);
			GameServer.Command.SkillController.SendSkillRefresh(c);

			return 1;
		}

	}
}
